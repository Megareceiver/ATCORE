-- phpMyAdmin SQL Dump
-- version 4.4.15.7
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 19, 2017 at 07:15 AM
-- Server version: 5.5.47-MariaDB
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `at_dev`
--

-- --------------------------------------------------------

--
-- Table structure for table `attachments`
--

CREATE TABLE IF NOT EXISTS `attachments` (
  `id` int(11) unsigned NOT NULL,
  `description` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `type_no` int(11) NOT NULL DEFAULT '0',
  `trans_no` int(11) NOT NULL DEFAULT '0',
  `unique_name` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tran_date` date NOT NULL DEFAULT '0000-00-00',
  `filename` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `filesize` int(11) NOT NULL DEFAULT '0',
  `filetype` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT ''
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `attachments`
--

INSERT INTO `attachments` (`id`, `description`, `type_no`, `trans_no`, `unique_name`, `tran_date`, `filename`, `filesize`, `filetype`) VALUES
(1, '', 10, 1, '57d771125559e', '2016-09-13', 'AMK-AMK PROJECT 2016-05-17 1430-a21tech.XLS', 13824, 'application/vnd.ms-excel');

-- --------------------------------------------------------

--
-- Table structure for table `audit_trail`
--

CREATE TABLE IF NOT EXISTS `audit_trail` (
  `id` int(11) NOT NULL,
  `type` smallint(6) unsigned NOT NULL DEFAULT '0',
  `trans_no` int(11) unsigned NOT NULL DEFAULT '0',
  `user` smallint(6) unsigned NOT NULL DEFAULT '0',
  `stamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `description` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fiscal_year` int(11) NOT NULL,
  `gl_date` date NOT NULL DEFAULT '0000-00-00',
  `gl_seq` int(11) unsigned DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=194 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `audit_trail`
--

INSERT INTO `audit_trail` (`id`, `type`, `trans_no`, `user`, `stamp`, `description`, `fiscal_year`, `gl_date`, `gl_seq`) VALUES
(1, 18, 32, 10, '2016-08-09 06:05:01', '', 3, '2016-08-09', 0),
(2, 25, 31, 10, '2016-08-09 06:05:01', '', 3, '2016-08-09', 0),
(3, 20, 1, 10, '2016-08-09 06:05:01', '', 3, '2016-08-09', 0),
(4, 18, 33, 10, '2016-08-09 06:15:22', '', 3, '2016-08-01', 0),
(5, 25, 32, 10, '2016-08-09 06:15:22', '', 3, '2016-08-01', 0),
(6, 20, 2, 10, '2016-08-09 06:15:22', '', 3, '2016-08-01', 0),
(7, 18, 34, 10, '2016-08-09 06:17:31', '', 3, '2016-08-02', 0),
(8, 25, 33, 10, '2016-08-09 06:17:31', '', 3, '2016-08-02', 0),
(9, 20, 3, 10, '2016-08-09 06:17:31', '', 3, '2016-08-02', 0),
(10, 18, 35, 10, '2016-08-09 06:18:56', '', 3, '2016-07-01', 0),
(11, 25, 34, 10, '2016-08-09 06:18:56', '', 3, '2016-07-01', 0),
(12, 20, 4, 10, '2016-08-09 06:18:56', '', 3, '2016-07-01', 0),
(13, 18, 36, 10, '2016-08-09 06:19:46', '', 3, '2016-05-01', 0),
(14, 25, 35, 10, '2016-08-09 06:19:46', '', 3, '2016-05-01', 0),
(15, 20, 5, 10, '2016-08-09 06:19:46', '', 3, '2016-05-01', 0),
(16, 30, 1, 10, '2016-08-09 06:23:28', '', 3, '2016-08-10', 0),
(17, 13, 1, 10, '2016-08-09 06:23:28', '', 3, '2016-08-10', 0),
(18, 10, 1, 10, '2016-08-09 06:23:28', 'Updated.', 3, '2016-08-10', 0),
(19, 30, 2, 10, '2016-08-09 06:25:11', '', 3, '2016-08-11', 0),
(20, 13, 2, 10, '2016-08-09 06:25:11', '', 3, '2016-08-11', 0),
(21, 10, 2, 10, '2016-08-09 06:25:11', 'Updated.', 3, '2016-08-11', 0),
(22, 30, 3, 10, '2016-08-09 06:26:57', '', 3, '2016-07-10', 0),
(23, 13, 3, 10, '2016-08-09 06:26:57', '', 3, '2016-07-10', 0),
(24, 10, 3, 10, '2016-08-09 06:26:57', 'Updated.', 3, '2016-07-10', 0),
(25, 30, 4, 10, '2016-08-09 06:27:40', '', 3, '2016-08-09', 0),
(26, 13, 4, 10, '2016-08-09 06:27:40', '', 3, '2016-08-09', 0),
(27, 10, 4, 10, '2016-08-09 06:27:40', 'Updated.', 3, '2016-08-09', 0),
(28, 30, 5, 10, '2016-08-09 06:28:06', '', 3, '2016-08-09', 0),
(29, 13, 5, 10, '2016-08-09 06:28:07', '', 3, '2016-08-09', 0),
(30, 10, 5, 10, '2016-08-09 06:28:07', 'Updated.', 3, '2016-08-09', 0),
(31, 22, 1, 10, '2016-08-09 06:37:20', '', 3, '2016-08-09', 0),
(32, 22, 2, 10, '2016-08-09 06:39:08', '', 3, '2016-08-09', 0),
(33, 12, 1, 10, '2016-08-09 06:43:12', '', 3, '2016-08-09', 0),
(34, 96, 1, 0, '2016-08-09 13:11:00', NULL, 3, '2015-12-31', NULL),
(35, 96, 1, 0, '2016-08-09 13:14:52', NULL, 3, '2015-12-31', NULL),
(36, 96, 1, 0, '2016-08-09 13:15:08', NULL, 3, '2015-12-31', NULL),
(37, 95, 1, 0, '2016-08-09 13:16:13', NULL, 3, '2015-12-31', NULL),
(38, 30, 6, 10, '2016-08-09 13:31:09', '', 3, '2016-08-09', 0),
(39, 13, 6, 10, '2016-08-09 13:31:09', '', 3, '2016-08-09', 0),
(40, 10, 6, 10, '2016-08-09 13:31:09', 'Updated.', 3, '2016-08-09', 0),
(41, 12, 2, 10, '2016-08-09 13:32:51', '', 3, '2016-08-09', 0),
(42, 30, 7, 10, '2016-08-09 13:56:57', '', 3, '2016-08-09', 0),
(43, 13, 7, 10, '2016-08-09 13:56:58', '', 3, '2016-08-09', 0),
(44, 10, 7, 10, '2016-08-09 13:56:58', 'Updated.', 3, '2016-08-09', 0),
(45, 12, 3, 10, '2016-08-09 13:56:58', '', 3, '2016-08-09', 0),
(46, 12, 4, 10, '2016-08-09 14:02:33', '', 3, '2016-08-09', 0),
(47, 18, 37, 10, '2016-08-09 14:14:51', '', 3, '2016-08-09', 0),
(48, 25, 36, 10, '2016-08-09 14:14:51', '', 3, '2016-08-09', 0),
(49, 20, 6, 10, '2016-08-09 14:14:51', '', 3, '2016-08-09', 0),
(50, 22, 3, 10, '2016-08-09 14:15:30', '', 3, '2016-08-09', 0),
(51, 95, 2, 0, '2016-08-09 14:32:24', NULL, 3, '2015-12-31', NULL),
(52, 18, 38, 10, '2016-08-10 02:50:59', '', 3, '2016-08-10', 0),
(53, 25, 37, 10, '2016-08-10 02:56:31', '', 3, '2016-08-10', 0),
(54, 20, 7, 10, '2016-08-10 03:06:03', '', 3, '2016-08-10', 0),
(55, 22, 4, 10, '2016-08-10 03:14:02', '', 3, '2016-08-10', 0),
(56, 18, 39, 10, '2016-08-10 03:17:24', '', 3, '2016-08-10', 0),
(57, 25, 38, 10, '2016-08-10 03:17:24', '', 3, '2016-08-10', 0),
(58, 20, 8, 10, '2016-08-10 03:17:24', '', 3, '2016-08-10', 0),
(59, 22, 5, 10, '2016-08-10 03:18:00', '', 3, '2016-08-10', 0),
(60, 18, 40, 10, '2016-08-10 03:18:46', '', 3, '2016-08-10', 0),
(61, 25, 39, 10, '2016-08-10 03:18:56', '', 3, '2016-08-10', 0),
(62, 20, 9, 10, '2016-08-10 03:19:35', '', 3, '2016-08-10', 0),
(63, 22, 6, 10, '2016-08-10 03:20:25', '', 3, '2016-08-10', 0),
(64, 22, 7, 10, '2016-08-10 03:22:49', '', 3, '2016-08-10', 0),
(65, 18, 41, 10, '2016-08-10 03:32:31', '', 3, '2016-08-10', 0),
(66, 25, 40, 10, '2016-08-10 03:32:31', '', 3, '2016-08-10', 0),
(67, 20, 10, 10, '2016-08-10 03:32:31', '', 3, '2016-08-10', 0),
(68, 18, 42, 10, '2016-08-10 03:36:33', '', 3, '2016-08-10', 0),
(69, 25, 41, 10, '2016-08-10 03:37:59', '', 3, '2016-08-10', 0),
(70, 18, 43, 10, '2016-08-10 03:38:18', '', 3, '2016-08-10', 0),
(71, 25, 42, 10, '2016-08-10 03:38:26', '', 3, '2016-08-10', 0),
(72, 20, 11, 10, '2016-08-10 03:40:10', '', 3, '2016-08-10', 0),
(73, 22, 8, 10, '2016-08-10 03:40:31', '', 3, '2016-08-10', 0),
(74, 18, 44, 10, '2016-08-10 03:41:33', '', 3, '2016-08-10', 0),
(75, 25, 43, 10, '2016-08-10 03:41:40', '', 3, '2016-08-10', 0),
(76, 20, 12, 10, '2016-08-10 03:42:12', '', 3, '2016-08-10', 0),
(77, 32, 1, 10, '2016-08-10 03:42:17', '', 3, '2016-08-10', 0),
(78, 30, 8, 10, '2016-08-10 03:42:27', '', 3, '2016-08-10', 0),
(79, 13, 8, 10, '2016-08-10 03:42:35', '', 3, '2016-08-10', 0),
(80, 10, 8, 10, '2016-08-10 03:43:02', 'Updated.', 3, '2016-08-10', 0),
(81, 12, 5, 10, '2016-08-10 03:43:02', '', 3, '2016-08-10', 0),
(82, 18, 45, 10, '2016-08-10 03:43:18', '', 3, '2016-08-10', 0),
(83, 25, 44, 10, '2016-08-10 03:43:18', '', 3, '2016-08-10', 0),
(84, 20, 13, 10, '2016-08-10 03:43:18', '', 3, '2016-08-10', 0),
(85, 32, 2, 10, '2016-08-10 03:44:09', '', 3, '2016-08-10', 0),
(86, 30, 9, 10, '2016-08-10 03:44:17', '', 3, '2016-08-10', 0),
(87, 30, 10, 10, '2016-08-10 03:45:35', '', 3, '2016-08-10', 0),
(88, 13, 9, 10, '2016-08-10 03:45:35', '', 3, '2016-08-10', 0),
(89, 10, 9, 10, '2016-08-10 03:45:35', 'Updated.', 3, '2016-08-10', 0),
(90, 12, 6, 10, '2016-08-10 03:45:35', '', 3, '2016-08-10', 0),
(91, 13, 10, 10, '2016-08-10 03:46:14', '', 3, '2016-08-10', 0),
(92, 10, 10, 10, '2016-08-10 03:46:21', 'Updated.', 3, '2016-08-10', 0),
(93, 12, 7, 10, '2016-08-10 03:46:21', '', 3, '2016-08-10', 0),
(94, 1, 1, 10, '2016-08-10 03:50:56', '', 3, '2016-08-10', 0),
(95, 32, 3, 10, '2016-08-10 03:54:23', '', 3, '2016-08-10', 0),
(96, 30, 11, 10, '2016-08-10 03:54:54', '', 3, '2016-08-10', 0),
(97, 21, 1, 10, '2016-08-10 04:01:33', '', 3, '2016-08-10', 0),
(98, 12, 8, 10, '2016-08-10 04:12:45', '', 3, '2016-08-10', 0),
(99, 22, 9, 10, '2016-08-10 04:13:09', '', 3, '2016-08-10', 0),
(100, 18, 46, 10, '2016-08-10 04:26:46', '', 3, '2016-08-10', 0),
(101, 25, 45, 10, '2016-08-10 04:26:46', '', 3, '2016-08-10', 0),
(102, 20, 14, 10, '2016-08-10 04:26:46', '', 3, '2016-08-10', 0),
(103, 22, 10, 10, '2016-08-10 04:26:55', '', 3, '2016-08-10', 0),
(104, 18, 47, 10, '2016-08-10 04:28:58', '', 3, '2016-08-10', 0),
(105, 25, 46, 10, '2016-08-10 04:28:58', '', 3, '2016-08-10', 0),
(106, 20, 15, 10, '2016-08-10 04:28:58', '', 3, '2016-08-10', 0),
(107, 22, 11, 10, '2016-08-10 04:29:04', '', 3, '2016-08-10', 0),
(108, 18, 48, 10, '2016-08-10 05:10:42', '', 3, '2016-08-10', 0),
(109, 25, 47, 10, '2016-08-10 05:10:42', '', 3, '2016-08-10', 0),
(110, 20, 16, 10, '2016-08-10 05:10:42', '', 3, '2016-08-10', 0),
(111, 12, 9, 10, '2016-08-10 05:14:29', '', 3, '2016-08-10', 0),
(112, 12, 10, 10, '2016-08-10 05:14:56', '', 3, '2016-08-10', 0),
(113, 18, 49, 10, '2016-08-10 05:15:51', '', 3, '2016-08-10', 0),
(114, 25, 48, 10, '2016-08-10 05:15:51', '', 3, '2016-08-10', 0),
(115, 20, 17, 10, '2016-08-10 05:15:51', '', 3, '2016-08-10', 0),
(116, 12, 11, 10, '2016-08-10 05:16:04', '', 3, '2016-08-10', 0),
(117, 12, 12, 10, '2016-08-10 05:16:29', '', 3, '2016-08-10', 0),
(118, 30, 12, 10, '2016-08-10 05:42:32', '', 3, '2016-08-10', 0),
(119, 13, 11, 10, '2016-08-10 05:42:33', '', 3, '2016-08-10', 0),
(120, 10, 11, 10, '2016-08-10 05:42:33', 'Updated.', 3, '2016-08-10', 0),
(121, 18, 50, 10, '2016-08-10 05:43:46', '', 3, '2016-08-10', 0),
(122, 25, 49, 10, '2016-08-10 05:43:46', '', 3, '2016-08-10', 0),
(123, 20, 18, 10, '2016-08-10 05:43:46', '', 3, '2016-08-10', 0),
(124, 18, 51, 10, '2016-08-10 05:44:26', '', 3, '2016-08-10', 0),
(125, 25, 50, 10, '2016-08-10 05:44:26', '', 3, '2016-08-10', 0),
(126, 20, 19, 10, '2016-08-10 05:44:26', '', 3, '2016-08-10', 0),
(127, 18, 52, 10, '2016-08-10 05:48:04', '', 3, '2016-08-10', 0),
(128, 25, 51, 10, '2016-08-10 05:48:04', '', 3, '2016-08-10', 0),
(129, 20, 20, 10, '2016-08-10 05:48:04', '', 3, '2016-08-10', 0),
(130, 30, 13, 10, '2016-08-10 05:51:39', '', 3, '2016-08-10', 0),
(131, 13, 12, 10, '2016-08-10 05:51:39', '', 3, '2016-08-10', 0),
(132, 10, 12, 10, '2016-08-10 05:51:39', 'Updated.', 3, '2016-08-10', 0),
(133, 18, 53, 10, '2016-08-10 05:53:55', '', 3, '2016-08-10', 0),
(134, 25, 52, 10, '2016-08-10 05:53:55', '', 3, '2016-08-10', 0),
(135, 96, 2, 0, '2016-08-10 05:57:35', NULL, 3, '2015-12-31', NULL),
(136, 2, 1, 10, '2016-08-10 07:40:17', '', 3, '2016-08-02', 0),
(137, 30, 14, 10, '2016-08-10 07:51:18', '', 3, '2016-08-10', 0),
(138, 13, 13, 10, '2016-08-10 07:51:19', '', 3, '2016-08-10', 0),
(139, 10, 13, 10, '2016-08-10 07:51:19', 'Updated.', 3, '2016-08-10', 0),
(140, 35, 1, 10, '2016-08-10 08:30:51', '', 3, '2016-08-10', 0),
(141, 30, 15, 10, '2016-08-10 10:22:19', '', 3, '2016-08-10', 0),
(142, 12, 13, 10, '2016-08-16 02:04:17', '', 3, '2016-08-16', 0),
(143, 18, 54, 10, '2016-08-25 14:30:57', '', 3, '2016-08-25', 0),
(144, 25, 53, 10, '2016-08-25 14:30:57', '', 3, '2016-08-25', 0),
(145, 17, 1, 10, '2016-08-25 22:47:40', '', 3, '2016-08-26', 0),
(146, 17, 2, 10, '2016-08-25 22:51:03', '', 3, '2016-08-26', 0),
(147, 30, 16, 10, '2016-08-25 22:54:13', '', 3, '2016-08-26', 0),
(148, 13, 14, 10, '2016-08-25 22:54:13', '', 3, '2016-08-26', 0),
(149, 10, 14, 10, '2016-08-25 22:54:13', 'Updated.', 3, '2016-08-26', 0),
(150, 30, 17, 14, '2016-08-29 04:58:29', '', 3, '2016-08-29', 0),
(151, 13, 15, 14, '2016-08-29 04:58:29', '', 3, '2016-08-29', 0),
(152, 10, 15, 14, '2016-08-29 04:58:29', 'Updated.', 3, '2016-08-29', 0),
(153, 1, 2, 14, '2016-09-12 14:39:07', '', 3, '2016-09-12', 0),
(154, 30, 18, 14, '2016-09-12 14:42:19', '', 3, '2016-09-12', 0),
(155, 13, 16, 14, '2016-09-12 14:42:20', '', 3, '2016-09-12', 0),
(156, 10, 16, 14, '2016-09-12 14:42:20', 'Updated.', 3, '2016-09-12', 0),
(157, 35, 2, 14, '2016-09-13 02:11:47', '', 3, '2016-09-12', 0),
(158, 30, 19, 14, '2016-09-28 06:51:37', '', 3, '2016-09-28', 0),
(159, 13, 17, 14, '2016-09-28 06:51:38', '', 3, '2016-09-28', 0),
(160, 10, 17, 14, '2016-09-28 06:51:38', 'Updated.', 3, '2016-09-28', 0),
(161, 12, 14, 14, '2016-09-28 06:51:38', '', 3, '2016-09-28', 0),
(162, 12, 15, 14, '2016-09-28 06:52:33', '', 3, '2016-09-28', 0),
(163, 18, 55, 10, '2016-11-25 04:35:47', '', 3, '2017-12-31', 0),
(164, 1, 3, 10, '2016-12-22 07:38:16', '', 3, '2017-12-31', 0),
(165, 32, 4, 10, '2017-02-15 04:05:11', '', 3, '2017-02-15', 0),
(166, 32, 5, 10, '2017-02-16 02:40:44', '', 3, '2017-02-16', 0),
(167, 30, 20, 10, '2017-02-16 04:50:31', '', 3, '2017-02-16', 0),
(168, 13, 18, 10, '2017-02-16 04:50:31', '', 3, '2017-02-16', 0),
(169, 30, 21, 10, '2017-02-16 07:44:11', '', 3, '2017-02-16', 0),
(170, 13, 19, 10, '2017-02-16 07:44:11', '', 3, '2017-02-16', 0),
(171, 30, 22, 10, '2017-02-16 08:01:49', '', 3, '2017-02-16', 0),
(172, 13, 20, 10, '2017-02-16 08:01:49', '', 3, '2017-02-16', 0),
(173, 30, 23, 10, '2017-02-16 08:04:18', '', 3, '2017-02-16', 0),
(174, 30, 24, 10, '2017-02-16 08:12:39', '', 3, '2017-02-16', 0),
(175, 13, 21, 10, '2017-02-16 08:12:39', '', 3, '2017-02-16', 0),
(176, 10, 18, 10, '2017-02-16 08:12:39', 'Updated.', 3, '2017-02-16', 0),
(177, 1, 4, 10, '2017-02-18 02:18:11', '', 3, '2017-02-18', 0),
(178, 1, 5, 10, '2017-02-21 06:57:50', '', 3, '2017-02-21', 0),
(179, 2, 2, 10, '2017-02-21 06:58:31', '', 3, '2017-02-21', 0),
(180, 1, 6, 10, '2017-02-21 10:57:30', '', 3, '2017-02-21', 0),
(181, 2, 3, 10, '2017-02-21 10:57:59', '', 3, '2017-02-21', 0),
(182, 0, 1, 10, '2017-02-21 11:01:36', '', 3, '2017-02-21', 0),
(183, 0, 2, 10, '2017-02-21 11:11:54', '', 3, '2017-02-21', 0),
(184, 4, 1, 10, '2017-02-22 08:25:52', '', 3, '2017-02-22', 0),
(185, 30, 25, 10, '2017-02-23 06:42:52', '', 3, '2017-02-23', 0),
(186, 13, 22, 10, '2017-02-23 06:42:53', '', 3, '2017-02-23', 0),
(187, 10, 19, 10, '2017-02-23 06:42:53', 'Updated.', 3, '2017-02-23', 0),
(188, 12, 16, 10, '2017-02-23 06:44:19', '', 3, '2017-02-23', 0),
(189, 32, 6, 10, '2017-03-07 08:28:03', '', 3, '2017-03-07', 0),
(190, 30, 26, 10, '2017-05-06 04:47:57', '', 3, '2017-05-06', 0),
(191, 13, 23, 10, '2017-05-06 04:47:57', '', 3, '2017-05-06', 0),
(192, 10, 20, 10, '2017-05-06 04:47:57', 'Updated.', 3, '2017-05-06', 0),
(193, 12, 17, 10, '2017-05-06 04:47:57', '', 3, '2017-05-06', 0);

-- --------------------------------------------------------

--
-- Table structure for table `bad_debts`
--

CREATE TABLE IF NOT EXISTS `bad_debts` (
  `id` int(11) NOT NULL,
  `type` smallint(6) NOT NULL,
  `type_no` int(16) NOT NULL,
  `tran_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `step` tinyint(2) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `bank_accounts`
--

CREATE TABLE IF NOT EXISTS `bank_accounts` (
  `account_code` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `account_type` smallint(6) NOT NULL DEFAULT '0',
  `bank_account_name` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `bank_account_number` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `bank_name` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `bank_address` tinytext COLLATE utf8_unicode_ci,
  `bank_curr_code` char(3) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `dflt_curr_act` tinyint(1) NOT NULL DEFAULT '0',
  `id` smallint(6) NOT NULL,
  `last_reconciled_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ending_reconcile_balance` double NOT NULL DEFAULT '0',
  `inactive` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `bank_accounts`
--

INSERT INTO `bank_accounts` (`account_code`, `account_type`, `bank_account_name`, `bank_account_number`, `bank_name`, `bank_address`, `bank_curr_code`, `dflt_curr_act`, `id`, `last_reconciled_date`, `ending_reconcile_balance`, `inactive`) VALUES
('1060', 0, 'Bank SGD', '0011001247618', 'OCBC Bank of Singapore', '53 Ang Mo Kio Avenue 3, Singapore', 'SGD', 1, 9, '2017-02-23 05:00:00', 0, 0),
('1065', 3, 'Petty Cash', '', '', '', 'SGD', 0, 5, '0000-00-00 00:00:00', 0, 0),
('1050', 0, 'Bank USD', '', 'Bank USD', '', 'USD', 1, 8, '0000-00-00 00:00:00', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `bank_trans`
--

CREATE TABLE IF NOT EXISTS `bank_trans` (
  `id` int(11) NOT NULL,
  `type` smallint(6) DEFAULT NULL,
  `trans_no` int(11) DEFAULT NULL,
  `bank_act` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tax_inclusive` tinyint(1) NOT NULL DEFAULT '0',
  `ref` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `trans_date` date NOT NULL DEFAULT '0000-00-00',
  `amount` double DEFAULT NULL,
  `dimension_id` int(11) NOT NULL DEFAULT '0',
  `dimension2_id` int(11) NOT NULL DEFAULT '0',
  `person_type_id` int(11) NOT NULL DEFAULT '0',
  `person_id` tinyblob,
  `reconciled` date DEFAULT NULL,
  `cheque` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `imported_goods_invoice` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `bank_trans`
--

INSERT INTO `bank_trans` (`id`, `type`, `trans_no`, `bank_act`, `tax_inclusive`, `ref`, `trans_date`, `amount`, `dimension_id`, `dimension2_id`, `person_type_id`, `person_id`, `reconciled`, `cheque`, `imported_goods_invoice`) VALUES
(1, 22, 1, '9', 0, 'IJ/PV/0001', '2016-08-09', -214, 0, 0, 3, 0x32, '2016-09-28', '', NULL),
(2, 22, 2, '9', 0, 'IJ/PV/0002', '2016-08-09', -4280, 0, 0, 3, 0x33, '2016-09-28', '', NULL),
(3, 12, 1, '9', 0, 'COR 001', '2016-08-09', 0, 0, 0, 2, 0x32, '2016-09-28', '', NULL),
(4, 0, NULL, '9', 0, NULL, '2015-12-31', 50000, 0, 0, 0, NULL, '2017-02-23', '', NULL),
(5, 12, 2, '9', 0, 'COR 002', '2016-08-09', 10000, 0, 0, 2, 0x37, '2016-09-28', '', NULL),
(6, 12, 3, '5', 0, 'COR 003', '2016-08-09', 1070, 0, 0, 2, 0x38, NULL, '', NULL),
(7, 12, 4, '9', 0, 'COR 004', '2016-08-09', 535, 0, 0, 2, 0x37, '2017-02-23', '', NULL),
(8, 22, 3, '9', 0, 'IJ/PV/0003', '2016-08-09', -15700, 0, 0, 3, 0x37, '2017-02-23', '', NULL),
(9, 22, 4, '9', 0, 'IJ/PV/0004', '2016-08-10', -3412, 0, 0, 3, 0x33, '2017-02-23', '', NULL),
(10, 22, 5, '9', 0, 'IJ/PV/0005', '2016-08-10', -1000, 0, 0, 3, 0x33, '2017-02-23', '', NULL),
(11, 22, 6, '9', 0, 'IJ/PV/0006', '2016-08-10', -850, 0, 0, 3, 0x34, '2017-02-23', '', NULL),
(12, 22, 7, '9', 0, 'IJ/PV/0007', '2016-08-10', -1605, 0, 0, 3, 0x34, '2017-02-23', '', NULL),
(13, 22, 8, '9', 0, 'IJ/PV/0008', '2016-08-10', -4280, 0, 0, 3, 0x37, '2017-02-23', '', NULL),
(14, 12, 5, '5', 0, 'COR 005', '2016-08-10', 1000, 0, 0, 2, 0x38, NULL, '', NULL),
(15, 12, 6, '5', 0, 'COR 006', '2016-08-10', 963, 0, 0, 2, 0x38, NULL, '', NULL),
(16, 12, 7, '5', 0, 'COR 007', '2016-08-10', 2140, 0, 0, 2, 0x38, NULL, '', NULL),
(17, 1, 1, '5', 0, 'IJ/PV/0001', '2016-08-10', -107, 0, 0, 0, 0x6f666669636520737570706c696573, NULL, '', NULL),
(18, 12, 8, '9', 0, 'COR 008', '2016-08-10', 128.4, 0, 0, 2, 0x32, '2017-02-23', '', NULL),
(19, 22, 9, '9', 0, 'IJ/PV/0009', '2016-08-10', -568, 0, 0, 3, 0x32, '2017-02-23', '', NULL),
(20, 22, 10, '9', 0, 'IJ/PV/0010', '2016-08-10', -1000, 0, 0, 3, 0x33, '2017-02-23', '', NULL),
(21, 22, 11, '9', 0, 'IJ/PV/0011', '2016-08-10', -2140, 0, 0, 3, 0x32, '2017-02-23', '', NULL),
(22, 12, 9, '9', 0, 'COR 009', '2016-08-10', 246.1, 0, 0, 2, 0x33, '2017-02-23', '', NULL),
(23, 12, 10, '9', 0, 'COR 010', '2016-08-10', 535, 0, 0, 2, 0x34, '2017-02-23', '', NULL),
(24, 12, 11, '9', 0, 'COR 011', '2016-08-10', 1551.5, 0, 0, 2, 0x35, '2017-02-23', '', NULL),
(25, 12, 12, '9', 0, 'COR 012', '2016-08-10', 668.75, 0, 0, 2, 0x36, '2017-02-23', '', NULL),
(26, 2, 1, '9', 0, 'OR 0001', '2016-08-02', 5.4, 0, 0, 0, '', '2016-09-28', '', NULL),
(27, 12, 13, '9', 0, 'COR 013', '2016-08-16', 30000, 0, 0, 2, 0x38, '2017-02-23', '', NULL),
(28, 1, 2, '9', 0, 'J/PV/0002', '2016-09-12', -200, 0, 0, 2, 0x35, '2017-02-23', '123456', NULL),
(29, 12, 14, '5', 0, 'COR 014', '2016-09-28', 214, 0, 0, 2, 0x38, NULL, '', NULL),
(30, 12, 15, '9', 0, 'COR 015', '2016-09-28', 190, 0, 0, 2, 0x38, '2017-02-23', '', NULL),
(31, 1, 3, '9', 0, 'J/PV/0003', '2017-12-31', -200, 0, 0, 0, '', NULL, '', NULL),
(32, 1, 4, '9', 0, 'J/PV/0004', '2017-02-18', -200, 0, 0, 0, '', '2017-02-23', 'T256488', NULL),
(33, 1, 5, '9', 0, 'J/PV/0005', '2017-02-21', -500, 0, 0, 0, '', '2017-02-23', '', NULL),
(34, 2, 2, '9', 0, 'OR 0002', '2017-02-21', 200, 0, 0, 0, '', '2017-02-23', '', NULL),
(35, 1, 6, '9', 0, 'J/PV/0006', '2017-02-21', -20, 0, 0, 0, '', '2017-02-23', '', NULL),
(36, 2, 3, '9', 0, 'OR 0003', '2017-02-21', 25, 0, 0, 0, '', '2017-02-23', '', NULL),
(37, 0, 1, '5', 0, 'JV 0001', '2017-02-21', 400, 0, 0, 0, '', NULL, '', NULL),
(38, 0, 2, '8', 0, 'JV 0002', '2017-02-21', 16, 0, 0, 0, '', NULL, '', NULL),
(39, 4, 1, '9', 0, 'FT 0001', '2017-02-22', -1770, 0, 0, 0, 0x46726f6d2042616e6b2053474420546f2042616e6b20555344, '2017-02-23', '', NULL),
(40, 4, 1, '8', 0, 'FT 0001', '2017-02-22', 1200, 0, 0, 0, 0x46726f6d2042616e6b2053474420546f2042616e6b20555344, NULL, '', NULL),
(41, 98, 1, '''.5.''', 0, NULL, '2015-12-31', 0, 0, 0, 0, NULL, NULL, '', NULL),
(42, 98, 1, '''.8.''', 0, NULL, '2015-12-31', 0, 0, 0, 0, NULL, NULL, '', NULL),
(43, 98, 1, '''.9.''', 0, NULL, '2015-12-31', 50, 0, 0, 0, NULL, NULL, '', NULL),
(44, 12, 16, '9', 0, 'COR 016', '2017-02-23', 1070, 0, 0, 2, 0x35, '2017-02-23', '', NULL),
(45, 12, 17, '5', 0, 'COR 017', '2017-05-06', 237.54, 0, 0, 2, 0x38, NULL, '', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `bank_trans_detail`
--

CREATE TABLE IF NOT EXISTS `bank_trans_detail` (
  `id` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `account_code` char(10) NOT NULL,
  `amount` double NOT NULL,
  `trans_no` int(11) NOT NULL,
  `currence` char(50) NOT NULL,
  `currence_rate` double NOT NULL,
  `tax` int(11) NOT NULL,
  `cheque` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bank_trans_detail`
--

INSERT INTO `bank_trans_detail` (`id`, `type`, `account_code`, `amount`, `trans_no`, `currence`, `currence_rate`, `tax`, `cheque`) VALUES
(1, 1, '5700', 100, 1, 'SGD', 1, 46, ''),
(2, 2, '4440', -5.4, 1, 'SGD', 1, 0, ''),
(3, 1, '1200', 200, 2, 'SGD', 1, 0, ''),
(4, 1, '4430', 200, 3, 'SGD', 1, 0, ''),
(5, 1, '5460', 200, 4, 'SGD', 1, 12, ''),
(6, 1, '4440', 500, 5, 'SGD', 1, 12, ''),
(7, 2, '5010', -200, 2, 'SGD', 1, 26, ''),
(8, 1, '5030', 20, 6, 'SGD', 1, 12, ''),
(9, 2, '4510', -25, 3, 'SGD', 1, 26, '');

-- --------------------------------------------------------

--
-- Table structure for table `bom`
--

CREATE TABLE IF NOT EXISTS `bom` (
  `id` int(11) NOT NULL,
  `parent` char(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `component` char(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `workcentre_added` int(11) NOT NULL DEFAULT '0',
  `loc_code` char(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `quantity` double NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `budget_trans`
--

CREATE TABLE IF NOT EXISTS `budget_trans` (
  `counter` int(11) NOT NULL,
  `type` smallint(6) NOT NULL DEFAULT '0',
  `type_no` bigint(16) NOT NULL DEFAULT '1',
  `tran_date` date NOT NULL DEFAULT '0000-00-00',
  `account` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `memo_` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `amount` double NOT NULL DEFAULT '0',
  `dimension_id` int(11) DEFAULT '0',
  `dimension2_id` int(11) DEFAULT '0',
  `person_type_id` int(11) DEFAULT NULL,
  `person_id` tinyblob
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `chart_class`
--

CREATE TABLE IF NOT EXISTS `chart_class` (
  `cid` varchar(3) COLLATE utf8_unicode_ci NOT NULL,
  `class_name` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ctype` tinyint(1) NOT NULL DEFAULT '0',
  `inactive` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `chart_class`
--

INSERT INTO `chart_class` (`cid`, `class_name`, `ctype`, `inactive`) VALUES
('1', 'Assets', 1, 0),
('2', 'Liabilities', 2, 0),
('3', 'Income', 4, 0),
('4', 'Costs', 6, 0);

-- --------------------------------------------------------

--
-- Table structure for table `chart_master`
--

CREATE TABLE IF NOT EXISTS `chart_master` (
  `account_code` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `account_code2` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `account_name` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `account_type` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `inactive` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `chart_master`
--

INSERT INTO `chart_master` (`account_code`, `account_code2`, `account_name`, `account_type`, `inactive`) VALUES
('1060', '', 'Bank', '1', 0),
('1065', '', 'Petty Cash', '1', 0),
('1200', '', 'Trade Debtors', '1', 0),
('1205', '', 'Allowance for doubtful accounts', '1', 0),
('1510', '', 'Inventory', '2', 0),
('1520', '', 'Stocks of Raw Materials', '2', 0),
('1530', '', 'Stocks of Work In Progress', '2', 0),
('1540', '', 'Stocks of Finsihed Goods', '2', 0),
('1550', '', 'Goods Received Clearing account', '2', 0),
('1820', '', 'Office Furniture &amp; Equipment', '3', 0),
('1825', '', 'Accum. Amort. -Furn. &amp; Equip.', '3', 0),
('1840', '', 'Vehicle', '3', 0),
('1845', '', 'Accum. Amort. -Vehicle', '3', 0),
('2100', '', 'Trade Creditor', '4', 0),
('2110', '', 'Accrued Income Tax - Federal', '4', 0),
('2120', '', 'Accrued Income Tax - State', '4', 0),
('2130', '', 'Accrued Franchise Tax', '4', 0),
('2140', '', 'Accrued Real &amp; Personal Prop Tax', '4', 0),
('2150', '', 'GST Output Tax', '4', 0),
('2160', '', 'Accrued Use Tax Payable', '4', 0),
('2210', '', 'Accrued Wages', '4', 0),
('2220', '', 'Accrued Comp Time', '4', 0),
('2230', '', 'Accrued Holiday Pay', '4', 0),
('2240', '', 'Accrued Vacation Pay', '4', 0),
('2310', '', 'Accr. Benefits - 401K', '4', 0),
('2320', '', 'Accr. Benefits - Stock Purchase', '4', 0),
('2330', '', 'Accr. Benefits - Med, Den', '4', 0),
('2340', '', 'Accr. Benefits - Payroll Taxes', '4', 0),
('2350', '', 'Accr. Benefits - Credit Union', '4', 0),
('2360', '', 'Accr. Benefits - Savings Bond', '4', 0),
('2370', '', 'Accr. Benefits - Garnish', '4', 0),
('2380', '', 'Accr. Benefits - Charity Cont.', '4', 0),
('2620', '', 'Bank Loans', '5', 0),
('2680', '', 'Loans from Shareholders', '5', 0),
('3350', '', 'Common Shares', '6', 0),
('3590', '', 'Retained Earnings - prior years', '7', 0),
('4010', '', 'Sales', '8', 0),
('4430', '', 'Shipping &amp; Handling', '9', 0),
('4440', '', 'Interest', '9', 0),
('4450', '', 'Foreign Exchange Gain', '9', 0),
('4500', '', 'Prompt Payment Discounts', '9', 0),
('4510', '', 'Discounts Given', '9', 0),
('5010', '', 'Cost of Goods Sold - Retail', '10', 0),
('5020', '', 'Material Usage Varaiance', '10', 0),
('5030', '', 'Consumable Materials', '10', 0),
('5040', '', 'Inventory Adjustment A/c', '10', 0),
('5050', '', 'Purchases of materials', '10', 0),
('5060', '', 'Discounts Received', '10', 0),
('5100', '', 'Postage &amp; Courier', '10', 0),
('5410', '', 'Wages &amp; Salaries', '11', 0),
('5420', '', 'Wages - Overtime', '11', 0),
('5430', '', 'Benefits - Comp Time', '11', 0),
('5440', '', 'Benefits - Payroll Taxes', '11', 0),
('5450', '', 'Benefits - Workers Comp', '11', 0),
('5460', '', 'Benefits - Pension', '11', 0),
('5470', '', 'Benefits - General Benefits', '11', 0),
('5510', '', 'Inc Tax Exp - Federal', '11', 0),
('5520', '', 'Inc Tax Exp - State', '11', 0),
('5530', '', 'Taxes - Real Estate', '11', 0),
('5540', '', 'Taxes - Personal Property', '11', 0),
('5550', '', 'Taxes - Franchise', '11', 0),
('5560', '', 'Taxes - Foreign Withholding', '11', 0),
('5610', '', 'Accounting &amp; Legal', '12', 0),
('5615', '', 'Advertising &amp; Promotions', '12', 0),
('5620', '', 'Bad Debts', '12', 0),
('5660', '', 'Amortization Expense', '12', 0),
('5685', '', 'Insurance', '12', 0),
('5690', '', 'Interest &amp; Bank Charges', '12', 0),
('5700', '', 'Office Supplies', '12', 0),
('5760', '', 'Rent', '12', 0),
('5765', '', 'Repair &amp; Maintenance', '12', 0),
('5780', '', 'Telephone', '12', 0),
('5785', '', 'Travel &amp; Entertainment', '12', 0),
('5790', '', 'Utilities', '12', 0),
('5795', '', 'Registrations', '12', 0),
('5800', '', 'Licenses', '12', 0),
('5810', '', 'Foreign Exchange Loss', '12', 0),
('9990', '', 'Year Profit/Loss', '12', 0),
('1300', '1300', 'GST Input Tax', '1', 0),
('5900', '5900', 'GST Expense (Not Claimable)', '12', 0),
('2152', '', 'GST Output Tax Zero Rated', '4', 0),
('1070', '', 'Public Bank Berhad', '1', 0),
('1071', '', 'Malayan Banking Berhad', '1', 0),
('4460', '', 'Divined Income', '9', 0),
('4011', '', 'Sales Commission', '8', 0),
('2154', '', 'Contra Account', '4', 0),
('1830', '', 'Computer &amp; Software', '3', 0),
('1835', '', 'Accum. Amort. - Computer &amp; Software', '3', 0),
('1201', '', 'Amount Loan To Director', '1', 0),
('4451', '', 'Rounding Difference', '9', 0),
('5710', '', 'Purchases', '12', 0),
('P1000', '', 'Petty Cash', '0', 0),
('1050', '', 'Bank USD', '1', 0),
('123456', '222', 'trial', '1', 0);

-- --------------------------------------------------------

--
-- Table structure for table `chart_types`
--

CREATE TABLE IF NOT EXISTS `chart_types` (
  `id` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `class_id` varchar(3) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `parent` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '-1',
  `inactive` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `chart_types`
--

INSERT INTO `chart_types` (`id`, `name`, `class_id`, `parent`, `inactive`) VALUES
('1', 'Current Assets', '1', '', 0),
('2', 'Inventory Assets', '1', '', 0),
('3', 'Capital Assets', '1', '', 0),
('4', 'Current Liabilities', '2', '', 0),
('5', 'Long Term Liabilities', '2', '', 0),
('6', 'Share Capital', '2', '', 0),
('7', 'Retained Earnings', '2', '', 0),
('8', 'Sales Revenue', '3', '', 0),
('9', 'Other Revenue', '3', '', 0),
('10', 'Cost of Goods Sold', '4', '', 0),
('11', 'Payroll Expenses', '4', '', 0),
('12', 'General &amp; Administrative expenses', '4', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `type` int(11) NOT NULL DEFAULT '0',
  `id` int(11) NOT NULL DEFAULT '0',
  `date_` date DEFAULT '0000-00-00',
  `memo_` tinytext COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`type`, `id`, `date_`, `memo_`) VALUES
(22, 1, '2016-08-09', 'Payment for Invoice #1 (SI001)'),
(22, 2, '2016-08-09', 'Payment for Invoice #2 (SI002)'),
(12, 3, '2016-08-09', 'Cash invoice 7'),
(20, 6, '2016-08-09', '\n'),
(22, 5, '2016-08-10', 'IN1235'),
(22, 6, '2016-08-10', 'IN1236'),
(22, 8, '2016-08-10', 'IV1008'),
(13, 8, '2016-08-10', 'Sales Quotation # 1'),
(12, 5, '2016-08-10', 'Cash invoice 8'),
(10, 8, '2016-08-10', 'Sales Quotation # 1'),
(12, 6, '2016-08-10', 'Cash invoice 9'),
(13, 10, '2016-08-10', 'Sales Quotation # 2'),
(10, 10, '2016-08-10', 'Sales Quotation # 2'),
(12, 7, '2016-08-10', 'Cash invoice 10'),
(22, 10, '2016-08-10', 'IV0810'),
(22, 11, '2016-08-10', 'IV1609'),
(12, 14, '2016-09-28', 'Cash invoice 17'),
(1, 5, '2017-02-21', 'test'),
(1, 6, '2017-02-21', 'test'),
(2, 3, '2017-02-21', 'test'),
(0, 1, '2017-02-21', 'test'),
(0, 2, '2017-02-21', 'test'),
(4, 1, '2017-02-22', 'Test'),
(12, 17, '2017-05-06', 'Cash invoice 20');

-- --------------------------------------------------------

--
-- Table structure for table `credit_status`
--

CREATE TABLE IF NOT EXISTS `credit_status` (
  `id` int(11) NOT NULL,
  `reason_description` char(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `dissallow_invoices` tinyint(1) NOT NULL DEFAULT '0',
  `inactive` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `credit_status`
--

INSERT INTO `credit_status` (`id`, `reason_description`, `dissallow_invoices`, `inactive`) VALUES
(1, 'Good History', 0, 0),
(3, 'No more work until payment received', 1, 0),
(4, 'In liquidation', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `crm_categories`
--

CREATE TABLE IF NOT EXISTS `crm_categories` (
  `id` int(11) NOT NULL COMMENT 'pure technical key',
  `type` varchar(20) COLLATE utf8_unicode_ci NOT NULL COMMENT 'contact type e.g. customer',
  `action` varchar(20) COLLATE utf8_unicode_ci NOT NULL COMMENT 'detailed usage e.g. department',
  `name` varchar(30) COLLATE utf8_unicode_ci NOT NULL COMMENT 'for category selector',
  `description` tinytext COLLATE utf8_unicode_ci NOT NULL COMMENT 'usage description',
  `system` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'nonzero for core system usage',
  `inactive` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `crm_categories`
--

INSERT INTO `crm_categories` (`id`, `type`, `action`, `name`, `description`, `system`, `inactive`) VALUES
(1, 'cust_branch', 'general', 'General', 'General contact data for customer branch (overrides company setting)', 1, 0),
(2, 'cust_branch', 'invoice', 'Invoices', 'Invoice posting (overrides company setting)', 1, 0),
(3, 'cust_branch', 'order', 'Orders', 'Order confirmation (overrides company setting)', 1, 0),
(4, 'cust_branch', 'delivery', 'Deliveries', 'Delivery coordination (overrides company setting)', 1, 0),
(5, 'customer', 'general', 'General', 'General contact data for customer', 1, 0),
(6, 'customer', 'order', 'Orders', 'Order confirmation', 1, 0),
(7, 'customer', 'delivery', 'Deliveries', 'Delivery coordination', 1, 0),
(8, 'customer', 'invoice', 'Invoices', 'Invoice posting', 1, 0),
(9, 'supplier', 'general', 'General', 'General contact data for supplier', 1, 0),
(10, 'supplier', 'order', 'Orders', 'Order confirmation', 1, 0),
(11, 'supplier', 'delivery', 'Deliveries', 'Delivery coordination', 1, 0),
(12, 'supplier', 'invoice', 'Invoices', 'Invoice posting', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `crm_contacts`
--

CREATE TABLE IF NOT EXISTS `crm_contacts` (
  `id` int(11) NOT NULL,
  `person_id` int(11) NOT NULL DEFAULT '0' COMMENT 'foreign key to crm_contacts',
  `type` varchar(20) COLLATE utf8_unicode_ci NOT NULL COMMENT 'foreign key to crm_categories',
  `action` varchar(20) COLLATE utf8_unicode_ci NOT NULL COMMENT 'foreign key to crm_categories',
  `entity_id` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'entity id in related class table'
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `crm_contacts`
--

INSERT INTO `crm_contacts` (`id`, `person_id`, `type`, `action`, `entity_id`) VALUES
(9, 9, 'cust_branch', 'general', '1'),
(11, 10, 'cust_branch', 'general', '2'),
(13, 11, 'cust_branch', 'general', '3'),
(15, 12, 'cust_branch', 'general', '4'),
(17, 13, 'cust_branch', 'general', '5'),
(19, 14, 'cust_branch', 'general', '6'),
(23, 17, 'cust_branch', 'general', '7'),
(25, 18, 'cust_branch', 'general', '8'),
(27, 19, 'cust_branch', 'general', '9'),
(30, 21, 'cust_branch', 'general', '10'),
(31, 22, 'cust_branch', 'general', '11'),
(33, 23, 'cust_branch', 'general', '12'),
(38, 27, 'cust_branch', 'general', '13'),
(42, 29, 'supplier', 'general', '1'),
(43, 30, 'supplier', 'general', '2'),
(44, 31, 'supplier', 'general', '3'),
(45, 32, 'supplier', 'general', '4'),
(46, 33, 'supplier', 'general', '5'),
(47, 34, 'supplier', 'general', '6'),
(48, 35, 'cust_branch', 'general', '15'),
(49, 35, 'customer', 'general', '2'),
(50, 36, 'cust_branch', 'general', '16'),
(51, 36, 'customer', 'general', '3'),
(52, 37, 'cust_branch', 'general', '17'),
(53, 37, 'customer', 'general', '4'),
(54, 38, 'cust_branch', 'general', '18'),
(55, 38, 'customer', 'general', '5'),
(56, 39, 'cust_branch', 'general', '19'),
(57, 39, 'customer', 'general', '6'),
(59, 40, 'customer', 'general', '7'),
(60, 41, 'supplier', 'general', '7'),
(61, 40, 'cust_branch', 'general', '20'),
(62, 42, 'cust_branch', 'general', '21'),
(63, 42, 'customer', 'general', '8');

-- --------------------------------------------------------

--
-- Table structure for table `crm_persons`
--

CREATE TABLE IF NOT EXISTS `crm_persons` (
  `id` int(11) NOT NULL,
  `ref` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `name2` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` tinytext COLLATE utf8_unicode_ci,
  `phone` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone2` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fax` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lang` char(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notes` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `inactive` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `crm_persons`
--

INSERT INTO `crm_persons` (`id`, `ref`, `name`, `name2`, `address`, `phone`, `phone2`, `fax`, `email`, `lang`, `notes`, `inactive`) VALUES
(1, 'S0001', '', '', '', '', '', '', '', '', '', 0),
(2, 'S0002', '', '', '', '', '', '', '', '', '', 0),
(3, 'S0003', '', '', '', '', '', '', '', '', '', 0),
(4, 'S0004', '', '', '', '', '', '', '', '', '', 0),
(5, 'S0005', '', '', '', '', '', '', '', '', '', 0),
(6, 'S0006', '', '', '', '', '', '', '', '', '', 0),
(7, 'S0007', '', '', '', '', '', '', '', '', '', 0),
(8, 'S0008', '', '', '', '', '', '', '', '', '', 0),
(9, 'Harvey Tomato Co Pte Ltd', 'C0002', '', '', '', '', '', '', '', '', 0),
(10, 'XYZ GmbH', 'C0004', '', '', '', '', '', '', '', '', 0),
(11, 'Hitamoto Bank', 'C0006', '', '', '', '', '', '', '', '', 0),
(12, 'XYZ Pte Ltd', 'C0008', '', '', '', '', '', '', '', '', 0),
(13, 'Bee Hiang Pte Ltd', 'C0010', '', '', '', '', '', '', '', '', 0),
(14, 'Macrohard Inc.', 'C0012', '', '', '', '', '', '', '', '', 0),
(15, 'ABC', '', '', '', '', '', '', '', '', '', 0),
(16, 'EEE', '', '', '', '', '', '', '', '', '', 0),
(17, 'xyz company', 'xyz', '', 'Singapore', '', '', '', '', '', '', 0),
(18, 'AIA Trading Pte Ltd', 'AIA Trading', '', '768 Upper Serangoon Road, Singapore', '', '', '', '', '', '', 0),
(19, 'AIA Trading Pte Ltd', 'AIA Trading', '', '768 Upper Serangoon Road, Singapore', '', '', '', '', '', '', 0),
(20, 'ADC Mobile', 'Mr.Chin Hwee', '', '', '', '', '', 'chinhwee@a2000.net', '', '', 0),
(21, 'Mr.Quang', 'Mr.Quang', '', '', '', '', '', 'quang@a2000.net', '', '', 0),
(22, 'C0001', 'Harvey Tomato Co Pte Ltd USD', '', '', '', '', '', '', '', '', 0),
(23, 'C0003', 'XYZ GmbH USD', '', '', '', '', '', '', '', '', 0),
(24, 'Storage', '', '', '', '', '', '', '', '', '', 0),
(25, 'XYZ G', '', '', '', '', '', '', '', '', '', 0),
(26, 'XYZ G', '', '', '', '', '', '', '', '', '', 0),
(27, 'AAA Trading Sdn Bhd', 'AAA Trading', '', '3-3, Subang Business Centre, Usj 9/5Q, Uep Subang Jaya, 47620, Petaling Jaya, Selangor, 47620, Malaysia', '', '', '', '', '', '', 0),
(29, 'A11', '', '', '', '', '', '', '', '', '', 0),
(30, 'Demo Supplier 01', '', '', '', '', '', '', '', '', '', 0),
(31, 'Demo Supplier 02', '', '', '', '', '', '', '', '', '', 0),
(32, 'Demo Supplier 03', '', '', '', '', '', '', '', '', '', 0),
(33, 'Demo Supplier 04', '', '', '', '', '', '', '', '', '', 0),
(34, 'Demo Supplier 05', '', '', '', '', '', '', '', '', '', 0),
(35, 'Demo Customer 01', 'Customer 01', '', 'Ang Mo Kio, Singapore', '', '', '', '', '', '', 0),
(36, 'Demo Customer 02', 'Customer 02', '', 'Ang Mo Kio, Singapore', '', '', '', '', '', '', 0),
(37, 'Demo Customer 03', 'Customer 03', '', 'Ang Mo Kio, Singapore', '', '', '', '', '', '', 0),
(38, 'Demo Customer 04', 'Customer 04', '', 'Ang Mo Kio, Singapore', '', '', '', '', '', '', 0),
(39, 'Demo Customer 05', 'Customer 05', '', 'Ang Mo Kio, Singapore', '', '', '', '', '', '', 0),
(40, 'CustomerB', 'Customer B', '', 'Singapore ', '', '', '', '', '', '', 0),
(41, 'Supplier M', '', '', 'SG', '', '', '', '', '', '', 0),
(42, 'Customer JJ', 'CustJJ ', '', 'Changi ', '', '', '', '', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `currencies`
--

CREATE TABLE IF NOT EXISTS `currencies` (
  `currency` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `curr_abrev` char(3) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `curr_symbol` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `country` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `hundreds_name` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `auto_update` tinyint(1) NOT NULL DEFAULT '1',
  `inactive` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `currencies`
--

INSERT INTO `currencies` (`currency`, `curr_abrev`, `curr_symbol`, `country`, `hundreds_name`, `auto_update`, `inactive`) VALUES
('US Dollars', 'USD', 'US$', 'United States', 'Cents', 1, 0),
('Singapore Dollars', 'SGD', 'SG$', 'Singapore', 'Cents', 1, 0),
('Malaysian Ringgit', 'MYR', 'MYR', 'Malaysia', 'Sen', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `cust_allocations`
--

CREATE TABLE IF NOT EXISTS `cust_allocations` (
  `id` int(11) NOT NULL,
  `amt` double unsigned DEFAULT NULL,
  `date_alloc` date NOT NULL DEFAULT '0000-00-00',
  `trans_no_from` int(11) DEFAULT NULL,
  `trans_type_from` int(11) DEFAULT NULL,
  `trans_no_to` int(11) DEFAULT NULL,
  `trans_type_to` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cust_allocations`
--

INSERT INTO `cust_allocations` (`id`, `amt`, `date_alloc`, `trans_no_from`, `trans_type_from`, `trans_no_to`, `trans_type_to`) VALUES
(1, 10000, '2016-08-09', 2, 12, 1, 95),
(2, 1070, '2016-08-09', 3, 12, 7, 10),
(3, 535, '2016-08-09', 4, 12, 6, 10),
(4, 1000, '2016-08-09', 5, 12, 8, 10),
(5, 963, '2016-08-09', 6, 12, 9, 10),
(6, 2140, '2016-08-09', 7, 12, 10, 10),
(7, 128.4, '2016-08-10', 8, 12, 1, 10),
(9, 535, '2016-08-10', 10, 12, 3, 10),
(10, 1551.5, '2016-08-10', 11, 12, 4, 10),
(11, 668.75, '2016-08-10', 12, 12, 5, 10),
(12, 246.1, '2016-08-10', 9, 12, 2, 10),
(13, 30000, '2016-08-15', 13, 12, 2, 95),
(14, 214, '2016-09-28', 14, 12, 17, 10),
(15, 1070, '2017-02-23', 16, 12, 19, 10),
(16, 237.54, '2017-05-06', 17, 12, 20, 10);

-- --------------------------------------------------------

--
-- Table structure for table `cust_branch`
--

CREATE TABLE IF NOT EXISTS `cust_branch` (
  `branch_code` int(11) NOT NULL,
  `debtor_no` int(11) NOT NULL DEFAULT '0',
  `br_name` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `branch_ref` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `br_address` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `area` int(11) DEFAULT NULL,
  `salesman` int(11) NOT NULL DEFAULT '0',
  `contact_name` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `default_location` varchar(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tax_group_id` int(11) DEFAULT NULL,
  `sales_account` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sales_discount_account` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `receivables_account` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `payment_discount_account` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `default_ship_via` int(11) NOT NULL DEFAULT '1',
  `disable_trans` tinyint(4) NOT NULL DEFAULT '0',
  `br_post_address` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `group_no` int(11) NOT NULL DEFAULT '0',
  `notes` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `inactive` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cust_branch`
--

INSERT INTO `cust_branch` (`branch_code`, `debtor_no`, `br_name`, `branch_ref`, `br_address`, `area`, `salesman`, `contact_name`, `default_location`, `tax_group_id`, `sales_account`, `sales_discount_account`, `receivables_account`, `payment_discount_account`, `default_ship_via`, `disable_trans`, `br_post_address`, `group_no`, `notes`, `inactive`) VALUES
(21, 8, 'Customer JJ', 'CustJJ ', 'Changi ', 1, 4, '', 'DEF', 1, '', '4510', '1200', '4500', 1, 0, 'Changi ', 0, '', 0),
(20, 7, 'CustomerB', 'Customer B', 'Singapore ', 1, 4, '', 'DEF', 1, '', '4510', '1200', '4500', 1, 0, 'Singapore ', 0, '', 0),
(19, 6, 'Demo Customer 05', 'Customer 05', 'Ang Mo Kio, Singapore', 1, 4, '', 'DEF', 1, '', '4510', '1200', '4500', 1, 0, 'Ang Mo Kio, Singapore', 0, '', 0),
(18, 5, 'Demo Customer 04', 'Customer 04', 'Ang Mo Kio, Singapore', 1, 4, '', 'DEF', 1, '', '4510', '1200', '4500', 1, 0, 'Ang Mo Kio, Singapore', 0, '', 0),
(15, 2, 'Demo Customer 01', 'Customer 01', 'Ang Mo Kio, Singapore', 1, 4, '', 'DEF', 1, '', '4510', '1200', '4500', 1, 0, 'Ang Mo Kio, Singapore', 0, '', 0),
(16, 3, 'Demo Customer 02', 'Customer 02', 'Ang Mo Kio, Singapore', 1, 4, '', 'DEF', 1, '', '4510', '1200', '4500', 1, 0, 'Ang Mo Kio, Singapore', 0, '', 0),
(17, 4, 'Demo Customer 03', 'Customer 03', 'Ang Mo Kio, Singapore', 1, 4, '', 'DEF', 1, '', '4510', '1200', '4500', 1, 0, 'Ang Mo Kio, Singapore', 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `dashboard_reminders`
--

CREATE TABLE IF NOT EXISTS `dashboard_reminders` (
  `id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `next_date` date NOT NULL,
  `description` text,
  `frequency` varchar(20) NOT NULL,
  `param` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `dashboard_widgets`
--

CREATE TABLE IF NOT EXISTS `dashboard_widgets` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `app` varchar(50) NOT NULL,
  `column_id` int(11) NOT NULL,
  `sort_no` int(11) NOT NULL,
  `collapsed` tinyint(4) NOT NULL,
  `widget` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `param` text
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `dashboard_widgets`
--

INSERT INTO `dashboard_widgets` (`id`, `user_id`, `app`, `column_id`, `sort_no`, `collapsed`, `widget`, `description`, `param`) VALUES
(1, 14, 'orders', 4, 0, 1, 'customers', 'Sales', '{&quot;top&quot;:&quot;10&quot;,&quot;data_filter&quot;:&quot;&quot;,&quot;graph_type&quot;:&quot;Table&quot;}');

-- --------------------------------------------------------

--
-- Table structure for table `data_incorrect`
--

CREATE TABLE IF NOT EXISTS `data_incorrect` (
  `id` int(11) NOT NULL,
  `table` char(50) NOT NULL,
  `type` int(5) NOT NULL,
  `trans_no` int(11) NOT NULL,
  `data` text,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `comment` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `debtors_master`
--

CREATE TABLE IF NOT EXISTS `debtors_master` (
  `debtor_no` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `debtor_ref` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `address` tinytext COLLATE utf8_unicode_ci,
  `tax_id` varchar(55) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `curr_code` char(3) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sales_type` int(11) NOT NULL DEFAULT '1',
  `dimension_id` int(11) NOT NULL DEFAULT '0',
  `dimension2_id` int(11) NOT NULL DEFAULT '0',
  `credit_status` int(11) NOT NULL DEFAULT '0',
  `payment_terms` int(11) DEFAULT NULL,
  `discount` double NOT NULL DEFAULT '0',
  `pymt_discount` double NOT NULL DEFAULT '0',
  `credit_limit` float NOT NULL DEFAULT '1000',
  `notes` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  `customer_tax_id` int(11) DEFAULT NULL,
  `industry_code` int(11) DEFAULT NULL,
  `msic` char(10) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `debtors_master`
--

INSERT INTO `debtors_master` (`debtor_no`, `name`, `debtor_ref`, `address`, `tax_id`, `curr_code`, `sales_type`, `dimension_id`, `dimension2_id`, `credit_status`, `payment_terms`, `discount`, `pymt_discount`, `credit_limit`, `notes`, `inactive`, `customer_tax_id`, `industry_code`, `msic`) VALUES
(2, 'Demo Customer 01', 'Customer 01', 'Ang Mo Kio, Singapore', '123456781', 'SGD', 2, 0, 0, 1, 5, 0, 0, 1000, '', 0, -1, NULL, ''),
(3, 'Demo Customer 02', 'Customer 02', 'Ang Mo Kio, Singapore', '123456782', 'SGD', 2, 0, 0, 1, 5, 0, 0, 1000, '', 0, -1, NULL, ''),
(4, 'Demo Customer 03', 'Customer 03', 'Ang Mo Kio, Singapore', '123456783', 'SGD', 2, 0, 0, 1, 5, 0, 0, 1000, '', 0, -1, NULL, ''),
(5, 'Demo Customer 04', 'Customer 04', 'Ang Mo Kio, Singapore', '123456784', 'SGD', 2, 0, 0, 1, 5, 0, 0, 1000, '', 0, -1, NULL, ''),
(6, 'Demo Customer 05', 'Customer 05', 'Ang Mo Kio, Singapore', '123456785', 'SGD', 2, 0, 0, 1, 5, 0, 0, 1000, '', 0, -1, NULL, ''),
(7, 'CustomerB', 'Customer B', 'Singapore', '', 'SGD', 2, 0, 0, 1, 5, 0, 0, 50000, '', 0, -1, NULL, ''),
(8, 'Customer JJ', 'CustJJ ', 'Changi ', '', 'SGD', 2, 0, 0, 1, 4, 0, 0, 20000, '', 0, -1, NULL, '');

-- --------------------------------------------------------

--
-- Table structure for table `debtor_trans`
--

CREATE TABLE IF NOT EXISTS `debtor_trans` (
  `trans_no` int(11) unsigned NOT NULL DEFAULT '0',
  `type` smallint(6) unsigned NOT NULL DEFAULT '0',
  `version` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `debtor_no` int(11) unsigned DEFAULT NULL,
  `branch_code` int(11) NOT NULL DEFAULT '-1',
  `tran_date` date NOT NULL DEFAULT '0000-00-00',
  `due_date` date NOT NULL DEFAULT '0000-00-00',
  `reference` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tpe` int(11) NOT NULL DEFAULT '0',
  `order_` int(11) NOT NULL DEFAULT '0',
  `ov_amount` double NOT NULL DEFAULT '0',
  `ov_gst` double NOT NULL DEFAULT '0',
  `ov_freight` double NOT NULL DEFAULT '0',
  `ov_freight_tax` double NOT NULL DEFAULT '0',
  `ov_discount` double NOT NULL DEFAULT '0',
  `alloc` double NOT NULL DEFAULT '0',
  `rate` double NOT NULL DEFAULT '1',
  `ship_via` int(11) DEFAULT NULL,
  `dimension_id` int(11) NOT NULL DEFAULT '0',
  `dimension2_id` int(11) NOT NULL DEFAULT '0',
  `payment_terms` int(11) DEFAULT NULL,
  `cheque` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cust_ref2` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `debtor_trans`
--

INSERT INTO `debtor_trans` (`trans_no`, `type`, `version`, `debtor_no`, `branch_code`, `tran_date`, `due_date`, `reference`, `tpe`, `order_`, `ov_amount`, `ov_gst`, `ov_freight`, `ov_freight_tax`, `ov_discount`, `alloc`, `rate`, `ship_via`, `dimension_id`, `dimension2_id`, `payment_terms`, `cheque`, `reason`, `cust_ref2`) VALUES
(2, 1, 0, 5, 18, '2016-09-12', '0000-00-00', 'J/PV/0002', 0, 0, 200, 0, 0, 0, 0, 0, 1, 0, 0, 0, NULL, '', '', NULL),
(1, 10, 0, 2, 15, '2016-08-10', '2016-08-15', 'IV 0001', 2, 1, 120, 8.4, 0, 0, 0, 128.4, 1, 1, 0, 0, 5, NULL, NULL, NULL),
(2, 10, 0, 3, 16, '2016-08-11', '2016-08-20', 'IV 0002', 2, 2, 230, 16.1, 0, 0, 0, 246.1, 1, 1, 0, 0, 5, NULL, NULL, NULL),
(3, 10, 0, 4, 17, '2016-07-10', '2016-09-08', 'IV 0003', 2, 3, 500, 35, 0, 0, 0, 535, 1, 1, 0, 0, 5, NULL, NULL, NULL),
(4, 10, 0, 5, 18, '2016-08-09', '2016-09-08', 'IV 0004', 2, 4, 1450, 101.5, 0, 0, 0, 1551.5, 1, 1, 0, 0, 5, NULL, NULL, NULL),
(5, 10, 0, 6, 19, '2016-08-09', '2016-09-08', 'IV 0005', 2, 5, 625, 43.75, 0, 0, 0, 668.75, 1, 1, 0, 0, 5, NULL, NULL, NULL),
(6, 10, 0, 7, 20, '2016-08-09', '2016-09-08', 'IV 0006', 2, 6, 500, 35, 0, 0, 0, 535, 1, 1, 0, 0, 5, NULL, NULL, NULL),
(7, 10, 0, 8, 21, '2016-08-09', '2016-08-09', 'IV 0007', 2, 7, 1000, 70, 0, 0, 0, 1070, 1, 1, 0, 0, 4, NULL, NULL, NULL),
(8, 10, 0, 8, 21, '2016-08-10', '2016-08-10', 'IV 0008', 2, 8, 1000, 0, 0, 0, 0, 1000, 1, 1, 0, 0, 4, NULL, NULL, NULL),
(9, 10, 0, 8, 21, '2016-08-10', '2016-08-10', 'IV 0009', 2, 10, 900, 63, 0, 0, 0, 963, 1, 1, 0, 0, 4, NULL, NULL, NULL),
(10, 10, 0, 8, 21, '2016-08-10', '2016-08-10', 'IV 0010', 2, 9, 2000, 140, 0, 0, 0, 2140, 1, 1, 0, 0, 4, NULL, NULL, NULL),
(11, 10, 0, 7, 20, '2016-08-10', '2016-09-09', 'IV 0011', 2, 12, 760, 53.2, 0, 0, 0, 0, 1, 1, 0, 0, 5, NULL, NULL, NULL),
(12, 10, 0, 7, 20, '2016-08-10', '2016-09-09', 'IV 0012', 2, 13, 1000, 70, 0, 0, 0, 0, 1, 1, 0, 0, 5, NULL, NULL, NULL),
(13, 10, 0, 7, 20, '2016-08-10', '2016-09-09', 'IV 0013', 2, 14, 2000, 140, 0, 0, 0, 0, 1, 1, 0, 0, 5, NULL, NULL, NULL),
(14, 10, 0, 7, 20, '2016-08-26', '2016-09-25', 'IV 0014', 2, 16, 800, 56, 0, 0, 0, 0, 1, 1, 0, 0, 5, NULL, NULL, NULL),
(15, 10, 0, 3, 16, '2016-08-29', '2016-09-28', 'IV 0015', 2, 17, 130, 0, 0, 0, 0, 0, 1, 1, 0, 0, 5, NULL, NULL, NULL),
(16, 10, 0, 3, 16, '2016-09-12', '2016-10-12', 'IV 0016', 2, 18, 145, 0, 0, 0, 0, 0, 1, 1, 0, 0, 5, NULL, NULL, NULL),
(17, 10, 0, 8, 21, '2016-09-28', '2016-09-28', 'IV 0017', 2, 19, 200, 14, 0, 0, 0, 214, 1, 1, 0, 0, 4, NULL, NULL, NULL),
(18, 10, 0, 4, 17, '2017-02-16', '2017-03-18', 'IV 0018', 2, 24, 699, 48.93, 0, 0, 0, 0, 1, 1, 0, 0, 5, NULL, NULL, NULL),
(19, 10, 0, 5, 18, '2017-02-23', '2017-03-25', 'IV 0019', 2, 25, 1000, 70, 0, 0, 0, 1070, 1, 1, 0, 0, 5, NULL, NULL, NULL),
(20, 10, 0, 8, 21, '2017-05-06', '2017-05-06', 'IV 0020', 2, 26, 0, 15.54, 0, 0, 0, 237.54, 1, 1, 0, 0, 4, NULL, NULL, NULL),
(1, 12, 2, 2, 15, '2016-08-09', '0000-00-00', 'COR 001', 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, NULL, 'PC004', '', NULL),
(2, 12, 0, 7, 20, '2016-08-09', '0000-00-00', 'COR 002', 0, 0, 10000, 0, 0, 0, 0, 10000, 1, 0, 0, 0, NULL, 'OBB0908', '', NULL),
(3, 12, 0, 8, 21, '2016-08-09', '0000-00-00', 'COR 003', 0, 0, 1070, 0, 0, 0, 0, 1070, 1, 0, 0, 0, NULL, '', '', NULL),
(4, 12, 0, 7, 20, '2016-08-09', '0000-00-00', 'COR 004', 0, 0, 535, 0, 0, 0, 0, 535, 1, 0, 0, 0, NULL, '', '', NULL),
(5, 12, 0, 8, 21, '2016-08-10', '0000-00-00', 'COR 005', 0, 0, 1000, 0, 0, 0, 0, 1000, 1, 0, 0, 0, NULL, '', '', NULL),
(6, 12, 0, 8, 21, '2016-08-10', '0000-00-00', 'COR 006', 0, 0, 963, 0, 0, 0, 0, 963, 1, 0, 0, 0, NULL, '', '', NULL),
(7, 12, 0, 8, 21, '2016-08-10', '0000-00-00', 'COR 007', 0, 0, 2140, 0, 0, 0, 0, 2140, 1, 0, 0, 0, NULL, '', '', NULL),
(8, 12, 0, 2, 15, '2016-08-10', '0000-00-00', 'COR 008', 0, 0, 128.4, 0, 0, 0, 0, 128.4, 1, 0, 0, 0, NULL, '', '', NULL),
(9, 12, 0, 3, 16, '2016-08-10', '0000-00-00', 'COR 009', 0, 0, 246.1, 0, 0, 0, 0, 246.1, 1, 0, 0, 0, NULL, '', '', NULL),
(10, 12, 0, 4, 17, '2016-08-10', '0000-00-00', 'COR 010', 0, 0, 535, 0, 0, 0, 0, 535, 1, 0, 0, 0, NULL, '', '', NULL),
(11, 12, 0, 5, 18, '2016-08-10', '0000-00-00', 'COR 011', 0, 0, 1551.5, 0, 0, 0, 0, 1551.5, 1, 0, 0, 0, NULL, '', '', NULL),
(12, 12, 0, 6, 19, '2016-08-10', '0000-00-00', 'COR 012', 0, 0, 668.75, 0, 0, 0, 0, 668.75, 1, 0, 0, 0, NULL, '', '', NULL),
(13, 12, 0, 8, 21, '2016-08-16', '0000-00-00', 'COR 013', 0, 0, 30000, 0, 0, 0, 0, 30000, 1, 0, 0, 0, NULL, '', '', NULL),
(14, 12, 0, 8, 21, '2016-09-28', '0000-00-00', 'COR 014', 0, 0, 214, 0, 0, 0, 0, 214, 1, 0, 0, 0, NULL, '', '', NULL),
(15, 12, 0, 8, 21, '2016-09-28', '0000-00-00', 'COR 015', 0, 0, 190, 0, 0, 0, 10, 0, 1, 0, 0, 0, NULL, '', '', NULL),
(16, 12, 0, 5, 18, '2017-02-23', '0000-00-00', 'COR 016', 0, 0, 1070, 0, 0, 0, 0, 1070, 1, 0, 0, 0, NULL, '', '', NULL),
(17, 12, 0, 8, 21, '2017-05-06', '0000-00-00', 'COR 017', 0, 0, 237.54, 0, 0, 0, 0, 237.54, 1, 0, 0, 0, NULL, '', '', NULL),
(1, 13, 2, 2, 15, '2016-08-10', '2016-08-15', 'auto', 2, 1, 120, 8.4, 0, 0, 0, 0, 1, 1, 0, 0, 5, '', '', NULL),
(2, 13, 2, 3, 16, '2016-08-11', '2016-08-20', 'auto', 2, 2, 230, 16.1, 0, 0, 0, 0, 1, 1, 0, 0, 5, '', '', NULL),
(3, 13, 2, 4, 17, '2016-07-10', '2016-09-08', 'auto', 2, 3, 500, 35, 0, 0, 0, 0, 1, 1, 0, 0, 5, '', '', NULL),
(4, 13, 2, 5, 18, '2016-08-09', '2016-09-08', 'auto', 2, 4, 1450, 101.5, 0, 0, 0, 0, 1, 1, 0, 0, 5, '', '', NULL),
(5, 13, 2, 6, 19, '2016-08-09', '2016-09-08', 'auto', 2, 5, 625, 43.75, 0, 0, 0, 0, 1, 1, 0, 0, 5, '', '', NULL),
(6, 13, 2, 7, 20, '2016-08-09', '2016-09-08', 'auto', 2, 6, 500, 35, 0, 0, 0, 0, 1, 1, 0, 0, 5, '', '', NULL),
(7, 13, 2, 8, 21, '2016-08-09', '2016-08-09', 'auto', 2, 7, 1000, 70, 0, 0, 0, 0, 1, 1, 0, 0, 4, '', '', NULL),
(8, 13, 2, 8, 21, '2016-08-10', '2016-08-11', 'auto', 2, 8, 1000, 0, 0, 0, 0, 0, 1, 1, 0, 0, 4, '', '', NULL),
(9, 13, 1, 8, 21, '2016-08-10', '2016-08-10', 'auto', 2, 10, 900, 63, 0, 0, 0, 0, 1, 1, 0, 0, 4, '', '', NULL),
(10, 13, 1, 8, 21, '2016-08-10', '2016-08-11', 'auto', 2, 9, 2000, 140, 0, 0, 0, 0, 1, 1, 0, 0, 4, '', '', NULL),
(11, 13, 1, 7, 20, '2016-08-10', '2016-09-09', 'auto', 2, 12, 760, 53.2, 0, 0, 0, 0, 1, 1, 0, 0, 5, '', '', NULL),
(12, 13, 1, 7, 20, '2016-08-10', '2016-09-09', 'auto', 2, 13, 1000, 70, 0, 0, 0, 0, 1, 1, 0, 0, 5, '', '', NULL),
(13, 13, 2, 7, 20, '2016-08-10', '2016-09-09', 'IV 0013', 2, 14, 2000, 140, 0, 0, 0, 0, 1, 1, 0, 0, 5, '', '', NULL),
(14, 13, 1, 7, 20, '2016-08-26', '2016-09-25', 'auto', 2, 16, 800, 56, 0, 0, 0, 0, 1, 1, 0, 0, 5, '', '', NULL),
(15, 13, 1, 3, 16, '2016-08-29', '2016-09-28', 'auto', 2, 17, 130, 0, 0, 0, 0, 0, 1, 1, 0, 0, 5, '', '', NULL),
(16, 13, 2, 3, 16, '2016-09-12', '2016-10-12', 'IV 0016', 2, 18, 145, 0, 0, 0, 0, 0, 1, 1, 0, 0, 5, '', '', NULL),
(17, 13, 1, 8, 21, '2016-09-28', '2016-09-28', 'auto', 2, 19, 200, 14, 0, 0, 0, 0, 1, 1, 0, 0, 4, '', '', NULL),
(18, 13, 0, 3, 16, '2017-02-16', '2017-02-17', 'auto', 2, 20, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 5, '', '', NULL),
(19, 13, 0, 4, 17, '2017-02-16', '2017-02-17', 'auto', 2, 21, 250, 17.5, 0, 0, 0, 0, 1, 1, 0, 0, 5, '', '', NULL),
(20, 13, 0, 4, 17, '2017-02-16', '2017-02-17', 'auto', 2, 22, 150, 10.5, 0, 0, 0, 0, 1, 1, 0, 0, 5, '', '', NULL),
(21, 13, 1, 4, 17, '2017-02-16', '2017-03-18', 'auto', 2, 24, 699, 48.93, 0, 0, 0, 0, 1, 1, 0, 0, 5, '', '', NULL),
(22, 13, 1, 5, 18, '2017-02-23', '2017-03-25', 'auto', 2, 25, 1000, 70, 0, 0, 0, 0, 1, 1, 0, 0, 5, '', '', NULL),
(23, 13, 1, 8, 21, '2017-05-06', '2017-05-06', 'auto', 2, 26, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 4, '', '', NULL),
(1, 95, 0, 7, 0, '2015-12-31', '2015-12-31', 'IV3112', 1, 0, 10000, 0, 0, 0, 0, 10000, 1, NULL, 0, 0, NULL, NULL, NULL, NULL),
(2, 95, 0, 8, 0, '2015-12-31', '2015-12-31', 'OB2015', 1, 0, 30000, 0, 0, 0, 0, 30000, 1, NULL, 0, 0, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `debtor_trans_details`
--

CREATE TABLE IF NOT EXISTS `debtor_trans_details` (
  `id` int(11) NOT NULL,
  `debtor_trans_no` int(11) DEFAULT NULL,
  `debtor_trans_type` int(11) DEFAULT NULL,
  `stock_id` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `gl_code` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` tinytext COLLATE utf8_unicode_ci,
  `unit_price` double NOT NULL DEFAULT '0',
  `unit_tax` double NOT NULL DEFAULT '0',
  `quantity` double NOT NULL DEFAULT '0',
  `discount_percent` double NOT NULL DEFAULT '0',
  `standard_cost` double NOT NULL DEFAULT '0',
  `qty_done` double NOT NULL DEFAULT '0',
  `src_id` int(11) NOT NULL,
  `tax_type_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `debtor_trans_details`
--

INSERT INTO `debtor_trans_details` (`id`, `debtor_trans_no`, `debtor_trans_type`, `stock_id`, `gl_code`, `description`, `unit_price`, `unit_tax`, `quantity`, `discount_percent`, `standard_cost`, `qty_done`, `src_id`, `tax_type_id`) VALUES
(1, 1, 13, 'SP01', NULL, 'Stock Product 01', 120, 0, 1, 0, 100, 1, 1, 54),
(2, 1, 10, 'SP01', NULL, 'Stock Product 01', 120, 8.4, 1, 0, 100, 0, 1, 54),
(3, 2, 13, 'SP02', NULL, 'Stock Product 02', 230, 0, 1, 0, 200, 1, 2, 54),
(4, 2, 10, 'SP02', NULL, 'Stock Product 02', 230, 16.1, 1, 0, 200, 0, 3, 54),
(5, 3, 13, 'SP03', NULL, 'Stock Product 03', 250, 0, 2, 0, 150, 2, 3, 54),
(6, 3, 10, 'SP03', NULL, 'Stock Product 03', 250, 35, 2, 0, 150, 0, 5, 54),
(7, 4, 13, 'SP04', NULL, 'Stock product 04', 290, 0, 5, 0, 120, 5, 4, 54),
(8, 4, 10, 'SP04', NULL, 'Stock product 04', 290, 101.5, 5, 0, 120, 0, 7, 54),
(9, 5, 13, 'SP05', NULL, 'Stock product 05', 125, 0, 5, 0, 80, 5, 5, 54),
(10, 5, 10, 'SP05', NULL, 'Stock product 05', 125, 43.75, 5, 0, 80, 0, 9, 54),
(11, 6, 13, 'SP11', NULL, 'Service Product 01', 500, 0, 1, 0, 0, 1, 6, 54),
(12, 6, 10, 'SP11', NULL, 'Service Product 01', 500, 35, 1, 0, 0, 0, 11, 54),
(13, 7, 13, 'SP01', NULL, 'Stock Product 01', 1000, 0, 1, 0, 100, 1, 7, 54),
(14, 7, 10, 'SP01', NULL, 'Stock Product 01', 1000, 70, 1, 0, 100, 0, 13, 54),
(15, 8, 13, 'SP14', NULL, 'Service Product 04', 1000, 0, 1, 0, 0, 0, 9, 0),
(16, 8, 10, 'SP14', NULL, 'Service Product 04', 1000, 0, 1, 0, 0, 0, 0, 0),
(17, 9, 13, 'AAA', NULL, 'AAA', 900, 0, 1, 0, 652.57142857143, 1, 12, 54),
(18, 9, 10, 'AAA', NULL, 'AAA', 900, 63, 1, 0, 652.57142857143, 0, 17, 54),
(19, 10, 13, 'AAA', NULL, 'AAA', 2000, 0, 1, 0, 652.57142857143, 0, 11, 54),
(20, 10, 10, 'AAA', NULL, 'AAA', 2000, 140, 1, 0, 0, 0, 0, 54),
(21, 11, 13, 'AAA', NULL, 'AAA', 560, 0, 1, 0, 690.12244897959, 1, 15, 54),
(22, 11, 13, 'Maint001', NULL, 'Maintenance ', 200, 0, 1, 0, 0, 1, 16, 54),
(23, 11, 10, 'AAA', NULL, 'AAA', 560, 39.2, 1, 0, 690.12244897959, 0, 21, 54),
(24, 11, 10, 'Maint001', NULL, 'Maintenance ', 200, 14, 1, 0, 0, 0, 22, 54),
(25, 12, 13, 'AAA', NULL, 'AAA', 1000, 0, 1, 0, 659.59183673469, 1, 17, 54),
(26, 12, 10, 'AAA', NULL, 'AAA', 1000, 70, 1, 0, 659.59183673469, 0, 25, 54),
(31, 13, 13, 'SP01', NULL, 'Stock Product 01', 2000, 0, 1, 0, 920, 0, 0, 54),
(32, 13, 10, 'SP01', NULL, 'Stock Product 01', 2000, 140, 1, 0, 920, 0, 0, 54),
(33, 14, 13, 'SP01', NULL, 'Stock Product 01', 800, 0, 1, 0, 649.33333333333, 1, 21, 54),
(34, 14, 10, 'SP01', NULL, 'Stock Product 01', 800, 56, 1, 0, 649.33333333333, 0, 33, 54),
(35, 15, 13, 'SP11', NULL, 'Service Product 01', 50, 0, 1, 0, 0, 1, 22, 49),
(36, 15, 13, 'Maint001', NULL, 'Maintenance ', 80, 0, 1, 0, 0, 1, 23, 0),
(37, 15, 10, 'SP11', NULL, 'Service Product 01', 50, 0, 1, 0, 0, 0, 35, 49),
(38, 15, 10, 'Maint001', NULL, 'Maintenance ', 80, 0, 1, 0, 0, 0, 36, 0),
(43, 16, 13, 'SP01', NULL, 'Stock Product 01', 20, 0, 1, 0, 649.33333333333, 0, 0, 0),
(44, 16, 13, 'AAA', NULL, 'AAA', 10, 0, 10, 0, 648.14285714285, 0, 0, 0),
(45, 16, 13, 'SP09', NULL, 'Stock Product 09', 5, 0, 5, 0, 0, 0, 0, 0),
(46, 16, 10, 'SP01', NULL, 'Stock Product 01', 20, 0, 1, 0, 649.33333333333, 0, 0, 0),
(47, 16, 10, 'AAA', NULL, 'AAA', 10, 0, 10, 0, 648.14285714285, 0, 0, 0),
(48, 16, 10, 'SP09', NULL, 'Stock Product 09', 5, 0, 5, 0, 0, 0, 0, 0),
(49, 17, 13, 'SP01', NULL, 'Stock Product 01', 20, 0, 10, 0, 649.33333333333, 10, 26, 54),
(50, 17, 10, 'SP01', NULL, 'Stock Product 01', 20, 14, 10, 0, 649.33333333333, 0, 49, 54),
(51, 18, 13, 'SP01', NULL, 'Stock Product 01', 0, 0, 1, 0, 649.33333333333, 0, 29, 30),
(52, 19, 13, 'SP01', NULL, 'Stock Product 01', 250, 0, 1, 0, 649.33333333333, 0, 30, 26),
(53, 20, 13, 'AAA', NULL, 'AAA', 150, 0, 1, 0, 648.14285714285, 0, 31, 30),
(54, 21, 13, 'AAA', NULL, 'AAA', 699, 0, 1, 0, 648.14285714285, 1, 33, 30),
(55, 18, 10, 'AAA', NULL, 'AAA', 699, 48.93, 1, 0, 648.14285714285, 0, 54, 30),
(56, 22, 13, 'SP01', NULL, 'Stock Product 01', 1000, 0, 1, 0, 649.33333333333, 1, 34, 30),
(57, 19, 10, 'SP01', NULL, 'Stock Product 01', 1000, 70, 1, 0, 649.33333333333, 0, 56, 30),
(58, 20, 10, '', '4010', NULL, 222, 15.54, 0, 0, 0, 0, 0, 30);

-- --------------------------------------------------------

--
-- Table structure for table `dimensions`
--

CREATE TABLE IF NOT EXISTS `dimensions` (
  `id` int(11) NOT NULL,
  `reference` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `name` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `type_` tinyint(1) NOT NULL DEFAULT '1',
  `closed` tinyint(1) NOT NULL DEFAULT '0',
  `date_` date NOT NULL DEFAULT '0000-00-00',
  `due_date` date NOT NULL DEFAULT '0000-00-00'
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `dimensions`
--

INSERT INTO `dimensions` (`id`, `reference`, `name`, `type_`, `closed`, `date_`, `due_date`) VALUES
(1, '1', 'Support', 1, 0, '2014-06-21', '2020-07-11'),
(2, '2', 'Development', 1, 0, '2014-06-21', '2014-06-21');

-- --------------------------------------------------------

--
-- Table structure for table `exchange_rates`
--

CREATE TABLE IF NOT EXISTS `exchange_rates` (
  `id` int(11) NOT NULL,
  `curr_code` char(3) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `rate_buy` double NOT NULL DEFAULT '0',
  `rate_sell` double NOT NULL DEFAULT '0',
  `date_` date NOT NULL DEFAULT '0000-00-00'
) ENGINE=MyISAM AUTO_INCREMENT=91 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `exchange_rates`
--

INSERT INTO `exchange_rates` (`id`, `curr_code`, `rate_buy`, `rate_sell`, `date_`) VALUES
(42, 'SGD', 1, 1, '2015-11-03'),
(43, 'SGD', 1, 1, '2015-07-16'),
(44, 'SGD', 1, 1, '2015-07-29'),
(45, 'SGD', 1, 1, '2015-08-21'),
(46, 'SGD', 1, 1, '2015-08-22'),
(47, 'SGD', 1, 1, '2015-08-25'),
(73, 'USD', 1.35, 1.35, '2015-02-28'),
(50, 'SGD', 1, 1, '2015-10-02'),
(51, 'SGD', 1, 1, '2015-10-09'),
(52, 'SGD', 1, 1, '2015-10-17'),
(53, 'SGD', 1, 1, '2015-10-23'),
(54, 'SGD', 1, 1, '2015-11-01'),
(55, 'SGD', 1, 1, '2015-11-02'),
(56, 'SGD', 1, 1, '2015-10-29'),
(57, 'SGD', 1, 1, '2015-10-16'),
(58, 'SGD', 1, 1, '2015-10-19'),
(59, 'SGD', 1, 1, '2015-10-31'),
(76, 'MYR', 0.3, 0.3, '2015-11-10'),
(77, 'MYR', 0.3, 0.3, '2015-11-30'),
(78, 'MYR', 0.3, 0.3, '2015-12-01'),
(71, 'USD', 1.26, 1.26, '2015-02-26'),
(72, 'USD', 1.2, 1.2, '2015-02-27'),
(80, 'MYR', 0.3, 0.3, '2015-12-12'),
(79, 'MYR', 0.3, 0.3, '2015-11-11'),
(75, 'USD', 1.35, 1.35, '2015-11-07'),
(74, 'USD', 1.26, 1.26, '2015-11-06'),
(81, 'MYR', 0.3, 0.3, '2015-12-11'),
(82, 'USD', 1.35, 1.35, '2015-11-17'),
(83, 'USD', 1.26, 1.26, '2015-11-16'),
(90, 'USD', 1.25, 1.25, '2015-11-26'),
(85, 'USD', 1.35, 1.35, '2015-02-02'),
(86, 'USD', 1.2, 1.2, '2015-02-03'),
(87, 'USD', 1.35, 1.35, '2015-11-20'),
(88, 'USD', 1.22, 1.22, '2015-11-25'),
(89, 'USD', 1.25, 1.25, '2015-11-01');

-- --------------------------------------------------------

--
-- Table structure for table `fiscal_year`
--

CREATE TABLE IF NOT EXISTS `fiscal_year` (
  `id` int(11) NOT NULL,
  `begin` date DEFAULT '0000-00-00',
  `end` date DEFAULT '0000-00-00',
  `closed` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `fiscal_year`
--

INSERT INTO `fiscal_year` (`id`, `begin`, `end`, `closed`) VALUES
(2, '2015-01-01', '2015-12-31', 1),
(3, '2017-01-01', '2017-12-31', 0),
(4, '2018-01-01', '2018-12-31', 0),
(5, '2019-01-01', '2019-01-31', 0),
(6, '2016-01-01', '2016-12-31', 0);

-- --------------------------------------------------------

--
-- Table structure for table `gl_trans`
--

CREATE TABLE IF NOT EXISTS `gl_trans` (
  `counter` int(11) NOT NULL,
  `type` smallint(6) NOT NULL DEFAULT '0',
  `type_no` bigint(16) NOT NULL DEFAULT '1',
  `tran_date` date NOT NULL DEFAULT '0000-00-00',
  `account` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `memo_` tinytext COLLATE utf8_unicode_ci,
  `amount` double NOT NULL DEFAULT '0',
  `dimension_id` int(11) NOT NULL DEFAULT '0',
  `dimension2_id` int(11) NOT NULL DEFAULT '0',
  `person_type_id` int(11) DEFAULT NULL,
  `person_id` tinyblob,
  `gst` int(11) NOT NULL,
  `openning` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB AUTO_INCREMENT=399 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `gl_trans`
--

INSERT INTO `gl_trans` (`counter`, `type`, `type_no`, `tran_date`, `account`, `memo_`, `amount`, `dimension_id`, `dimension2_id`, `person_type_id`, `person_id`, `gst`, `openning`) VALUES
(1, 25, 31, '2016-08-09', '1510', 'SP01', 100, 0, 0, 3, 0x32, 0, ''),
(2, 25, 31, '2016-08-09', '5011', '', -100, 0, 0, 3, '', 0, ''),
(3, 20, 1, '2016-08-09', '2100', '', 0, 0, 0, 3, 0x32, 0, ''),
(4, 20, 1, '2016-08-09', '5011', '', 0, 0, 0, 3, 0x32, 0, ''),
(5, 20, 1, '2016-08-09', '1300', '', 0, 0, 0, 3, 0x32, 0, ''),
(6, 20, 1, '2016-08-09', '1200', '', 0, 0, 0, 3, 0x32, 0, ''),
(7, 20, 1, '2016-08-09', '1300', '', 0, 0, 0, 3, 0x32, 0, ''),
(8, 20, 1, '2016-08-09', '2100', '', 0, 0, 0, 3, 0x32, 0, ''),
(9, 20, 1, '2016-08-09', '1550', '', 0, 0, 0, 3, 0x32, 0, ''),
(10, 20, 1, '2016-08-09', '1300', '', 0, 0, 0, 3, 0x32, 0, ''),
(11, 20, 1, '2016-08-09', '2100', '', 0, 0, 0, 3, 0x32, 0, ''),
(12, 20, 1, '2016-08-09', '1550', '', 0, 0, 0, 3, 0x32, 0, ''),
(13, 20, 1, '2016-08-09', '1300', '', 0, 0, 0, 3, 0x32, 0, ''),
(14, 20, 1, '2016-08-09', '2100', '', 0, 0, 0, 3, 0x32, 0, ''),
(15, 25, 32, '2016-08-01', '1510', 'SP02', 2000, 0, 0, 3, 0x33, 0, ''),
(16, 25, 32, '2016-08-01', '1550', '', -2000, 0, 0, 3, '', 0, ''),
(17, 20, 2, '2016-08-01', '2100', '', -2140, 0, 0, 3, 0x33, 0, ''),
(18, 20, 2, '2016-08-01', '1550', '', 2000, 0, 0, 3, 0x33, 0, ''),
(19, 20, 2, '2016-08-01', '1300', '', 140, 0, 0, 3, 0x33, 0, ''),
(20, 25, 33, '2016-08-02', '1510', 'SP03', 1500, 0, 0, 3, 0x34, 0, ''),
(21, 25, 33, '2016-08-02', '1550', '', -1500, 0, 0, 3, '', 0, ''),
(22, 20, 3, '2016-08-02', '2100', '', -1605, 0, 0, 3, 0x34, 0, ''),
(23, 20, 3, '2016-08-02', '1550', '', 1500, 0, 0, 3, 0x34, 0, ''),
(24, 20, 3, '2016-08-02', '1300', '', 105, 0, 0, 3, 0x34, 0, ''),
(25, 25, 34, '2016-07-01', '1510', 'SP04', 600, 0, 0, 3, 0x35, 0, ''),
(26, 25, 34, '2016-07-01', '1550', '', -600, 0, 0, 3, '', 0, ''),
(27, 20, 4, '2016-07-01', '2100', '', -642, 0, 0, 3, 0x35, 0, ''),
(28, 20, 4, '2016-07-01', '1550', '', 600, 0, 0, 3, 0x35, 0, ''),
(29, 20, 4, '2016-07-01', '1300', '', 42, 0, 0, 3, 0x35, 0, ''),
(30, 25, 35, '2016-05-01', '1510', 'SP05', 1600, 0, 0, 3, 0x36, 0, ''),
(31, 25, 35, '2016-05-01', '1550', '', -1600, 0, 0, 3, '', 0, ''),
(32, 20, 5, '2016-05-01', '2100', '', -1712, 0, 0, 3, 0x36, 0, ''),
(33, 20, 5, '2016-05-01', '1550', '', 1600, 0, 0, 3, 0x36, 0, ''),
(34, 20, 5, '2016-05-01', '1300', '', 112, 0, 0, 3, 0x36, 0, ''),
(35, 13, 1, '2016-08-10', '5010', '', 100, 0, 0, 2, 0x32, 0, ''),
(36, 13, 1, '2016-08-10', '1510', '', -100, 0, 0, 2, 0x32, 0, ''),
(37, 10, 1, '2016-08-10', '4010', '', -120, 0, 0, 2, 0x32, 0, ''),
(38, 10, 1, '2016-08-10', '2150', '', -8.4, 0, 0, 2, 0x32, 0, ''),
(39, 10, 1, '2016-08-10', '1200', '', 128.4, 0, 0, 2, 0x32, 0, ''),
(40, 10, 1, '2016-08-10', '4451', '', 0, 0, 0, 2, 0x32, 0, ''),
(41, 13, 2, '2016-08-11', '5010', '', 200, 0, 0, 2, 0x33, 0, ''),
(42, 13, 2, '2016-08-11', '1510', '', -200, 0, 0, 2, 0x33, 0, ''),
(43, 10, 2, '2016-08-11', '4010', '', -230, 0, 0, 2, 0x33, 0, ''),
(44, 10, 2, '2016-08-11', '2150', '', -16.1, 0, 0, 2, 0x33, 0, ''),
(45, 10, 2, '2016-08-11', '1200', '', 246.1, 0, 0, 2, 0x33, 0, ''),
(46, 10, 2, '2016-08-11', '4451', '', 0, 0, 0, 2, 0x33, 0, ''),
(47, 13, 3, '2016-07-10', '5010', '', 300, 0, 0, 2, 0x34, 0, ''),
(48, 13, 3, '2016-07-10', '1510', '', -300, 0, 0, 2, 0x34, 0, ''),
(49, 10, 3, '2016-07-10', '4010', '', -500, 0, 0, 2, 0x34, 0, ''),
(50, 10, 3, '2016-07-10', '2150', '', -35, 0, 0, 2, 0x34, 0, ''),
(51, 10, 3, '2016-07-10', '1200', '', 535, 0, 0, 2, 0x34, 0, ''),
(52, 10, 3, '2016-07-10', '4451', '', 0, 0, 0, 2, 0x34, 0, ''),
(53, 13, 4, '2016-08-09', '5010', '', 600, 0, 0, 2, 0x35, 0, ''),
(54, 13, 4, '2016-08-09', '1510', '', -600, 0, 0, 2, 0x35, 0, ''),
(55, 10, 4, '2016-08-09', '4010', '', -1450, 0, 0, 2, 0x35, 0, ''),
(56, 10, 4, '2016-08-09', '2150', '', -101.5, 0, 0, 2, 0x35, 0, ''),
(57, 10, 4, '2016-08-09', '1200', '', 1551.5, 0, 0, 2, 0x35, 0, ''),
(58, 10, 4, '2016-08-09', '4451', '', 0, 0, 0, 2, 0x35, 0, ''),
(59, 13, 5, '2016-08-09', '5010', '', 400, 0, 0, 2, 0x36, 0, ''),
(60, 13, 5, '2016-08-09', '1510', '', -400, 0, 0, 2, 0x36, 0, ''),
(61, 10, 5, '2016-08-09', '4010', '', -625, 0, 0, 2, 0x36, 0, ''),
(62, 10, 5, '2016-08-09', '2150', '', -43.75, 0, 0, 2, 0x36, 0, ''),
(63, 10, 5, '2016-08-09', '1200', '', 668.75, 0, 0, 2, 0x36, 0, ''),
(64, 10, 5, '2016-08-09', '4451', '', 0, 0, 0, 2, 0x36, 0, ''),
(65, 22, 1, '2016-08-09', '2100', '', 107, 0, 0, 3, 0x32, 0, ''),
(66, 22, 1, '2016-08-09', '5690', '', 107, 0, 0, 3, 0x32, 0, ''),
(67, 22, 1, '2016-08-09', '1060', '', -214, 0, 0, 3, 0x32, 0, ''),
(68, 22, 2, '2016-08-09', '2100', '', 2140, 0, 0, 3, 0x33, 0, ''),
(69, 22, 2, '2016-08-09', '5690', '', 2140, 0, 0, 3, 0x33, 0, ''),
(70, 22, 2, '2016-08-09', '1060', '', -4280, 0, 0, 3, 0x33, 0, ''),
(71, 12, 1, '2016-08-09', '1060', '', 0, 0, 0, 2, 0x32, 0, ''),
(72, 12, 1, '2016-08-09', '1200', '', 0, 0, 0, 2, 0x32, 0, ''),
(73, 12, 1, '2016-08-09', '5690', '', 0, 0, 0, 2, 0x32, 0, ''),
(74, 97, 0, '2015-12-31', '1060', '', 50000, 0, 0, NULL, NULL, 0, ''),
(75, 97, 0, '2015-12-31', '1065', '', 15000, 0, 0, NULL, NULL, 0, ''),
(76, 97, 0, '2015-12-31', '1200', '', 40000, 0, 0, NULL, NULL, 0, ''),
(77, 97, 0, '2015-12-31', '1070', '', 30000, 0, 0, NULL, NULL, 0, ''),
(78, 97, 0, '2015-12-31', '2100', '', -25000, 0, 0, NULL, NULL, 0, ''),
(79, 97, 0, '2015-12-31', '2620', '', -110000, 0, 0, NULL, NULL, 0, ''),
(80, 96, 1, '2015-12-31', 'P1000', '', 0, 0, 0, NULL, 0x537570706c6965724d, 0, 'supplier-1'),
(81, 96, 1, '2015-12-31', '2100', '', 0, 0, 0, NULL, 0x537570706c6965724d, 0, 'supplier-1'),
(82, 96, 1, '2015-12-31', 'P1000', '', 0, 0, 0, NULL, 0x537570706c6965724d, 0, 'supplier-1'),
(83, 96, 1, '2015-12-31', '2100', '', 0, 0, 0, NULL, 0x537570706c6965724d, 0, 'supplier-1'),
(84, 96, 1, '2015-12-31', 'P1000', '', 0, 0, 0, NULL, 0x537570706c6965724d, 0, 'supplier-1'),
(85, 96, 1, '2015-12-31', '2100', '', 0, 0, 0, NULL, 0x537570706c6965724d, 0, 'supplier-1'),
(86, 96, 1, '2015-12-31', 'P1000', '', 0, 0, 0, NULL, 0x537570706c6965724d, 0, 'supplier-1'),
(87, 96, 1, '2015-12-31', '2100', '', 0, 0, 0, NULL, 0x537570706c6965724d, 0, 'supplier-1'),
(88, 96, 1, '2015-12-31', 'P1000', '', -5000, 0, 0, NULL, 0x537570706c6965724d, 0, 'supplier-1'),
(89, 96, 1, '2015-12-31', '2100', '', 5000, 0, 0, NULL, 0x537570706c6965724d, 0, 'supplier-1'),
(90, 96, 1, '2015-12-31', 'P1000', '', 5000, 0, 0, NULL, 0x537570706c6965724d, 0, 'supplier-1'),
(91, 96, 1, '2015-12-31', '2100', '', -5000, 0, 0, NULL, 0x537570706c6965724d, 0, 'supplier-1'),
(92, 95, 1, '2015-12-31', '4010', '', -10000, 0, 0, NULL, 0x437573746f6d657242, 0, 'customer-2'),
(93, 95, 1, '2015-12-31', '1200', '', 10000, 0, 0, NULL, 0x437573746f6d657242, 0, 'customer-2'),
(94, 95, 1, '2015-12-31', '4010', '', 10000, 0, 0, NULL, 0x437573746f6d657242, 0, 'customer-2'),
(95, 95, 1, '2015-12-31', '1200', '', -10000, 0, 0, NULL, 0x437573746f6d657242, 0, 'customer-2'),
(96, 10, 6, '2016-08-09', '4010', '', -500, 0, 0, 2, 0x37, 0, ''),
(97, 10, 6, '2016-08-09', '2150', '', -35, 0, 0, 2, 0x37, 0, ''),
(98, 10, 6, '2016-08-09', '1200', '', 535, 0, 0, 2, 0x37, 0, ''),
(99, 10, 6, '2016-08-09', '4451', '', 0, 0, 0, 2, 0x37, 0, ''),
(100, 12, 2, '2016-08-09', '1060', '', 10000, 0, 0, 2, 0x37, 0, ''),
(101, 12, 2, '2016-08-09', '1200', '', -10000, 0, 0, 2, 0x37, 0, ''),
(102, 13, 7, '2016-08-09', '5010', '', 100, 0, 0, 2, 0x38, 0, ''),
(103, 13, 7, '2016-08-09', '1510', '', -100, 0, 0, 2, 0x38, 0, ''),
(104, 10, 7, '2016-08-09', '4010', '', -1000, 0, 0, 2, 0x38, 0, ''),
(105, 10, 7, '2016-08-09', '2150', '', -70, 0, 0, 2, 0x38, 0, ''),
(106, 10, 7, '2016-08-09', '1200', '', 1070, 0, 0, 2, 0x38, 0, ''),
(107, 10, 7, '2016-08-09', '4451', '', 0, 0, 0, 2, 0x38, 0, ''),
(108, 12, 3, '2016-08-09', 'P1000', '', 1070, 0, 0, 2, 0x38, 0, ''),
(109, 12, 3, '2016-08-09', '1200', '', -1070, 0, 0, 2, 0x38, 0, ''),
(110, 12, 4, '2016-08-09', '1060', '', 535, 0, 0, 2, 0x37, 0, ''),
(111, 12, 4, '2016-08-09', '1200', '', -535, 0, 0, 2, 0x37, 0, ''),
(112, 25, 36, '2016-08-09', '1510', 'SP01', 10000, 0, 0, 3, 0x37, 0, ''),
(113, 25, 36, '2016-08-09', '1550', '', -10000, 0, 0, 3, '', 0, ''),
(114, 20, 6, '2016-08-09', '2100', '', -10700, 0, 0, 3, 0x37, 0, ''),
(115, 20, 6, '2016-08-09', '1550', '', 10000, 0, 0, 3, 0x37, 0, ''),
(116, 20, 6, '2016-08-09', '1300', '', 700, 0, 0, 3, 0x37, 0, ''),
(117, 22, 3, '2016-08-09', '2100', '', 15700, 0, 0, 3, 0x37, 0, ''),
(118, 22, 3, '2016-08-09', '1060', '', -15700, 0, 0, 3, 0x37, 0, ''),
(119, 95, 2, '2015-12-31', '4010', '', -30000, 0, 0, NULL, 0x437573746f6d6572204a4a, 0, 'customer-3'),
(120, 95, 2, '2015-12-31', '1200', '', 30000, 0, 0, NULL, 0x437573746f6d6572204a4a, 0, 'customer-3'),
(121, 95, 2, '2015-12-31', '4010', '', 30000, 0, 0, NULL, 0x437573746f6d6572204a4a, 0, 'customer-3'),
(122, 95, 2, '2015-12-31', '1200', '', -30000, 0, 0, NULL, 0x437573746f6d6572204a4a, 0, 'customer-3'),
(123, 25, 37, '2016-08-10', '1510', 'AAA', 1000, 0, 0, 3, 0x33, 0, ''),
(124, 25, 37, '2016-08-10', '1510', 'SP02', 600, 0, 0, 3, 0x33, 0, ''),
(125, 25, 37, '2016-08-10', '1550', '', -1600, 0, 0, 3, '', 0, ''),
(126, 20, 7, '2016-08-10', '2100', '', -1712, 0, 0, 3, 0x33, 0, ''),
(127, 20, 7, '2016-08-10', '1550', '', 1000, 0, 0, 3, 0x33, 0, ''),
(128, 20, 7, '2016-08-10', '1300', '', 70, 0, 0, 3, 0x33, 0, ''),
(129, 20, 7, '2016-08-10', '1550', '', 600, 0, 0, 3, 0x33, 0, ''),
(130, 20, 7, '2016-08-10', '1300', '', 42, 0, 0, 3, 0x33, 0, ''),
(131, 22, 4, '2016-08-10', '2100', '', 1712, 0, 0, 3, 0x33, 0, ''),
(132, 22, 4, '2016-08-10', '5060', '', -12, 0, 0, 3, 0x33, 0, ''),
(133, 22, 4, '2016-08-10', '5690', '', 1712, 0, 0, 3, 0x33, 0, ''),
(134, 22, 4, '2016-08-10', '1060', '', -3412, 0, 0, 3, 0x33, 0, ''),
(135, 25, 38, '2016-08-10', '1510', 'AAA', 1000, 0, 0, 3, 0x33, 0, ''),
(136, 25, 38, '2016-08-10', '1550', '', -1000, 0, 0, 3, '', 0, ''),
(137, 20, 8, '2016-08-10', '2100', '', -1070, 0, 0, 3, 0x33, 0, ''),
(138, 20, 8, '2016-08-10', '1550', '', 1000, 0, 0, 3, 0x33, 0, ''),
(139, 20, 8, '2016-08-10', '1300', '', 70, 0, 0, 3, 0x33, 0, ''),
(140, 22, 5, '2016-08-10', '2100', '', 1070, 0, 0, 3, 0x33, 0, ''),
(141, 22, 5, '2016-08-10', '5060', '', -70, 0, 0, 3, 0x33, 0, ''),
(142, 22, 5, '2016-08-10', '1060', '', -1000, 0, 0, 3, 0x33, 0, ''),
(143, 25, 39, '2016-08-10', '1510', 'AAA', 800, 0, 0, 3, 0x34, 0, ''),
(144, 25, 39, '2016-08-10', '1550', '', -800, 0, 0, 3, '', 0, ''),
(145, 20, 9, '2016-08-10', '2100', '', -856, 0, 0, 3, 0x34, 0, ''),
(146, 20, 9, '2016-08-10', '1550', '', 800, 0, 0, 3, 0x34, 0, ''),
(147, 20, 9, '2016-08-10', '1300', '', 56, 0, 0, 3, 0x34, 0, ''),
(148, 22, 6, '2016-08-10', '2100', '', 856, 0, 0, 3, 0x34, 0, ''),
(149, 22, 6, '2016-08-10', '5060', '', -6, 0, 0, 3, 0x34, 0, ''),
(150, 22, 6, '2016-08-10', '1060', '', -850, 0, 0, 3, 0x34, 0, ''),
(151, 22, 7, '2016-08-10', '2100', '', 1605, 0, 0, 3, 0x34, 0, ''),
(152, 22, 7, '2016-08-10', '1060', '', -1605, 0, 0, 3, 0x34, 0, ''),
(153, 25, 40, '2016-08-10', '1510', 'AAA', 568, 0, 0, 3, 0x32, 0, ''),
(154, 25, 40, '2016-08-10', '1550', '', -568, 0, 0, 3, '', 0, ''),
(155, 20, 10, '2016-08-10', '2100', '', -568, 0, 0, 3, 0x32, 0, ''),
(156, 20, 10, '2016-08-10', '1550', '', 568, 0, 0, 3, 0x32, 0, ''),
(157, 20, 10, '2016-08-10', '1300', '', 0, 0, 0, 3, 0x32, 0, ''),
(158, 25, 41, '2016-08-10', '1510', 'SP02', 4000, 0, 0, 3, 0x37, 0, ''),
(159, 25, 41, '2016-08-10', '1550', '', -4000, 0, 0, 3, '', 0, ''),
(160, 25, 42, '2016-08-10', '1510', 'SP07', 88, 0, 0, 3, 0x35, 0, ''),
(161, 25, 42, '2016-08-10', '1510', 'SP08', 168, 0, 0, 3, 0x35, 0, ''),
(162, 25, 42, '2016-08-10', '1550', '', -256, 0, 0, 3, '', 0, ''),
(163, 20, 11, '2016-08-10', '2100', '', -4280, 0, 0, 3, 0x37, 0, ''),
(164, 20, 11, '2016-08-10', '1550', '', 4000, 0, 0, 3, 0x37, 0, ''),
(165, 20, 11, '2016-08-10', '1300', '', 280, 0, 0, 3, 0x37, 0, ''),
(166, 22, 8, '2016-08-10', '2100', '', 4280, 0, 0, 3, 0x37, 0, ''),
(167, 22, 8, '2016-08-10', '1060', '', -4280, 0, 0, 3, 0x37, 0, ''),
(168, 25, 43, '2016-08-10', '1510', 'AAA', 800, 0, 0, 3, 0x35, 0, ''),
(169, 25, 43, '2016-08-10', '1550', '', -800, 0, 0, 3, '', 0, ''),
(170, 20, 12, '2016-08-10', '2100', '', -856, 0, 0, 3, 0x35, 0, ''),
(171, 20, 12, '2016-08-10', '1550', '', 800, 0, 0, 3, 0x35, 0, ''),
(172, 20, 12, '2016-08-10', '1300', '', 56, 0, 0, 3, 0x35, 0, ''),
(173, 10, 8, '2016-08-10', '4010', '', 0, 0, 0, 2, 0x38, 0, ''),
(174, 10, 8, '2016-08-10', '1200', '', 0, 0, 0, 2, 0x38, 0, ''),
(175, 10, 8, '2016-08-10', '4451', '', 0, 0, 0, 2, 0x38, 0, ''),
(176, 12, 5, '2016-08-10', 'P1000', '', 1000, 0, 0, 2, 0x38, 0, ''),
(177, 12, 5, '2016-08-10', '1200', '', -1000, 0, 0, 2, 0x38, 0, ''),
(178, 10, 8, '2016-08-10', '4010', '', -1000, 0, 0, 2, 0x38, 0, ''),
(179, 10, 8, '2016-08-10', '1200', '', 1000, 0, 0, 2, 0x38, 0, ''),
(180, 10, 8, '2016-08-10', '4451', '', 0, 0, 0, 2, 0x38, 0, ''),
(181, 25, 44, '2016-08-10', '1510', 'AAA', 400, 0, 0, 3, 0x34, 0, ''),
(182, 25, 44, '2016-08-10', '1550', '', -400, 0, 0, 3, '', 0, ''),
(183, 20, 13, '2016-08-10', '2100', '', -428, 0, 0, 3, 0x34, 0, ''),
(184, 20, 13, '2016-08-10', '1550', '', 400, 0, 0, 3, 0x34, 0, ''),
(185, 20, 13, '2016-08-10', '1300', '', 28, 0, 0, 3, 0x34, 0, ''),
(186, 13, 9, '2016-08-10', '5010', '', 652.57, 0, 0, 2, 0x38, 0, ''),
(187, 13, 9, '2016-08-10', '1510', '', -652.57, 0, 0, 2, 0x38, 0, ''),
(188, 10, 9, '2016-08-10', '4010', '', -900, 0, 0, 2, 0x38, 0, ''),
(189, 10, 9, '2016-08-10', '2150', '', -63, 0, 0, 2, 0x38, 0, ''),
(190, 10, 9, '2016-08-10', '1200', '', 963, 0, 0, 2, 0x38, 0, ''),
(191, 10, 9, '2016-08-10', '4451', '', 0, 0, 0, 2, 0x38, 0, ''),
(192, 12, 6, '2016-08-10', 'P1000', '', 963, 0, 0, 2, 0x38, 0, ''),
(193, 12, 6, '2016-08-10', '1200', '', -963, 0, 0, 2, 0x38, 0, ''),
(194, 13, 10, '2016-08-10', '5010', '', 652.57, 0, 0, 2, 0x38, 0, ''),
(195, 13, 10, '2016-08-10', '1510', '', -652.57, 0, 0, 2, 0x38, 0, ''),
(196, 10, 10, '2016-08-10', '4010', '', -2000, 0, 0, 2, 0x38, 0, ''),
(197, 10, 10, '2016-08-10', '2150', '', -140, 0, 0, 2, 0x38, 0, ''),
(198, 10, 10, '2016-08-10', '1200', '', 2140, 0, 0, 2, 0x38, 0, ''),
(199, 10, 10, '2016-08-10', '4451', '', 0, 0, 0, 2, 0x38, 0, ''),
(200, 12, 7, '2016-08-10', 'P1000', '', 2140, 0, 0, 2, 0x38, 0, ''),
(201, 12, 7, '2016-08-10', '1200', '', -2140, 0, 0, 2, 0x38, 0, ''),
(202, 1, 1, '2016-08-10', '5700', 'Office Supplies', 100, 0, 0, 0, 0x6f666669636520737570706c696573, 46, ''),
(203, 1, 1, '2016-08-10', '1300', '', 7, 0, 0, 0, 0x6f666669636520737570706c696573, 0, ''),
(204, 1, 1, '2016-08-10', 'P1000', '', -107, 0, 0, 0, 0x6f666669636520737570706c696573, 0, ''),
(205, 21, 1, '2016-08-10', '2100', '', 4280, 0, 0, 3, 0x37, 0, ''),
(206, 21, 1, '2016-08-10', '1510', '', -4000, 0, 0, 3, 0x37, 0, ''),
(207, 21, 1, '2016-08-10', '1300', '', -280, 0, 0, 3, 0x37, 0, ''),
(208, 20, 1, '2016-08-09', '1550', '', 100, 0, 0, 3, 0x32, 0, ''),
(209, 20, 1, '2016-08-09', '1300', '', 7, 0, 0, 3, 0x32, 0, ''),
(210, 20, 1, '2016-08-09', '2100', '', -107, 0, 0, 3, 0x32, 0, ''),
(211, 12, 8, '2016-08-10', '1060', '', 128.4, 0, 0, 2, 0x32, 0, ''),
(212, 12, 8, '2016-08-10', '1200', '', -128.4, 0, 0, 2, 0x32, 0, ''),
(213, 22, 9, '2016-08-10', '2100', '', 568, 0, 0, 3, 0x32, 0, ''),
(214, 22, 9, '2016-08-10', '1060', '', -568, 0, 0, 3, 0x32, 0, ''),
(215, 25, 45, '2016-08-10', '1510', 'AAA', 1000, 0, 0, 3, 0x33, 0, ''),
(216, 25, 45, '2016-08-10', '1550', '', -1000, 0, 0, 3, '', 0, ''),
(217, 20, 14, '2016-08-10', '2100', '', -1000, 0, 0, 3, 0x33, 0, ''),
(218, 20, 14, '2016-08-10', '1550', '', 1000, 0, 0, 3, 0x33, 0, ''),
(219, 20, 14, '2016-08-10', '', '', 0, 0, 0, 3, 0x33, 0, ''),
(220, 22, 10, '2016-08-10', '2100', '', 1000, 0, 0, 3, 0x33, 0, ''),
(221, 22, 10, '2016-08-10', '1060', '', -1000, 0, 0, 3, 0x33, 0, ''),
(222, 20, 15, '2016-08-10', '2100', '', -2140, 0, 0, 3, 0x32, 0, ''),
(223, 20, 15, '2016-08-10', '5710', '', 2000, 0, 0, 3, 0x32, 0, ''),
(224, 20, 15, '2016-08-10', '1300', '', 140, 0, 0, 3, 0x32, 0, ''),
(225, 22, 11, '2016-08-10', '2100', '', 2140, 0, 0, 3, 0x32, 0, ''),
(226, 22, 11, '2016-08-10', '1060', '', -2140, 0, 0, 3, 0x32, 0, ''),
(227, 25, 47, '2016-08-10', '1510', 'SP01', 200, 0, 0, 3, 0x32, 0, ''),
(228, 25, 47, '2016-08-10', '1550', '', -200, 0, 0, 3, '', 0, ''),
(229, 20, 16, '2016-08-10', '2100', '', -214, 0, 0, 3, 0x32, 0, ''),
(230, 20, 16, '2016-08-10', '1550', '', 200, 0, 0, 3, 0x32, 0, ''),
(231, 20, 16, '2016-08-10', '1300', '', 14, 0, 0, 3, 0x32, 0, ''),
(232, 12, 9, '2016-08-10', '1060', '', 246.1, 0, 0, 2, 0x33, 0, ''),
(233, 12, 9, '2016-08-10', '1200', '', -246.1, 0, 0, 2, 0x33, 0, ''),
(234, 12, 10, '2016-08-10', '1060', '', 535, 0, 0, 2, 0x34, 0, ''),
(235, 12, 10, '2016-08-10', '1200', '', -535, 0, 0, 2, 0x34, 0, ''),
(236, 25, 48, '2016-08-10', '1510', 'AAA', 568, 0, 0, 3, 0x32, 0, ''),
(237, 25, 48, '2016-08-10', '1550', '', -568, 0, 0, 3, '', 0, ''),
(238, 20, 17, '2016-08-10', '2100', '', -607.76, 0, 0, 3, 0x32, 0, ''),
(239, 20, 17, '2016-08-10', '1550', '', 568, 0, 0, 3, 0x32, 0, ''),
(240, 20, 17, '2016-08-10', '1300', '', 39.76, 0, 0, 3, 0x32, 0, ''),
(241, 12, 11, '2016-08-10', '1060', '', 1551.5, 0, 0, 2, 0x35, 0, ''),
(242, 12, 11, '2016-08-10', '1200', '', -1551.5, 0, 0, 2, 0x35, 0, ''),
(243, 12, 12, '2016-08-10', '1060', '', 668.75, 0, 0, 2, 0x36, 0, ''),
(244, 12, 12, '2016-08-10', '1200', '', -668.75, 0, 0, 2, 0x36, 0, ''),
(245, 13, 11, '2016-08-10', '5010', '', 690.12, 0, 0, 2, 0x37, 0, ''),
(246, 13, 11, '2016-08-10', '1510', '', -690.12, 0, 0, 2, 0x37, 0, ''),
(247, 10, 11, '2016-08-10', '4010', '', -560, 0, 0, 2, 0x37, 0, ''),
(248, 10, 11, '2016-08-10', '2150', '', -39.2, 0, 0, 2, 0x37, 0, ''),
(249, 10, 11, '2016-08-10', '4010', '', -200, 0, 0, 2, 0x37, 0, ''),
(250, 10, 11, '2016-08-10', '2150', '', -14, 0, 0, 2, 0x37, 0, ''),
(251, 10, 11, '2016-08-10', '1200', '', 813.2, 0, 0, 2, 0x37, 0, ''),
(252, 10, 11, '2016-08-10', '4451', '', 0, 0, 0, 2, 0x37, 0, ''),
(253, 25, 49, '2016-08-10', '1510', 'AAA', 568, 0, 0, 3, 0x32, 0, ''),
(254, 25, 49, '2016-08-10', '1550', '', -568, 0, 0, 3, '', 0, ''),
(255, 20, 18, '2016-08-10', '2100', '', -607.76, 0, 0, 3, 0x32, 0, ''),
(256, 20, 18, '2016-08-10', '1550', '', 568, 0, 0, 3, 0x32, 0, ''),
(257, 20, 18, '2016-08-10', '1300', '', 39.76, 0, 0, 3, 0x32, 0, ''),
(258, 20, 19, '2016-08-10', '2100', '', -2140, 0, 0, 3, 0x32, 0, ''),
(259, 20, 19, '2016-08-10', '5710', '', 2000, 0, 0, 3, 0x32, 0, ''),
(260, 20, 19, '2016-08-10', '1300', '', 140, 0, 0, 3, 0x32, 0, ''),
(261, 25, 51, '2016-08-10', '1510', 'AAA', 568, 0, 0, 3, 0x32, 0, ''),
(262, 25, 51, '2016-08-10', '1550', '', -568, 0, 0, 3, '', 0, ''),
(263, 20, 20, '2016-08-10', '2100', '', -2747.76, 0, 0, 3, 0x32, 0, ''),
(264, 20, 20, '2016-08-10', '1550', '', 568, 0, 0, 3, 0x32, 0, ''),
(265, 20, 20, '2016-08-10', '1300', '', 39.76, 0, 0, 3, 0x32, 0, ''),
(266, 20, 20, '2016-08-10', '5710', '', 2000, 0, 0, 3, 0x32, 0, ''),
(267, 20, 20, '2016-08-10', '1300', '', 140, 0, 0, 3, 0x32, 0, ''),
(268, 13, 12, '2016-08-10', '5010', '', 659.59, 0, 0, 2, 0x37, 0, ''),
(269, 13, 12, '2016-08-10', '1510', '', -659.59, 0, 0, 2, 0x37, 0, ''),
(270, 10, 12, '2016-08-10', '4010', '', -1000, 0, 0, 2, 0x37, 0, ''),
(271, 10, 12, '2016-08-10', '2150', '', -70, 0, 0, 2, 0x37, 0, ''),
(272, 10, 12, '2016-08-10', '1200', '', 1070, 0, 0, 2, 0x37, 0, ''),
(273, 10, 12, '2016-08-10', '4451', '', 0, 0, 0, 2, 0x37, 0, ''),
(274, 25, 52, '2016-08-10', '1510', 'AAA', 568, 0, 0, 3, 0x32, 0, ''),
(275, 25, 52, '2016-08-10', '1550', '', -568, 0, 0, 3, '', 0, ''),
(276, 96, 2, '2015-12-31', '1065', '', -20000, 0, 0, NULL, 0x537570706c6965724d, 0, 'supplier-4'),
(277, 96, 2, '2015-12-31', '2100', '', 20000, 0, 0, NULL, 0x537570706c6965724d, 0, 'supplier-4'),
(278, 96, 2, '2015-12-31', '1065', '', 20000, 0, 0, NULL, 0x537570706c6965724d, 0, 'supplier-4'),
(279, 96, 2, '2015-12-31', '2100', '', -20000, 0, 0, NULL, 0x537570706c6965724d, 0, 'supplier-4'),
(280, 2, 1, '2016-08-02', '4440', 'Interest', -5.4, 0, 0, 0, '', 0, ''),
(281, 2, 1, '2016-08-02', '1060', '', 5.4, 0, 0, 0, '', 0, ''),
(282, 13, 13, '2016-08-10', '5010', '', 0, 0, 0, 2, 0x37, 0, ''),
(283, 13, 13, '2016-08-10', '1510', '', 0, 0, 0, 2, 0x37, 0, ''),
(284, 13, 13, '2016-08-10', '5010', '', 0, 0, 0, 2, 0x37, 0, ''),
(285, 13, 13, '2016-08-10', '1510', '', 0, 0, 0, 2, 0x37, 0, ''),
(286, 10, 13, '2016-08-10', '4010', '', 0, 0, 0, 2, 0x37, 0, ''),
(287, 10, 13, '2016-08-10', '2150', '', 0, 0, 0, 2, 0x37, 0, ''),
(288, 10, 13, '2016-08-10', '1200', '', 0, 0, 0, 2, 0x37, 0, ''),
(289, 10, 13, '2016-08-10', '4451', '', 0, 0, 0, 2, 0x37, 0, ''),
(290, 35, 1, '2016-08-10', '5010', 'Cost was -772,586.29 changed to -772,586.29 x quantity on hand for item &#039;AAA&#039;', 0, 0, 0, NULL, NULL, 0, ''),
(291, 35, 1, '2016-08-10', '1510', 'Cost was -772,586.29 changed to -772,586.29 x quantity on hand for item &#039;AAA&#039;', -0, 0, 0, NULL, NULL, 0, ''),
(292, 13, 13, '2016-08-10', '5010', '', 920, 0, 0, 2, 0x37, 0, ''),
(293, 13, 13, '2016-08-10', '1510', '', -920, 0, 0, 2, 0x37, 0, ''),
(294, 10, 13, '2016-08-10', '4010', '', -2000, 0, 0, 2, 0x37, 0, ''),
(295, 10, 13, '2016-08-10', '2150', '', -140, 0, 0, 2, 0x37, 0, ''),
(296, 10, 13, '2016-08-10', '1200', '', 2140, 0, 0, 2, 0x37, 0, ''),
(297, 10, 13, '2016-08-10', '4451', '', 0, 0, 0, 2, 0x37, 0, ''),
(298, 12, 13, '2016-08-16', '1060', '', 30000, 0, 0, 2, 0x38, 0, ''),
(299, 12, 13, '2016-08-16', '1200', '', -30000, 0, 0, 2, 0x38, 0, ''),
(300, 25, 53, '2016-08-25', '1510', 'SP01', 200, 0, 0, 3, 0x32, 0, ''),
(301, 25, 53, '2016-08-25', '1550', '', -200, 0, 0, 3, '', 0, ''),
(302, 17, 1, '2016-08-26', '5040', '', -5000, 0, 0, NULL, NULL, 0, ''),
(303, 17, 1, '2016-08-26', '1510', '', 5000, 0, 0, NULL, NULL, 0, ''),
(304, 17, 2, '2016-08-26', '5040', '', -6000, 0, 0, NULL, NULL, 0, ''),
(305, 17, 2, '2016-08-26', '1510', '', 6000, 0, 0, NULL, NULL, 0, ''),
(306, 13, 14, '2016-08-26', '5010', '', 649.33, 0, 0, 2, 0x37, 0, ''),
(307, 13, 14, '2016-08-26', '1510', '', -649.33, 0, 0, 2, 0x37, 0, ''),
(308, 10, 14, '2016-08-26', '4010', '', -800, 0, 0, 2, 0x37, 0, ''),
(309, 10, 14, '2016-08-26', '2150', '', -56, 0, 0, 2, 0x37, 0, ''),
(310, 10, 14, '2016-08-26', '1200', '', 856, 0, 0, 2, 0x37, 0, ''),
(311, 10, 14, '2016-08-26', '4451', '', 0, 0, 0, 2, 0x37, 0, ''),
(312, 10, 15, '2016-08-29', '4010', '', -50, 0, 0, 2, 0x33, 0, ''),
(313, 10, 15, '2016-08-29', '4010', '', -80, 0, 0, 2, 0x33, 0, ''),
(314, 10, 15, '2016-08-29', '1200', '', 130, 0, 0, 2, 0x33, 0, ''),
(315, 10, 15, '2016-08-29', '4451', '', 0, 0, 0, 2, 0x33, 0, ''),
(316, 1, 2, '2016-09-12', '1200', 'Trade Debtors', 200, 0, 0, 2, 0x35, 0, ''),
(317, 1, 2, '2016-09-12', '1060', '', -200, 0, 0, 2, 0x35, 0, ''),
(318, 13, 16, '2016-09-12', '5010', '', 0, 0, 0, 2, 0x33, 0, ''),
(319, 13, 16, '2016-09-12', '1510', '', 0, 0, 0, 2, 0x33, 0, ''),
(320, 13, 16, '2016-09-12', '5010', '', 0, 0, 0, 2, 0x33, 0, ''),
(321, 13, 16, '2016-09-12', '1510', '', 0, 0, 0, 2, 0x33, 0, ''),
(322, 10, 16, '2016-09-12', '4010', '', 0, 0, 0, 2, 0x33, 0, ''),
(323, 10, 16, '2016-09-12', '4010', '', 0, 0, 0, 2, 0x33, 0, ''),
(324, 10, 16, '2016-09-12', '1200', '', 0, 0, 0, 2, 0x33, 0, ''),
(325, 10, 16, '2016-09-12', '4451', '', 0, 0, 0, 2, 0x33, 0, ''),
(326, 35, 2, '2016-09-12', '5010', 'Cost was -1,296.29 changed to -1,296.29 x quantity on hand for item &#039;AAA&#039;', -0, 0, 0, NULL, NULL, 0, ''),
(327, 35, 2, '2016-09-12', '1510', 'Cost was -1,296.29 changed to -1,296.29 x quantity on hand for item &#039;AAA&#039;', 0, 0, 0, NULL, NULL, 0, ''),
(328, 13, 16, '2016-09-12', '5010', '', 649.3333, 0, 0, 2, 0x33, 0, ''),
(329, 13, 16, '2016-09-12', '1510', '', -649.3333, 0, 0, 2, 0x33, 0, ''),
(330, 13, 16, '2016-09-12', '5010', '', 6481.4286, 0, 0, 2, 0x33, 0, ''),
(331, 13, 16, '2016-09-12', '1510', '', -6481.4286, 0, 0, 2, 0x33, 0, ''),
(332, 10, 16, '2016-09-12', '4010', '', -20, 0, 0, 2, 0x33, 0, ''),
(333, 10, 16, '2016-09-12', '4010', '', -100, 0, 0, 2, 0x33, 0, ''),
(334, 10, 16, '2016-09-12', '4010', '', -25, 0, 0, 2, 0x33, 0, ''),
(335, 10, 16, '2016-09-12', '1200', '', 145, 0, 0, 2, 0x33, 0, ''),
(336, 10, 16, '2016-09-12', '4451', '', 0, 0, 0, 2, 0x33, 0, ''),
(337, 13, 17, '2016-09-28', '5010', '', 6493.3333, 0, 0, 2, 0x38, 0, ''),
(338, 13, 17, '2016-09-28', '1510', '', -6493.3333, 0, 0, 2, 0x38, 0, ''),
(339, 10, 17, '2016-09-28', '4010', '', -200, 0, 0, 2, 0x38, 0, ''),
(340, 10, 17, '2016-09-28', '2150', '', -14, 0, 0, 2, 0x38, 0, ''),
(341, 10, 17, '2016-09-28', '1200', '', 214, 0, 0, 2, 0x38, 0, ''),
(342, 10, 17, '2016-09-28', '4451', '', 0, 0, 0, 2, 0x38, 0, ''),
(343, 12, 14, '2016-09-28', '1065', '', 214, 0, 0, 2, 0x38, 0, ''),
(344, 12, 14, '2016-09-28', '1200', '', -214, 0, 0, 2, 0x38, 0, ''),
(345, 12, 15, '2016-09-28', '1060', '', 190, 0, 0, 2, 0x38, 0, ''),
(346, 12, 15, '2016-09-28', '1200', '', -200, 0, 0, 2, 0x38, 0, ''),
(347, 12, 15, '2016-09-28', '4500', '', 10, 0, 0, 2, 0x38, 0, ''),
(348, 1, 3, '2017-12-31', '4430', 'Shipping &amp; Handling', 200, 0, 0, 0, '', 0, ''),
(349, 1, 3, '2017-12-31', '1060', '', -200, 0, 0, 0, '', 0, ''),
(350, 13, 18, '2017-02-16', '5010', '', 649.33, 0, 0, 2, 0x33, 0, ''),
(351, 13, 18, '2017-02-16', '1510', '', -649.33, 0, 0, 2, 0x33, 0, ''),
(352, 13, 19, '2017-02-16', '5010', '', 649.33, 0, 0, 2, 0x34, 0, ''),
(353, 13, 19, '2017-02-16', '1510', '', -649.33, 0, 0, 2, 0x34, 0, ''),
(354, 13, 20, '2017-02-16', '5010', '', 648.14, 0, 0, 2, 0x34, 0, ''),
(355, 13, 20, '2017-02-16', '1510', '', -648.14, 0, 0, 2, 0x34, 0, ''),
(356, 13, 21, '2017-02-16', '5010', '', 648.14, 0, 0, 2, 0x34, 0, ''),
(357, 13, 21, '2017-02-16', '1510', '', -648.14, 0, 0, 2, 0x34, 0, ''),
(358, 10, 18, '2017-02-16', '4010', '', -699, 0, 0, 2, 0x34, 0, ''),
(359, 10, 18, '2017-02-16', '2150', '', -48.93, 0, 0, 2, 0x34, 0, ''),
(360, 10, 18, '2017-02-16', '1200', '', 747.93, 0, 0, 2, 0x34, 0, ''),
(361, 10, 18, '2017-02-16', '4451', '', 0, 0, 0, 2, 0x34, 0, ''),
(362, 1, 4, '2017-02-18', '5460', 'Test', 200, 0, 0, 0, '', 12, ''),
(363, 1, 4, '2017-02-18', '1300', '', 14, 0, 0, 0, '', 0, ''),
(364, 1, 4, '2017-02-18', '1060', '', -214, 0, 0, 0, '', 0, ''),
(365, 1, 5, '2017-02-21', '4440', 'test', 500, 0, 0, 0, '', 12, ''),
(366, 1, 5, '2017-02-21', '1300', '', 35, 0, 0, 0, '', 0, ''),
(367, 1, 5, '2017-02-21', '1060', 'test', -535, 0, 0, 0, '', 0, ''),
(368, 2, 2, '2017-02-21', '5010', 'Cost of Goods Sold - Retail', -200, 0, 0, 0, '', 26, ''),
(369, 2, 2, '2017-02-21', '2150', '', -14, 0, 0, 0, '', 0, ''),
(370, 2, 2, '2017-02-21', '1060', '', 214, 0, 0, 0, '', 0, ''),
(371, 1, 6, '2017-02-21', '5030', 'test', 20, 0, 0, 0, '', 12, ''),
(372, 1, 6, '2017-02-21', '1300', '', 1.4, 0, 0, 0, '', 0, ''),
(373, 1, 6, '2017-02-21', '1060', 'test', -21.4, 0, 0, 0, '', 0, ''),
(374, 2, 3, '2017-02-21', '4510', 'test', -25, 0, 0, 0, '', 26, ''),
(375, 2, 3, '2017-02-21', '2150', '', -1.75, 0, 0, 0, '', 0, ''),
(376, 2, 3, '2017-02-21', '1060', 'test', 26.75, 0, 0, 0, '', 0, ''),
(377, 0, 1, '2017-02-21', '1065', 'Petty Cash', 400, 0, 0, NULL, NULL, 0, ''),
(378, 0, 1, '2017-02-21', '4440', 'Interest', -400, 0, 0, NULL, NULL, 0, ''),
(379, 0, 2, '2017-02-21', '1050', 'Bank USD', 20, 0, 0, NULL, NULL, 0, ''),
(380, 0, 2, '2017-02-21', '5550', 'Taxes - Franchise', -20, 0, 0, NULL, NULL, 0, ''),
(381, 4, 1, '2017-02-22', '1060', 'From Bank SGD To Bank USD', -1770, 0, 0, NULL, NULL, 0, ''),
(382, 4, 1, '2017-02-22', '5690', 'From Bank SGD To Bank USD', 20, 0, 0, NULL, NULL, 0, ''),
(383, 4, 1, '2017-02-22', '1050', 'From Bank SGD To Bank USD', 1500, 0, 0, NULL, NULL, 0, ''),
(384, 4, 1, '2017-02-22', '4450', 'Exchange Variance', 250, 0, 0, NULL, NULL, 0, ''),
(385, 13, 22, '2017-02-23', '5010', '', 649.33, 0, 0, 2, 0x35, 0, ''),
(386, 13, 22, '2017-02-23', '1510', '', -649.33, 0, 0, 2, 0x35, 0, ''),
(387, 10, 19, '2017-02-23', '4010', '', -1000, 0, 0, 2, 0x35, 0, ''),
(388, 10, 19, '2017-02-23', '2150', '', -70, 0, 0, 2, 0x35, 0, ''),
(389, 10, 19, '2017-02-23', '1200', '', 1070, 0, 0, 2, 0x35, 0, ''),
(390, 10, 19, '2017-02-23', '4451', '', 0, 0, 0, 2, 0x35, 0, ''),
(391, 12, 16, '2017-02-23', '1060', '', 1070, 0, 0, 2, 0x35, 0, ''),
(392, 12, 16, '2017-02-23', '1200', '', -1070, 0, 0, 2, 0x35, 0, ''),
(393, 10, 20, '2017-05-06', '4010', NULL, -222, 0, 0, 2, 0x38, 0, ''),
(394, 10, 20, '2017-05-06', '2150', NULL, -15.54, 0, 0, 2, 0x38, 0, ''),
(395, 10, 20, '2017-05-06', '1200', '', 237.54, 0, 0, 2, 0x38, 0, ''),
(396, 10, 20, '2017-05-06', '4451', '', 0, 0, 0, 2, 0x38, 0, ''),
(397, 12, 17, '2017-05-06', '1065', '', 237.54, 0, 0, 2, 0x38, 0, ''),
(398, 12, 17, '2017-05-06', '1200', '', -237.54, 0, 0, 2, 0x38, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `grn_batch`
--

CREATE TABLE IF NOT EXISTS `grn_batch` (
  `id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL DEFAULT '0',
  `purch_order_no` int(11) DEFAULT NULL,
  `reference` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `delivery_date` date NOT NULL DEFAULT '0000-00-00',
  `loc_code` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `grn_batch`
--

INSERT INTO `grn_batch` (`id`, `supplier_id`, `purch_order_no`, `reference`, `delivery_date`, `loc_code`) VALUES
(1, 9, 2, 'auto', '2015-11-03', 'DEF'),
(2, 11, 3, 'auto', '2015-11-03', 'DEF'),
(3, 9, 4, 'auto', '2015-11-03', 'DEF'),
(4, 9, 5, 'auto', '2015-11-03', 'DEF'),
(5, 9, 6, 'auto', '2015-11-03', 'DEF'),
(6, 9, 7, 'auto', '2015-11-03', 'DEF'),
(7, 9, 8, 'auto', '2015-11-03', 'DEF'),
(8, 14, 9, 'auto', '2015-11-04', 'DEF'),
(9, 9, 10, 'auto', '2015-11-04', 'DEF'),
(10, 9, 11, 'auto', '2015-11-04', 'DEF'),
(11, 9, 12, 'auto', '2015-11-06', 'DEF'),
(12, 12, 13, 'auto', '2015-11-06', 'DEF'),
(13, 9, 14, 'auto', '2015-11-06', 'DEF'),
(14, 12, 15, 'auto', '2015-11-06', 'DEF'),
(15, 12, 16, 'auto', '2015-11-07', 'DEF'),
(16, 9, 17, 'auto', '2015-11-06', 'DEF'),
(17, 9, 18, 'auto', '2015-11-10', 'DEF'),
(18, 9, 19, 'auto', '2015-11-10', 'DEF'),
(19, 9, 20, 'auto', '2015-11-10', 'DEF'),
(20, 10, 21, 'auto', '2015-11-08', 'DEF'),
(21, 3, 22, 'auto', '2015-11-08', 'DEF'),
(22, 9, 23, 'auto', '2015-11-11', 'DEF'),
(23, 9, 24, 'auto', '2015-12-13', 'DEF'),
(24, 14, 25, 'auto', '2015-11-17', 'DEF'),
(25, 12, 26, 'auto', '2015-11-16', 'DEF'),
(26, 9, 27, 'auto', '2015-11-16', 'DEF'),
(27, 12, 28, 'auto', '2015-11-16', 'DEF'),
(28, 12, 29, 'auto', '2015-11-16', 'DEF'),
(29, 9, 30, 'auto', '2015-02-28', 'DEF'),
(30, 9, 31, 'auto', '2015-02-28', 'DEF'),
(31, 2, 32, 'auto', '2016-08-09', 'DEF'),
(32, 3, 33, 'auto', '2016-08-01', 'DEF'),
(33, 4, 34, 'auto', '2016-08-02', 'DEF'),
(34, 5, 35, 'auto', '2016-07-01', 'DEF'),
(35, 6, 36, 'auto', '2016-05-01', 'DEF'),
(36, 7, 37, 'auto', '2016-08-09', 'DEF'),
(37, 3, 38, 'auto', '2016-08-10', 'DEF'),
(38, 3, 39, 'auto', '2016-08-10', 'DEF'),
(39, 4, 40, 'auto', '2016-08-10', 'DEF'),
(40, 2, 41, 'auto', '2016-08-10', 'DEF'),
(41, 7, 42, 'auto', '2016-08-10', 'DEF'),
(42, 5, 43, 'auto', '2016-08-10', 'DEF'),
(43, 5, 44, 'auto', '2016-08-10', 'DEF'),
(44, 4, 45, 'auto', '2016-08-10', 'DEF'),
(45, 3, 46, 'auto', '2016-08-10', 'DEF'),
(46, 2, 47, 'auto', '2016-08-10', 'DEF'),
(47, 2, 48, 'auto', '2016-08-10', 'DEF'),
(48, 2, 49, 'auto', '2016-08-10', 'DEF'),
(49, 2, 50, 'auto', '2016-08-10', 'DEF'),
(50, 2, 51, 'auto', '2016-08-10', 'DEF'),
(51, 2, 52, 'auto', '2016-08-10', 'DEF'),
(52, 2, 53, 'auto', '2016-08-10', 'DEF'),
(53, 2, 54, 'auto', '2016-08-25', 'DEF');

-- --------------------------------------------------------

--
-- Table structure for table `grn_items`
--

CREATE TABLE IF NOT EXISTS `grn_items` (
  `id` int(11) NOT NULL,
  `grn_batch_id` int(11) DEFAULT NULL,
  `po_detail_item` int(11) NOT NULL DEFAULT '0',
  `item_code` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` tinytext COLLATE utf8_unicode_ci,
  `qty_recd` double NOT NULL DEFAULT '0',
  `quantity_inv` double NOT NULL DEFAULT '0',
  `tax_type_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `grn_items`
--

INSERT INTO `grn_items` (`id`, `grn_batch_id`, `po_detail_item`, `item_code`, `description`, `qty_recd`, `quantity_inv`, `tax_type_id`) VALUES
(1, 1, 2, '1111', 'test ', 0, 0, 39),
(2, 2, 3, 'SP001', 'Apple iPhone 6S', 100, 100, 46),
(3, 2, 4, 'SP002', 'Apple iPhone 6S Plus', 20, 20, 46),
(4, 3, 5, 'SP001', 'Apple iPhone 6S', 1, 2, 38),
(5, 3, 6, 'SP002', 'Apple iPhone 6S Plus', 1, 2, 39),
(6, 3, 7, 'SV001', 'Repair Service', 1, 2, 40),
(7, 4, 8, 'SP001', 'Apple iPhone 6S', 1, 1, 41),
(8, 4, 9, 'SP002', 'Apple iPhone 6S Plus', 1, 1, 42),
(9, 4, 10, 'SV001', 'Repair Service', 1, 1, 43),
(10, 5, 11, 'SP001', 'Apple iPhone 6S', 1, 1, 44),
(11, 5, 12, 'SP002', 'Apple iPhone 6S Plus', 1, 1, 45),
(12, 5, 13, 'SV001', 'Repair Service', 1, 1, 47),
(13, 6, 14, 'SP001', 'Apple iPhone 6S', 1, 1, 48),
(14, 7, 15, '1111', 'test ', 100, 100, 46),
(15, 8, 16, 'SV001', 'Repair Service', 1, 1, 41),
(16, 9, 17, 'SP001', 'Apple iPhone 6S', 1, 1, 46),
(17, 9, 18, 'SP002', 'Apple iPhone 6S Plus', 1, 1, 46),
(18, 10, 19, '1111', 'test ', 1, 1, 46),
(19, 11, 20, '1111', 'test ', 1, 1, 48),
(20, 12, 21, '1111', 'test ', 1, 1, 48),
(21, 13, 22, '1111', 'test ', 1, 1, 46),
(22, 14, 23, '1111', 'test ', 1, 1, 46),
(23, 15, 24, '1111', 'test ', 1, 1, 46),
(24, 16, 25, '1111', 'test ', 1, 1, 46),
(25, 16, 26, '3333', 'test 2', 1, 1, 46),
(26, 17, 27, '1111', 'test ', 1, 1, 46),
(27, 18, 28, '1111', 'test ', 1, 1, 46),
(28, 19, 29, '1111', 'test ', 1, 1, 46),
(29, 20, 30, '3333', 'test 2', 1, 1, 46),
(30, 21, 31, '3333', 'test 2', 1, 1, 45),
(31, 22, 32, '1111', 'test ', 10, 10, 46),
(32, 23, 33, '1111', 'test ', 1, 1, 46),
(33, 24, 34, 'SV001', 'Purchase of Goods F', 1, 0, 48),
(34, 25, 35, '1111', 'test ', 10, 10, 48),
(35, 26, 36, '1111', 'test ', 0, 0, 48),
(36, 27, 37, '3333', 'test 2', 10, 10, 48),
(37, 28, 38, '1111', 'test ', 1, 1, 48),
(38, 29, 39, '1111', 'test ', 1, 1, 46),
(39, 30, 40, '1111', 'test ', 0, 0, 46),
(40, 31, 41, 'SP01', 'Stock Product 01', 1, 5, 46),
(41, 32, 42, 'SP02', 'Stock Product 02', 10, 10, 46),
(42, 33, 43, 'SP03', 'Stock Product 03', 10, 10, 46),
(43, 34, 44, 'SP04', 'Stock product 04', 5, 5, 46),
(44, 35, 45, 'SP05', 'Stock product 05', 20, 20, 46),
(45, 36, 46, 'SP01', 'Stock Product 01', 10, 10, 46),
(46, 37, 49, 'AAA', 'AAA', 1, 1, 46),
(47, 37, 50, 'SP02', 'Stock Product 02', 2, 2, 46),
(48, 38, 51, 'AAA', 'AAA', 1, 1, 46),
(49, 39, 52, 'AAA', 'AAA', 2, 2, 46),
(50, 40, 53, 'AAA', 'AAA', 1, 1, 41),
(51, 41, 54, 'SP02', 'Stock Product 02', 0, 0, 46),
(52, 42, 55, 'SP07', 'Stock Product 07', 2, 0, 46),
(53, 42, 56, 'SP08', 'Stock Product 08', 3, 0, 46),
(54, 43, 57, 'AAA', 'AAA', 1, 1, 46),
(55, 44, 58, 'AAA', 'AAA', 1, 1, 46),
(56, 45, 59, 'AAA', 'AAA', 1, 1, 0),
(57, 46, 60, 'Maint001', 'Maintenance ', 1, 1, 46),
(58, 47, 61, 'SP01', 'Stock Product 01', 1, 1, 46),
(59, 48, 62, 'AAA', 'AAA', 1, 1, 46),
(60, 49, 63, 'AAA', 'AAA', 1, 1, 46),
(61, 50, 64, 'Maint001', 'Maintenance ', 1, 1, 46),
(62, 51, 65, 'AAA', 'AAA', 1, 1, 46),
(63, 51, 66, 'Maint001', 'Maintenance ', 1, 1, 46),
(64, 52, 67, 'AAA', 'AAA', 1, 0, 46),
(65, 53, 68, 'SP01', 'Stock Product 01', 1, 0, 46);

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE IF NOT EXISTS `groups` (
  `id` smallint(6) unsigned NOT NULL,
  `description` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `inactive` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `description`, `inactive`) VALUES
(1, 'Small', 0),
(2, 'Medium', 0),
(3, 'Large', 0);

-- --------------------------------------------------------

--
-- Table structure for table `import_process`
--

CREATE TABLE IF NOT EXISTS `import_process` (
  `id` int(11) NOT NULL,
  `module` char(100) NOT NULL,
  `total` int(10) NOT NULL,
  `complate` int(10) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `file` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `item_codes`
--

CREATE TABLE IF NOT EXISTS `item_codes` (
  `id` int(11) unsigned NOT NULL,
  `item_code` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `stock_id` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `category_id` smallint(6) unsigned NOT NULL,
  `quantity` double NOT NULL DEFAULT '1',
  `is_foreign` tinyint(1) NOT NULL DEFAULT '0',
  `inactive` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=2542 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `item_codes`
--

INSERT INTO `item_codes` (`id`, `item_code`, `stock_id`, `description`, `category_id`, `quantity`, `is_foreign`, `inactive`) VALUES
(2541, 'Maint001', 'Maint001', 'Maintenance ', 46, 1, 0, 0),
(2540, 'AAA', 'AAA', 'AAA', 46, 1, 0, 0),
(2538, 'SP14', 'SP14', 'Service Product 04', 50, 1, 0, 0),
(2537, 'SP13', 'SP13', 'Service Product 03', 50, 1, 0, 0),
(2536, 'SP12', 'SP12', 'Service Product 02', 50, 1, 0, 0),
(2535, 'SP11', 'SP11', 'Service Product 01', 50, 1, 0, 0),
(2534, 'SP10', 'SP10', 'Stock Product 10', 46, 1, 0, 0),
(2533, 'SP09', 'SP09', 'Stock Product 09', 46, 1, 0, 0),
(2532, 'SP08', 'SP08', 'Stock Product 08', 46, 1, 0, 0),
(2531, 'SP07', 'SP07', 'Stock Product 07', 46, 1, 0, 0),
(2530, 'SP06', 'SP06', 'Stock Product 06', 46, 1, 0, 0),
(2529, 'SP05', 'SP05', 'Stock product 05', 46, 1, 0, 0),
(2528, 'SP04', 'SP04', 'Stock product 04', 46, 1, 0, 0),
(2527, 'SP03', 'SP03', 'Stock Product 03', 46, 1, 0, 0),
(2526, 'SP02', 'SP02', 'Stock Product 02', 46, 1, 0, 0),
(2525, 'SP01', 'SP01', 'Test', 46, 1, 0, 0),
(2524, 'SV001', 'SV001', 'Repair Service', 46, 1, 0, 0),
(2523, 'SP002', 'SP002', 'Apple iPhone 6S Plus', 46, 1, 0, 0),
(2522, 'SP001', 'SP001', 'Apple iPhone 6S', 46, 1, 0, 0),
(2521, 'Sales', 'Sales', 'Sales', 46, 1, 0, 0),
(2520, '3333', '3333', 'test 2', 46, 1, 0, 0),
(2519, '1111', '1111', 'test ', 46, 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `item_tax_types`
--

CREATE TABLE IF NOT EXISTS `item_tax_types` (
  `id` int(11) NOT NULL,
  `name` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `exempt` tinyint(1) NOT NULL DEFAULT '0',
  `inactive` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `item_tax_types`
--

INSERT INTO `item_tax_types` (`id`, `name`, `exempt`, `inactive`) VALUES
(1, 'Standard Rated', 0, 0),
(2, 'GST Zero Rated', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `item_tax_type_exemptions`
--

CREATE TABLE IF NOT EXISTS `item_tax_type_exemptions` (
  `item_tax_type_id` int(11) NOT NULL DEFAULT '0',
  `tax_type_id` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `item_units`
--

CREATE TABLE IF NOT EXISTS `item_units` (
  `abbr` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `decimals` tinyint(2) NOT NULL,
  `inactive` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `item_units`
--

INSERT INTO `item_units` (`abbr`, `name`, `decimals`, `inactive`) VALUES
('each', 'Each', 0, 0),
('set', 'Set', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `kv_country`
--

CREATE TABLE IF NOT EXISTS `kv_country` (
  `id` int(11) unsigned NOT NULL,
  `iso` varchar(50) DEFAULT NULL,
  `local_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=247 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `kv_country`
--

INSERT INTO `kv_country` (`id`, `iso`, `local_name`) VALUES
(1, 'AD', 'Andorra'),
(2, 'AE', 'United Arab Emirates'),
(3, 'AF', 'Afghanistan'),
(4, 'AG', 'Antigua and Barbuda'),
(5, 'AI', 'Anguilla'),
(6, 'AL', 'Albania'),
(7, 'AM', 'Armenia\r\n'),
(8, 'AN', 'Netherlands Antilles\r\n'),
(9, 'AO', 'Angola\r\n'),
(10, 'AQ', 'Antarctica\r\n'),
(11, 'AR', 'Argentina\r\n'),
(12, 'AS', 'American Samoa\r\n'),
(13, 'AT', 'Austria\r\n'),
(14, 'AU', 'Australia\r\n'),
(15, 'AW', 'Aruba\r\n'),
(16, 'AX', 'Aland Islands'),
(17, 'AZ', 'Azerbaijan\r\n'),
(18, 'BA', 'Bosnia and Herzegovina\r\n'),
(19, 'BB', 'Barbados\r\n'),
(20, 'BD', 'Bangladesh\r\n'),
(21, 'BE', 'Belgium\r\n'),
(22, 'BF', 'Burkina Faso\r\n'),
(23, 'BG', 'Bulgaria\r\n'),
(24, 'BH', 'Bahrain\r\n'),
(25, 'BI', 'Burundi\r\n'),
(26, 'BJ', 'Benin\r\n'),
(27, 'BL', 'Saint Barthlemy'),
(28, 'BM', 'Bermuda\r\n'),
(29, 'BN', 'Brunei Darussalam\r\n'),
(30, 'BO', 'Bolivia\r\nBolivia, Plurinational state of'),
(31, 'BR', 'Brazil\r\n'),
(32, 'BS', 'Bahamas\r\n'),
(33, 'BT', 'Bhutan\r\n'),
(34, 'BV', 'Bouvet Island\r\n'),
(35, 'BW', 'Botswana\r\n'),
(36, 'BY', 'Belarus\r\n'),
(37, 'BZ', 'Belize\r\n'),
(38, 'CA', 'Canada\r\n'),
(39, 'CC', 'Cocos (Keeling) Islands\r\n'),
(40, 'CD', 'Congo, The Democratic Republic of the\r\n'),
(41, 'CF', 'Central African Republic\r\n'),
(42, 'CG', 'Congo\r\n'),
(43, 'CH', 'Switzerland\r\n'),
(45, 'CK', 'Cook Islands\r\n'),
(46, 'CL', 'Chile'),
(47, 'CM', 'Cameroon\r\n'),
(48, 'CN', 'China\r\n'),
(49, 'CO', 'Colombia\r\n'),
(50, 'CR', 'Costa Rica\r\n'),
(51, 'CU', 'Cuba\r\n'),
(52, 'CV', 'Cape Verde\r\n'),
(53, 'CX', 'Christmas Island\r\n'),
(54, 'CY', 'Cyprus\r\n'),
(55, 'CZ', 'Czech Republic\r\n'),
(56, 'DE', 'Germany\r\n'),
(57, 'DJ', 'Djibouti\r\n'),
(58, 'DK', 'Denmark\r\n'),
(59, 'DM', 'Dominica\r\n'),
(60, 'DO', 'Dominican Republic\r\n'),
(61, 'DZ', 'Algeria\r\n'),
(62, 'EC', 'Ecuador\r\n'),
(63, 'EE', 'Estonia\r\n'),
(64, 'EG', 'Egypt\r\n'),
(65, 'EH', 'Western Sahara\r\n'),
(66, 'ER', 'Eritrea\r\n'),
(67, 'ES', 'Spain\r\n'),
(68, 'ET', 'Ethiopia\r\n'),
(69, 'FI', 'Finland\r\n'),
(70, 'FJ', 'Fiji\r\n'),
(71, 'FK', 'Falkland Islands (Malvinas)\r\n'),
(72, 'FM', 'Micronesia, Federated States of\r\n'),
(73, 'FO', 'Faroe Islands\r\n'),
(74, 'FR', 'France\r\n'),
(75, 'GA', 'Gabon'),
(76, 'GB', 'United Kingdom'),
(77, 'GD', 'Grenada'),
(78, 'GE', 'Georgia'),
(79, 'GF', 'French Guiana'),
(80, 'GG', 'Guernsey'),
(81, 'GH', 'Ghana\r\n'),
(82, 'GI', 'Gibraltar\r\n'),
(83, 'GL', 'Greenland\r\n'),
(84, 'GM', 'Gambia\r\n'),
(85, 'GN', 'Guinea\r\n'),
(86, 'GP', 'Guadeloupe\r\n'),
(87, 'GQ', 'Equatorial Guinea\r\n'),
(88, 'GR', 'Greece\r\n'),
(89, 'GS', 'South Georgia and the South Sandwich Islands\r\n'),
(90, 'GT', 'Guatemala\r\n'),
(91, 'GU', 'Guam\r\n'),
(92, 'GW', 'Guinea-Bissau\r\n'),
(93, 'GY', 'Guyana\r\n'),
(94, 'HK', 'Hong Kong\r\n'),
(95, 'HM', 'Heard Island and McDonald Islands\r\n'),
(96, 'HN', 'Honduras\r\n'),
(97, 'HR', 'Croatia\r\n'),
(98, 'HT', 'Haiti\r\n'),
(99, 'HU', 'Hungary\r\n'),
(100, 'ID', 'Indonesia\r\n'),
(101, 'IE', 'Ireland\r\n'),
(102, 'IL', 'Israel\r\n'),
(103, 'IM', 'Isle of Man\r\n'),
(104, 'IN', 'India\r\n'),
(105, 'IO', 'British Indian Ocean Territory\r\n'),
(106, 'IQ', 'Iraq\r\n'),
(107, 'IR', 'Iran, Islamic Republic of\r\n'),
(108, 'IS', 'Iceland\r\n'),
(109, 'IT', 'Italy'),
(110, 'JE', 'Jersey\r\n'),
(111, 'JM', 'Jamaica\r\n'),
(112, 'JO', 'Jordan\r\n'),
(113, 'JP', 'Japan\r\n'),
(114, 'KE', 'Kenya\r\n'),
(115, 'KG', 'Kyrgyzstan\r\n'),
(116, 'KH', 'Cambodia\r\n'),
(117, 'KI', 'Kiribati\r\n'),
(118, 'KM', 'Comoros\r\n'),
(119, 'KN', 'Saint Kitts and Nevis\r\n'),
(120, 'KP', 'Korea, Democratic People&#39;s Republic of\r\n'),
(121, 'KR', 'Korea, Republic of\r\n'),
(122, 'KW', 'Kuwait\r\n'),
(123, 'KY', 'Cayman Islands\r\n'),
(124, 'KZ', 'Kazakhstan\r\n'),
(125, 'LA', 'Lao People&#39;s Democratic Republic\r\n'),
(126, 'LB', 'Lebanon\r\n'),
(127, 'LC', 'Saint Lucia\r\n'),
(128, 'LI', 'Liechtenstein\r\n'),
(129, 'LK', 'Sri Lanka\r\n'),
(130, 'LR', 'Liberia\r\n'),
(131, 'LS', 'Lesotho\r\n'),
(132, 'LT', 'Lithuania\r\n'),
(133, 'LU', 'Luxembourg\r\n'),
(134, 'LV', 'Latvia\r\n'),
(135, 'LY', 'Libyan Arab Jamahiriya\r\n'),
(136, 'MA', 'Morocco\r\n'),
(137, 'MC', 'Monaco\r\n'),
(138, 'MD', 'Moldova, Republic of\r\n'),
(139, 'ME', 'Montenegro\r\n'),
(140, 'MF', 'Saint Martin'),
(141, 'MG', 'Madagascar\r\n'),
(142, 'MH', 'Marshall Islands\r\n'),
(143, 'MK', 'Macedonia\r\n'),
(144, 'ML', 'Mali\r\n'),
(145, 'MM', 'Myanmar\r\n'),
(146, 'MN', 'Mongolia\r\n'),
(147, 'MO', 'Macao\r\n'),
(148, 'MP', 'Northern Mariana Islands\r\n'),
(149, 'MQ', 'Martinique\r\n'),
(150, 'MR', 'Mauritania\r\n'),
(151, 'MS', 'Montserrat\r\n'),
(152, 'MT', 'Malta\r\n'),
(153, 'MU', 'Mauritius\r\n'),
(154, 'MV', 'Maldives\r\n'),
(155, 'MW', 'Malawi\r\n'),
(156, 'MX', 'Mexico\r\n'),
(157, 'MY', 'Malaysia\r\n'),
(158, 'MZ', 'Mozambique\r\n'),
(159, 'NA', 'Namibia\r\n'),
(160, 'NC', 'New Caledonia\r\n'),
(161, 'NE', 'Niger\r\n'),
(162, 'NF', 'Norfolk Island\r\n'),
(163, 'NG', 'Nigeria\r\n'),
(164, 'NI', 'Nicaragua\r\n'),
(165, 'NL', 'Netherlands\r\n'),
(166, 'NO', 'Norway'),
(167, 'NP', 'Nepal\r\n'),
(168, 'NR', 'Nauru\r\n'),
(169, 'NU', 'Niue\r\n'),
(170, 'NZ', 'New Zealand\r\n'),
(171, 'OM', 'Oman\r\n'),
(172, 'PA', 'Panama\r\n'),
(173, 'PE', 'Peru\r\n'),
(174, 'PF', 'French Polynesia\r\n'),
(175, 'PG', 'Papua New Guinea\r\n'),
(176, 'PH', 'Philippines\r\n'),
(177, 'PK', 'Pakistan\r\n'),
(178, 'PL', 'Poland\r\n'),
(179, 'PM', 'Saint Pierre and Miquelon\r\n'),
(180, 'PN', 'Pitcairn\r\n'),
(181, 'PR', 'Puerto Rico\r\n'),
(182, 'PS', 'Palestinian Territory, Occupied'),
(183, 'PT', 'Portugal\r\n'),
(184, 'PW', 'Palau\r\n'),
(185, 'PY', 'Paraguay\r\n'),
(186, 'QA', 'Qatar\r\n'),
(188, 'RO', 'Romania\r\n'),
(189, 'RS', 'Serbia\r\n'),
(190, 'RU', 'Russian Federation\r\n'),
(191, 'RW', 'Rwanda\r\n'),
(192, 'SA', 'Saudi Arabia\r\n'),
(193, 'SB', 'Solomon Islands\r\n'),
(194, 'SC', 'Seychelles\r\n'),
(195, 'SD', 'Sudan\r\n'),
(196, 'SE', 'Sweden\r\n'),
(197, 'SG', 'Singapore\r\n'),
(198, 'SH', 'Saint Helena\r\n'),
(199, 'SI', 'Slovenia\r\n'),
(200, 'SJ', 'Svalbard and Jan Mayen\r\n'),
(201, 'SK', 'Slovakia\r\n'),
(202, 'SL', 'Sierra Leone\r\n'),
(203, 'SM', 'San Marino\r\n'),
(204, 'SN', 'Senegal\r\n'),
(205, 'SO', 'Somalia\r\n'),
(206, 'SR', 'Suriname\r\n'),
(207, 'ST', 'Sao Tome and Principe\r\n'),
(208, 'SV', 'El Salvador\r\n'),
(209, 'SY', 'Syrian Arab Republic\r\n'),
(210, 'SZ', 'Swaziland\r\n'),
(211, 'TC', 'Turks and Caicos Islands\r\n'),
(212, 'TD', 'Chad'),
(213, 'TF', 'French Southern Territories'),
(214, 'TG', 'Togo'),
(215, 'TH', 'Thailand'),
(216, 'TJ', 'Tajikistan'),
(217, 'TK', 'Tokelau'),
(218, 'TL', 'Timor-Leste'),
(219, 'TM', 'Turkmenistan\r\n'),
(220, 'TN', 'Tunisia\r\n'),
(221, 'TO', 'Tonga\r\n'),
(222, 'TR', 'Turkey'),
(223, 'TT', 'Trinidad and Tobago\r\n'),
(224, 'TV', 'Tuvalu\r\n'),
(225, 'TW', 'Taiwan\r\n'),
(226, 'TZ', 'Tanzania, United Republic of\r\n'),
(227, 'UA', 'Ukraine\r\n'),
(228, 'UG', 'Uganda\r\n'),
(229, 'UM', 'United States Minor Outlying Islands\r\n'),
(230, 'US', 'United States\r\n'),
(231, 'UY', 'Uruguay\r\n'),
(232, 'UZ', 'Uzbekistan\r\n'),
(233, 'VA', 'Holy See (Vatican City State)\r\n'),
(234, 'VC', 'Saint Vincent and the Grenadines\r\n'),
(235, 'VE', 'Venezuela, Bolivarian Republic of'),
(236, 'VG', 'Virgin Islands, British\r\n'),
(237, 'VI', 'Virgin Islands, U.S.\r\n'),
(238, 'VN', 'Viet Nam'),
(239, 'VU', 'Vanuatu\r\n'),
(240, 'WF', 'Wallis and Futuna\r\n'),
(241, 'WS', 'Samoa\r\n'),
(242, 'YE', 'Yemen\r\n'),
(243, 'YT', 'Mayotte\r\n'),
(244, 'ZA', 'South Africa\r\n'),
(245, 'ZM', 'Zambia\r\n'),
(246, 'ZW', 'Zimbabwe');

-- --------------------------------------------------------

--
-- Table structure for table `kv_departments`
--

CREATE TABLE IF NOT EXISTS `kv_departments` (
  `id` smallint(6) unsigned NOT NULL,
  `description` varchar(60) NOT NULL DEFAULT '',
  `inactive` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kv_departments`
--

INSERT INTO `kv_departments` (`id`, `description`, `inactive`) VALUES
(1, 'Production', 0),
(2, 'Sales and Marketing', 0),
(3, 'HRM', 0),
(4, 'Training centre', 0),
(5, 'Research &amp; Development1', 0),
(6, 'Production', 0);

-- --------------------------------------------------------

--
-- Table structure for table `kv_empl_attendancee`
--

CREATE TABLE IF NOT EXISTS `kv_empl_attendancee` (
  `id` int(11) unsigned NOT NULL,
  `month` int(2) DEFAULT NULL,
  `year` int(2) DEFAULT NULL,
  `dept_id` int(10) NOT NULL,
  `empl_id` varchar(30) DEFAULT NULL,
  `1` varchar(2) NOT NULL,
  `2` varchar(2) NOT NULL,
  `3` varchar(2) NOT NULL,
  `4` varchar(2) NOT NULL,
  `5` varchar(2) NOT NULL,
  `6` varchar(2) NOT NULL,
  `7` varchar(2) NOT NULL,
  `8` varchar(2) NOT NULL,
  `9` varchar(2) NOT NULL,
  `10` varchar(2) NOT NULL,
  `11` varchar(2) NOT NULL,
  `12` varchar(2) NOT NULL,
  `13` varchar(2) NOT NULL,
  `14` varchar(2) NOT NULL,
  `15` varchar(2) NOT NULL,
  `16` varchar(2) NOT NULL,
  `17` varchar(2) NOT NULL,
  `18` varchar(2) NOT NULL,
  `19` varchar(2) NOT NULL,
  `20` varchar(2) NOT NULL,
  `21` varchar(2) NOT NULL,
  `22` varchar(2) NOT NULL,
  `23` varchar(2) NOT NULL,
  `24` varchar(2) NOT NULL,
  `25` varchar(2) NOT NULL,
  `26` varchar(2) NOT NULL,
  `27` varchar(2) NOT NULL,
  `28` varchar(2) NOT NULL,
  `29` varchar(2) NOT NULL,
  `30` varchar(2) NOT NULL,
  `31` varchar(2) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `kv_empl_attendancee`
--

INSERT INTO `kv_empl_attendancee` (`id`, `month`, `year`, `dept_id`, `empl_id`, `1`, `2`, `3`, `4`, `5`, `6`, `7`, `8`, `9`, `10`, `11`, `12`, `13`, `14`, `15`, `16`, `17`, `18`, `19`, `20`, `21`, `22`, `23`, `24`, `25`, `26`, `27`, `28`, `29`, `30`, `31`) VALUES
(1, 10, 21, 1, '1001', 'P', 'P', 'P', 'P', '', '', '', '', '', '', '', '', '', '', 'P', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `kv_empl_cv`
--

CREATE TABLE IF NOT EXISTS `kv_empl_cv` (
  `id` int(10) NOT NULL,
  `empl_id` varchar(10) NOT NULL,
  `empl_firstname` varchar(60) NOT NULL,
  `cv_title` varchar(60) NOT NULL,
  `filename` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `kv_empl_degree`
--

CREATE TABLE IF NOT EXISTS `kv_empl_degree` (
  `id` int(10) NOT NULL,
  `empl_id` varchar(10) NOT NULL,
  `degree` varchar(20) NOT NULL,
  `major` varchar(20) NOT NULL,
  `university` varchar(80) NOT NULL,
  `grade` varchar(20) NOT NULL,
  `year` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `kv_empl_experience`
--

CREATE TABLE IF NOT EXISTS `kv_empl_experience` (
  `id` int(10) NOT NULL,
  `empl_id` varchar(10) NOT NULL,
  `organization` varchar(60) NOT NULL,
  `job_role` varchar(60) NOT NULL,
  `s_date` date NOT NULL,
  `e_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `kv_empl_info`
--

CREATE TABLE IF NOT EXISTS `kv_empl_info` (
  `id` int(5) NOT NULL,
  `empl_id` varchar(10) NOT NULL,
  `empl_salutation` varchar(9) NOT NULL,
  `empl_firstname` varchar(120) NOT NULL,
  `empl_lastname` varchar(50) NOT NULL,
  `addr_line1` varchar(200) NOT NULL,
  `addr_line2` varchar(200) NOT NULL,
  `empl_city` varchar(60) NOT NULL,
  `empl_state` varchar(100) NOT NULL,
  `country` int(5) NOT NULL,
  `gender` int(2) NOT NULL,
  `date_of_birth` date NOT NULL,
  `age` int(3) NOT NULL,
  `marital_status` int(2) NOT NULL,
  `nationality` int(2) NOT NULL,
  `ethnic_origin` int(3) NOT NULL,
  `no_of_child` int(3) NOT NULL,
  `religion` int(2) NOT NULL,
  `weight` int(4) NOT NULL,
  `office_phone` varchar(15) NOT NULL,
  `home_phone` varchar(15) NOT NULL,
  `mobile_phone` varchar(15) NOT NULL,
  `email` varchar(120) NOT NULL,
  `skype_id` varchar(50) NOT NULL,
  `linkedin` varchar(50) NOT NULL,
  `status` int(2) NOT NULL,
  `empl_pic` varchar(10) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kv_empl_info`
--

INSERT INTO `kv_empl_info` (`id`, `empl_id`, `empl_salutation`, `empl_firstname`, `empl_lastname`, `addr_line1`, `addr_line2`, `empl_city`, `empl_state`, `country`, `gender`, `date_of_birth`, `age`, `marital_status`, `nationality`, `ethnic_origin`, `no_of_child`, `religion`, `weight`, `office_phone`, `home_phone`, `mobile_phone`, `email`, `skype_id`, `linkedin`, `status`, `empl_pic`) VALUES
(1, '1001', '1', 'Hong Quang', 'Ngo', '475 Kim Nguu Street', 'Hai Ba Trung District', 'Ha Noi', 'N/A', 238, 1, '1983-04-14', 33, 2, 4, 0, 0, 0, 0, '', '', '0913685381', 'hongquangngo@gmail.com', '', '', 1, ''),
(2, '1002', '1', 'Hong Quan', 'Nguyen', '475 Kim Nguu Street', 'Hai Ba Trung District', 'Ha Noi', 'N/A', 238, 1, '1985-01-02', 31, 2, 4, 0, 0, 0, 0, '', '', '0985388389', 'hongquan2712@gmail.com', '', '', 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `kv_empl_job`
--

CREATE TABLE IF NOT EXISTS `kv_empl_job` (
  `id` int(10) NOT NULL,
  `empl_id` varchar(10) NOT NULL,
  `grade` tinyint(2) NOT NULL,
  `department` tinyint(2) NOT NULL,
  `desig_group` tinyint(2) NOT NULL,
  `desig` varchar(40) NOT NULL,
  `joining` date NOT NULL,
  `empl_type` tinyint(2) NOT NULL,
  `working_branch` tinyint(2) NOT NULL,
  `mod_of_pay` int(2) NOT NULL,
  `bank_name` varchar(40) NOT NULL,
  `acc_no` varchar(30) NOT NULL,
  `basic` int(10) NOT NULL,
  `empl_hra` int(10) NOT NULL,
  `conveyance` int(10) NOT NULL,
  `medical_allowance` int(10) NOT NULL,
  `empl_da` int(10) NOT NULL,
  `edu_other` int(10) NOT NULL,
  `empl_pf` int(10) NOT NULL,
  `empl_esi` int(10) NOT NULL,
  `misc` int(10) NOT NULL,
  `prof_tax` int(10) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kv_empl_job`
--

INSERT INTO `kv_empl_job` (`id`, `empl_id`, `grade`, `department`, `desig_group`, `desig`, `joining`, `empl_type`, `working_branch`, `mod_of_pay`, `bank_name`, `acc_no`, `basic`, `empl_hra`, `conveyance`, `medical_allowance`, `empl_da`, `edu_other`, `empl_pf`, `empl_esi`, `misc`, `prof_tax`) VALUES
(1, '1001', 4, 1, 5, 'IT Manager', '2016-01-01', 2, 0, 1, 'Vietcombank', '0021001340062', 1000, 150, 80, 70, 200, 55, 20, 30, 0, 25),
(2, '1002', 4, 5, 5, 'Technical Manager', '2016-01-01', 2, 0, 1, 'Vietcombank', '0031001340063', 1500, 150, 80, 70, 200, 55, 20, 30, 0, 25);

-- --------------------------------------------------------

--
-- Table structure for table `kv_empl_loan`
--

CREATE TABLE IF NOT EXISTS `kv_empl_loan` (
  `id` int(10) NOT NULL,
  `empl_id` varchar(10) NOT NULL,
  `date` date NOT NULL,
  `loan_amount` decimal(15,2) NOT NULL,
  `loan_type_id` int(5) NOT NULL,
  `periods` int(5) NOT NULL,
  `monthly_pay` decimal(15,2) NOT NULL,
  `periods_paid` int(5) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `kv_empl_option`
--

CREATE TABLE IF NOT EXISTS `kv_empl_option` (
  `id` int(20) NOT NULL,
  `option_name` varchar(150) NOT NULL,
  `option_value` longtext NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kv_empl_option`
--

INSERT INTO `kv_empl_option` (`id`, `option_name`, `option_value`) VALUES
(1, 'weekly_off', 'Sun'),
(2, 'empl_ref_type', '0'),
(3, 'salary_account', '5410'),
(4, 'paid_from_account', '1060'),
(5, 'expd_percentage_amt', '30'),
(6, 'weekly_off', 'Sun'),
(7, 'empl_ref_type', '0'),
(8, 'weekly_off', 'Sun'),
(9, 'empl_ref_type', '0'),
(10, 'next_empl_id', '1'),
(11, 'weekly_off', 'Sun'),
(12, 'empl_ref_type', '0'),
(13, 'weekly_off', 'Sun'),
(14, 'empl_ref_type', '0'),
(15, 'weekly_off', 'Sun'),
(16, 'empl_ref_type', '0'),
(17, 'weekly_off', 'Sun'),
(18, 'empl_ref_type', '0');

-- --------------------------------------------------------

--
-- Table structure for table `kv_empl_salary`
--

CREATE TABLE IF NOT EXISTS `kv_empl_salary` (
  `id` int(20) NOT NULL,
  `empl_id` varchar(10) NOT NULL,
  `month` int(2) NOT NULL,
  `year` int(2) NOT NULL,
  `date` date NOT NULL,
  `gross` int(15) NOT NULL,
  `basic` int(10) NOT NULL,
  `empl_da` int(10) NOT NULL,
  `empl_hra` int(10) NOT NULL,
  `conveyance` int(10) NOT NULL,
  `medical_allowance` int(10) NOT NULL,
  `edu_other` int(10) NOT NULL,
  `lop_amount` int(10) NOT NULL,
  `empl_pf` int(10) NOT NULL,
  `loan` int(10) NOT NULL,
  `adv_sal` int(10) NOT NULL,
  `net_pay` int(10) NOT NULL,
  `prof_tax` int(10) NOT NULL,
  `empl_esi` int(10) NOT NULL,
  `misc` int(10) NOT NULL,
  `ot_other_allowance` int(10) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=137 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kv_empl_salary`
--

INSERT INTO `kv_empl_salary` (`id`, `empl_id`, `month`, `year`, `date`, `gross`, `basic`, `empl_da`, `empl_hra`, `conveyance`, `medical_allowance`, `edu_other`, `lop_amount`, `empl_pf`, `loan`, `adv_sal`, `net_pay`, `prof_tax`, `empl_esi`, `misc`, `ot_other_allowance`) VALUES
(136, '', 10, 43, '2016-10-15', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `kv_empl_training`
--

CREATE TABLE IF NOT EXISTS `kv_empl_training` (
  `id` int(5) NOT NULL,
  `empl_id` varchar(10) NOT NULL,
  `training_desc` varchar(60) NOT NULL,
  `course` varchar(50) NOT NULL,
  `cost` int(8) NOT NULL,
  `institute` varchar(60) NOT NULL,
  `s_date` date NOT NULL,
  `e_date` date NOT NULL,
  `notes` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `kv_loan_types`
--

CREATE TABLE IF NOT EXISTS `kv_loan_types` (
  `id` int(10) NOT NULL,
  `loan_name` varchar(200) NOT NULL,
  `interest_rate` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `locations`
--

CREATE TABLE IF NOT EXISTS `locations` (
  `loc_code` varchar(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `location_name` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `delivery_address` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `phone2` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `fax` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `contact` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `inactive` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `locations`
--

INSERT INTO `locations` (`loc_code`, `location_name`, `delivery_address`, `phone`, `phone2`, `fax`, `email`, `contact`, `inactive`) VALUES
('DEF', 'Default', 'Delivery 1\nDelivery 2\nDelivery 3', '', '', '', '', '', 0),
('GHI', 'GHI', '', '', '', '', '', 'Anne', 0);

-- --------------------------------------------------------

--
-- Table structure for table `loc_stock`
--

CREATE TABLE IF NOT EXISTS `loc_stock` (
  `loc_code` char(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `stock_id` char(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `reorder_level` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `loc_stock`
--

INSERT INTO `loc_stock` (`loc_code`, `stock_id`, `reorder_level`) VALUES
('DEF', '1111', 0),
('DEF', '3333', 0),
('DEF', 'AAA', 0),
('DEF', 'Maint001', 0),
('DEF', 'Sales', 0),
('DEF', 'SP001', 0),
('DEF', 'SP002', 0),
('DEF', 'SP01', 0),
('DEF', 'SP02', 0),
('DEF', 'SP03', 0),
('DEF', 'SP04', 0),
('DEF', 'SP05', 0),
('DEF', 'SP06', 0),
('DEF', 'SP07', 0),
('DEF', 'SP08', 0),
('DEF', 'SP09', 0),
('DEF', 'SP10', 0),
('DEF', 'SP11', 0),
('DEF', 'SP12', 0),
('DEF', 'SP13', 0),
('DEF', 'SP14', 0),
('DEF', 'SV001', 0),
('GHI', 'AAA', 0),
('GHI', 'Maint001', 0),
('GHI', 'SP01', 0),
('GHI', 'SP02', 0),
('GHI', 'SP03', 0),
('GHI', 'SP04', 0),
('GHI', 'SP05', 0),
('GHI', 'SP06', 0),
('GHI', 'SP07', 0),
('GHI', 'SP08', 0),
('GHI', 'SP09', 0),
('GHI', 'SP10', 0),
('GHI', 'SP11', 0),
('GHI', 'SP12', 0),
('GHI', 'SP13', 0),
('GHI', 'SP14', 0);

-- --------------------------------------------------------

--
-- Table structure for table `log`
--

CREATE TABLE IF NOT EXISTS `log` (
  `id` int(11) NOT NULL,
  `table` char(100) NOT NULL,
  `table_id` char(20) NOT NULL,
  `action` int(1) NOT NULL DEFAULT '0',
  `data_old` text,
  `data_new` text,
  `uid` int(11) NOT NULL,
  `ip_address` varchar(20) NOT NULL,
  `user_agent` char(100) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `log`
--

INSERT INTO `log` (`id`, `table`, `table_id`, `action`, `data_old`, `data_new`, `uid`, `ip_address`, `user_agent`, `time`) VALUES
(1, 'fiscal_year', '3', 1, NULL, NULL, 10, '14.182.156.66', 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:47.0) Gecko/20100101 Firefox/47.0', '2016-08-09 01:56:37'),
(2, 'fiscal_year', '4', 1, NULL, NULL, 14, '118.189.170.79', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Saf', '2016-09-13 02:57:34'),
(3, 'fiscal_year', '5', 1, NULL, NULL, 14, '118.189.170.79', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Saf', '2016-09-13 02:57:52'),
(4, 'fiscal_year', '6', 1, NULL, NULL, 14, '118.189.170.79', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.116 Safari/537.', '2016-09-28 06:49:23');

-- --------------------------------------------------------

--
-- Table structure for table `movement_types`
--

CREATE TABLE IF NOT EXISTS `movement_types` (
  `id` int(11) NOT NULL,
  `name` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `inactive` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `movement_types`
--

INSERT INTO `movement_types` (`id`, `name`, `inactive`) VALUES
(1, 'Adjustment', 0),
(2, 'Write Off', 0),
(3, 'Transfer', 0);

-- --------------------------------------------------------

--
-- Table structure for table `msic_division`
--

CREATE TABLE IF NOT EXISTS `msic_division` (
  `id` int(5) NOT NULL,
  `section` int(11) NOT NULL,
  `description` varchar(200) NOT NULL,
  `inactive` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `msic_division`
--

INSERT INTO `msic_division` (`id`, `section`, `description`, `inactive`) VALUES
(1, 1, 'CROPS AND ANIMAL PRODUCTION, HUNTING', 1),
(2, 1, 'FORESTRY & LOGGING', 1),
(3, 1, 'FISHING AND AQUACULTURE', 1),
(4, 2, 'MINING OF COAL AND LIGNITE', 1),
(5, 2, 'EXTRACTION OF CRUDE, PETROLEUM AND NATURAL GAS', 1),
(6, 2, 'MINING OF METAL ORES', 1),
(7, 2, 'OTHER MINING AND QUARRYING', 1),
(8, 2, 'MINING SUPPORT SERVICE ACTIVITIES', 1),
(9, 3, 'MANUFACTURE OF FOOD PRODUCTS', 1),
(10, 3, 'MANUFACTURE OF BEVERAGES  .', 1),
(11, 3, 'MANUFACTURE OF TOBACCO PRODUCTS', 1),
(12, 3, 'MANUFACTURE OF TEXTILES', 1),
(13, 3, 'MANUFACTURE OF WEARING APPAREL', 1),
(14, 3, 'MANUFACTURE OF LEATHER AND RELATED PRODUCTS', 1),
(15, 3, 'MANUFACTURE OF WOOD AND OF PRODUCTS', 1),
(16, 3, 'MANUFACTURE OF PAPER AND PAPER PRODUCTS', 1),
(17, 3, 'PRINTING AND REPRODUCTION OF RECORDED MEDIA', 1),
(18, 3, 'MANUFACTURE OF COKE AND REFINED PETROLEUM PRODUCTS', 1),
(19, 3, 'MANUFACTURE OF CHEMICALS AND CHEMICAL PRODUCTS', 1),
(20, 3, 'MANUFACTURE OF BASIC PHARMACEUTICALS', 1),
(21, 3, 'MANUFACTURE OF RUBBER & PLASTIC PRODUCTS', 1),
(22, 3, 'MANUFACTURE OF OTHER NON-METALLIC MINERAL PRODUCTS', 1),
(23, 3, 'MANUFACTURE OF BASIC METALS', 1),
(24, 3, 'MANUFACTURE OF FABRICATED METAL PRODUCTS', 1),
(25, 3, 'MANUFACTURE OF COMPUTER, ELECTRONIC AND OPTICAL PRODUCTS', 1),
(26, 3, 'MANUFACTURE OF ELECTRICAL EQUIPMENT', 1),
(27, 3, 'MANUFACTURE OF MACHINERY AND EQUIPMENT N.E.0', 1),
(28, 3, 'MANUFACTURE OF MOTOR VEHICLES, TRAILERS AND SEMI-TRAILERS', 1),
(29, 3, 'MANUFACTURE OF OTHER TRANSPORT EQUIPMENT', 1),
(30, 3, 'MANUFACTURE OF FURNITURE', 1),
(31, 3, 'OTHER MANUFACTURING', 1),
(32, 3, 'REPAIR AND INSTALLATION OF MACHINERY AND EQUIPMENT', 1),
(33, 4, 'Electric power generation, transmission and distributio', 1),
(34, 4, 'Manufacture of gas; distribution of gaseous fuels through mains', 1),
(35, 4, 'Steam and air conditioning supply', 1),
(36, 5, 'WATER COLLECTION, TREATMENT & SUPPLY', 1),
(37, 5, 'WASTE COLLECTION, TREATMENT & DISPOSAL', 1),
(38, 6, 'Construction of building', 1),
(39, 6, 'CIVIL ENGINEERING', 1),
(40, 6, 'SPECIALIZED CONSTRUCTION ACTIVTIES', 1),
(41, 7, 'WHOLESALE, RETAIL TRADE, REPAIR OF MOTOR VEHICLES & CYCLES', 1),
(42, 7, 'WHOLESALE TRADE, EXCEPT OF MOTOR VEHICLES AND MOTORCYCLES', 1),
(43, 7, 'RETAIL TRADE, EXCEPT OF MOTOR VEHICLES AND MOTORCYCLES', 1),
(44, 8, 'LAND TRANSPORT AND TRANSPORT VIA PIPELINES', 1),
(45, 8, 'WATER TRANSPORT', 1),
(46, 8, 'AIR TRANSPORT', 1),
(47, 8, 'WAREHOUSING AND SUPPORT ACTIVITIES FOR TRANSPORTATIO', 1),
(48, 8, 'POSTAL AND COURIER-ACTIVITIES', 1),
(49, 9, 'ACCOMMODATIO', 1),
(50, 9, 'FOOD AND BEVERAGE SERVICE ACTIVITIES', 1),
(51, 10, 'INFORMATION AND COMMUNICATIO', 1),
(52, 10, 'MOTION PICTURE, VIDEO AND TELEVISION PROGRAMME PRODUCTION, SOUND RECORDING AND MUSIC PUBLISHING ACTIVITIES', 1),
(53, 10, 'PROGRAMMING AND BROADCASTING ACTIVITIES', 1),
(54, 10, 'COMPUTER PROGRAMMING, CONSULTANCY AND RELATED ACTIVITIES', 1),
(55, 10, 'INFORMATION SERVICE ACTIVITIES', 1),
(56, 11, 'FINANCIAL SERVICE ACTIVITIES', 1),
(57, 11, 'INSURANCE/TAKAFUL, REINSURANCE/RETAKAFUL AND PENSION FUNDING, EXCEPT COMPULSORY SOCIAL SECURITY', 1),
(58, 11, 'ACTIVITIES AUXILIARY TO FINANCIAL SERVICE AND INSURANCE/TAKAFUL ACTIVITIES', 1),
(59, 12, 'REAL ESTATE ACTIVTIES', 1),
(60, 13, 'PROFESSIONAL, SCIENTIFIC AND TECHNICAL ACTIVITIES', 1),
(61, 13, 'ACTIVITIES OF HEAD OFFICES, MANAGEMENT CONSULTANCY ACTIVITIES', 1),
(62, 13, 'ARCHITECTURAL AND ENGINEERING ACTIVITIES, TECHNICAL TESTING AND ANALYSIS', 1),
(63, 13, 'SCIENTIFIC RESEARCH AND DEVELOPMENT', 1),
(64, 13, 'ADVERTISING AND MARKET RESEARCH', 1),
(65, 13, 'OTHER PROFESSIONAL, SCIENTIFIC AND TECHNICAL ACTIVITIES', 1),
(66, 14, 'RENTAL & LEASING ACTIVITIES', 1),
(67, 14, 'EMPLOYMENT ACTIVITIES', 1),
(68, 14, 'TRAVEL AGENCY, TOUR OPERATOR, RESERVATION SERVICE AND RELATED ACTIVITIES', 1),
(69, 14, 'SECURITY AND INVESTIGATION ACTIVITIES', 1),
(70, 14, 'SERVICES TO BUILDING AND LANDSCAPE ACTIVITIES', 1),
(71, 14, 'OFFICE ADMINISTRATIVE, OFFICE SUPPORT AND OTHER BUSINESS SUPPORT ACTIVITIES', 1),
(72, 15, 'PUBLIC ADMINISTRATION AND DEFENCE, COMPULSORY SOCIAL ACTIVITIES', 1),
(73, 16, 'EDUCATIO', 1),
(74, 17, 'HUMAN HEALTH AND SOCIAL WORK ACTIVITIES', 1),
(75, 17, 'RESIDENTIAL CARE ACTIVITIES', 1),
(76, 18, 'CREATIVE, ARTS AND ENTERTAINMENT ACTIVITIES', 1),
(77, 18, 'LIBRARIES, ARCHIVES, MUSEUMS AND OTHER CULTURAL ACTIVITIES', 1),
(78, 18, 'SPORTS ACTIVITIES AND AMUSEMENT AND RECREATION ACTIVITIES', 1),
(79, 19, 'ACTIVITIES''OF MEMBERSHIP ORGANIZATIONS', 1),
(80, 19, 'REPAIR OF COMPUTERS AND PERSONAL AND HOUSEHOLD GOODS', 1),
(81, 19, 'OTHER PERSONAL SERVICE ACTIVITIES', 1),
(82, 20, 'GOODS- AND SERVICES-PRODUCING ACTIVITIES OF HOUSEHOLDS FOR OWN USE', 1),
(83, 21, 'Activities of extraterritorial organizationd bodies', 1);

-- --------------------------------------------------------

--
-- Table structure for table `msic_item`
--

CREATE TABLE IF NOT EXISTS `msic_item` (
  `id` int(5) NOT NULL,
  `division` int(11) NOT NULL,
  `code` varchar(8) NOT NULL,
  `description` varchar(200) NOT NULL,
  `inactive` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `msic_section`
--

CREATE TABLE IF NOT EXISTS `msic_section` (
  `id` int(5) NOT NULL,
  `section` char(1) NOT NULL,
  `description` varchar(150) NOT NULL,
  `inactive` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `msic_section`
--

INSERT INTO `msic_section` (`id`, `section`, `description`, `inactive`) VALUES
(1, 'A', 'AGRICULTURE FORESTRY AND FISHING', 1),
(2, 'B', 'MINING & QUARRYING', 1),
(3, 'C', 'MANUFACTURING', 1),
(4, 'D', 'ELECTRICITY, GAS, STEAM & AIRCON SUPPLY', 1),
(5, 'E', 'WATER SUPPLY, SEWERAGE, WASTE MGT & REMEDIATIO', 1),
(6, 'F', 'CONSTRUCTIO', 1),
(7, 'G', 'WHOLESALE & RETAIL TRADE', 1),
(8, 'H', 'TRANSPORTATION & STORAGE', 1),
(9, 'I', 'ACCOMODATION & FOOD SERVICE ACTIVITIES', 1),
(10, 'J', 'INFORMATION AND COMMUNICATIO', 1),
(11, 'K', 'FINANCIAL AND INSURANCE /TAKAFUL ACTIVITIES ', 1),
(12, 'L', 'REAL ESTATE ACTIVTIES', 1),
(13, 'M', 'PROFESSIONAL, SCIENTIFIC AND TECHNICAL ACTIVITIES', 1),
(14, '', 'ADMINISTRATIVE & SUPPORT SERVICE ACTIVITIES', 1),
(15, 'O', 'PUBLIC ADMIN, DEFENCE, COMPULSORY SOCIAL ACTIVITIES', 1),
(16, 'P', 'EDUCATIO', 1),
(17, 'Q', 'HUMAN HEALTH AND SOCIAL WORK ACTIVITIES', 1),
(18, 'R', 'ARTS, ENTERTAINMENT & RECREATIO', 1),
(19, 'S', 'OTHER SERVICES ACTIVITIES', 1),
(20, 'T', 'ACTIVITIES OF HOUSEHOLDS AS EMPLOYERS; UNDIFFERENTIATED', 1),
(21, 'U', 'ACTIVITIES OF EXTRATERRESTRIAL ORGANIZATIONS', 1);

-- --------------------------------------------------------

--
-- Table structure for table `opening_cache`
--

CREATE TABLE IF NOT EXISTS `opening_cache` (
  `id` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `opening_cache`
--

INSERT INTO `opening_cache` (`id`, `created`, `data`) VALUES
(1, '2016-08-09 12:49:45', '{"id":"1","pay_type":"debit","type":"97","account":"1060","amount":"50000","tran_date":"2015-12-31","gl_tran_id":"74"}'),
(2, '2016-08-09 12:49:45', '{"id":"2","pay_type":"debit","type":"97","account":"1065","amount":"15000","tran_date":"2015-12-31","gl_tran_id":"75"}'),
(3, '2016-08-09 12:49:45', '{"id":"3","pay_type":"debit","type":"97","account":"1200","amount":"10000","tran_date":"2015-12-31","gl_tran_id":"76"}'),
(4, '2016-08-09 12:49:45', '{"id":"4","pay_type":"debit","type":"97","account":"1070","amount":"30000","tran_date":"2015-12-31","gl_tran_id":"77"}'),
(5, '2016-08-09 12:49:45', '{"id":"5","pay_type":"credit","type":"1","account":"2100","amount":"-30000","tran_date":"2015-12-31","gl_tran_id":"78"}'),
(6, '2016-08-10 04:51:53', '{"id":"1","pay_type":"debit","type":"97","account":"1060","amount":"50000","tran_date":"2015-12-31","gl_tran_id":"74"}'),
(7, '2016-08-10 04:51:53', '{"id":"2","pay_type":"debit","type":"97","account":"1065","amount":"15000","tran_date":"2015-12-31","gl_tran_id":"75"}'),
(8, '2016-08-10 04:51:53', '{"id":"3","pay_type":"debit","type":"97","account":"1200","amount":"10000","tran_date":"2015-12-31","gl_tran_id":"76"}'),
(9, '2016-08-10 04:51:53', '{"id":"4","pay_type":"debit","type":"97","account":"1070","amount":"30000","tran_date":"2015-12-31","gl_tran_id":"77"}'),
(10, '2016-08-10 04:51:53', '{"id":"5","pay_type":"credit","type":"1","account":"2100","amount":"-5000","tran_date":"2015-12-31","gl_tran_id":"78"}'),
(11, '2016-08-10 04:51:53', '{"id":"6","pay_type":"credit","type":"1","account":"2620","amount":"-100000","tran_date":"2015-12-31","gl_tran_id":"79"}'),
(12, '2016-08-10 04:52:10', '{"id":"1","pay_type":"debit","type":"97","account":"1060","amount":"50000","tran_date":"2015-12-31","gl_tran_id":"74"}'),
(13, '2016-08-10 04:52:10', '{"id":"2","pay_type":"debit","type":"97","account":"1065","amount":"15000","tran_date":"2015-12-31","gl_tran_id":"75"}'),
(14, '2016-08-10 04:52:10', '{"id":"3","pay_type":"debit","type":"97","account":"1200","amount":"30000","tran_date":"2015-12-31","gl_tran_id":"76"}'),
(15, '2016-08-10 04:52:10', '{"id":"4","pay_type":"debit","type":"97","account":"1070","amount":"30000","tran_date":"2015-12-31","gl_tran_id":"77"}'),
(16, '2016-08-10 04:52:10', '{"id":"5","pay_type":"credit","type":"1","account":"2100","amount":"-35000","tran_date":"2015-12-31","gl_tran_id":"78"}'),
(17, '2016-08-10 04:52:10', '{"id":"6","pay_type":"credit","type":"1","account":"2620","amount":"-100000","tran_date":"2015-12-31","gl_tran_id":"79"}'),
(18, '2016-08-10 08:59:45', '{"id":"1","pay_type":"debit","type":"97","account":"1060","amount":"50000","tran_date":"2015-12-31","gl_tran_id":"74"}'),
(19, '2016-08-10 08:59:45', '{"id":"2","pay_type":"debit","type":"97","account":"1065","amount":"15000","tran_date":"2015-12-31","gl_tran_id":"75"}'),
(20, '2016-08-10 08:59:45', '{"id":"3","pay_type":"debit","type":"97","account":"1200","amount":"30000","tran_date":"2015-12-31","gl_tran_id":"76"}'),
(21, '2016-08-10 08:59:45', '{"id":"4","pay_type":"debit","type":"97","account":"1070","amount":"30000","tran_date":"2015-12-31","gl_tran_id":"77"}'),
(22, '2016-08-10 08:59:45', '{"id":"5","pay_type":"credit","type":"1","account":"2100","amount":"-25000","tran_date":"2015-12-31","gl_tran_id":"78"}'),
(23, '2016-08-10 08:59:45', '{"id":"6","pay_type":"credit","type":"1","account":"2620","amount":"-100000","tran_date":"2015-12-31","gl_tran_id":"79"}'),
(24, '2016-08-10 08:59:56', '{"id":"1","pay_type":"debit","type":"97","account":"1060","amount":"50000","tran_date":"2015-12-31","gl_tran_id":"74"}'),
(25, '2016-08-10 08:59:56', '{"id":"2","pay_type":"debit","type":"97","account":"1065","amount":"15000","tran_date":"2015-12-31","gl_tran_id":"75"}'),
(26, '2016-08-10 08:59:56', '{"id":"3","pay_type":"debit","type":"97","account":"1200","amount":"40000","tran_date":"2015-12-31","gl_tran_id":"76"}'),
(27, '2016-08-10 08:59:56', '{"id":"4","pay_type":"debit","type":"97","account":"1070","amount":"30000","tran_date":"2015-12-31","gl_tran_id":"77"}'),
(28, '2016-08-10 08:59:56', '{"id":"5","pay_type":"credit","type":"1","account":"2100","amount":"-25000","tran_date":"2015-12-31","gl_tran_id":"78"}'),
(29, '2016-08-10 08:59:56', '{"id":"6","pay_type":"credit","type":"1","account":"2620","amount":"-100000","tran_date":"2015-12-31","gl_tran_id":"79"}');

-- --------------------------------------------------------

--
-- Table structure for table `opening_customer`
--

CREATE TABLE IF NOT EXISTS `opening_customer` (
  `id` int(11) NOT NULL,
  `customer_id` char(50) NOT NULL,
  `balance` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `opening_gl`
--

CREATE TABLE IF NOT EXISTS `opening_gl` (
  `id` int(11) NOT NULL,
  `pay_type` char(15) NOT NULL,
  `type` char(20) NOT NULL,
  `account` char(20) NOT NULL,
  `amount` double NOT NULL,
  `tran_date` date NOT NULL,
  `gl_tran_id` int(11) NOT NULL,
  `trans_date` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `opening_gl`
--

INSERT INTO `opening_gl` (`id`, `pay_type`, `type`, `account`, `amount`, `tran_date`, `gl_tran_id`, `trans_date`) VALUES
(1, 'debit', '97', '1060', 50000, '2015-12-31', 74, ''),
(2, 'debit', '97', '1065', 15000, '2015-12-31', 75, ''),
(3, 'debit', '97', '1200', 40000, '2015-12-31', 76, ''),
(4, 'debit', '97', '1070', 30000, '2015-12-31', 77, ''),
(5, 'credit', '1', '2100', -25000, '2015-12-31', 78, ''),
(6, 'credit', '1', '2620', -110000, '2015-12-31', 79, ''),
(7, 'bank', 'bank', '9', 50000, '2015-12-31', 4, ''),
(8, 'bank', 'bank', '''.5.''', 0, '0000-00-00', 41, '2015-12-31'),
(9, 'bank', 'bank', '''.8.''', 0, '0000-00-00', 42, '2015-12-31'),
(10, 'bank', 'bank', '''.9.''', 50, '0000-00-00', 43, '2015-12-31');

-- --------------------------------------------------------

--
-- Table structure for table `opening_gl_system`
--

CREATE TABLE IF NOT EXISTS `opening_gl_system` (
  `id` int(11) NOT NULL,
  `account` int(10) NOT NULL,
  `amount` double NOT NULL,
  `tran_date` date NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `opening_product`
--

CREATE TABLE IF NOT EXISTS `opening_product` (
  `id` int(11) NOT NULL,
  `code` char(20) NOT NULL,
  `cost` int(20) NOT NULL,
  `qty` int(10) NOT NULL,
  `price` int(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `gl_tran_id` int(11) NOT NULL DEFAULT '0',
  `trans_no` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `opening_sale`
--

CREATE TABLE IF NOT EXISTS `opening_sale` (
  `id` int(11) NOT NULL,
  `type` char(15) DEFAULT 'sale',
  `customer` int(11) DEFAULT NULL,
  `branch` int(11) DEFAULT NULL,
  `ref` varchar(40) DEFAULT NULL,
  `trans_no` int(11) DEFAULT NULL,
  `tran_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `amount` double DEFAULT NULL,
  `payment` double DEFAULT NULL,
  `status` bit(1) DEFAULT b'0',
  `debit` double NOT NULL DEFAULT '0',
  `credit` double NOT NULL DEFAULT '0',
  `curr_rate` double NOT NULL DEFAULT '1',
  `currency` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `opening_sale`
--

INSERT INTO `opening_sale` (`id`, `type`, `customer`, `branch`, `ref`, `trans_no`, `tran_date`, `amount`, `payment`, `status`, `debit`, `credit`, `curr_rate`, `currency`) VALUES
(1, '96', 7, 0, 'INV311215', 1, '2015-12-31 05:00:00', NULL, NULL, b'0', 0, 5000, 1, 'SGD'),
(2, '95', 7, 0, 'IV3112', 1, '2015-12-31 05:00:00', NULL, NULL, b'0', 10000, 0, 1, ''),
(3, '95', 8, 0, 'OB2015', 2, '2015-12-31 05:00:00', NULL, NULL, b'0', 30000, 0, 1, ''),
(4, '96', 7, 0, 'OB1210', 2, '2015-12-31 05:00:00', NULL, NULL, b'0', 0, 20000, 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `opening_sale_item`
--

CREATE TABLE IF NOT EXISTS `opening_sale_item` (
  `id` int(11) NOT NULL,
  `sale_id` int(11) NOT NULL,
  `description` tinytext NOT NULL,
  `quantity` double NOT NULL,
  `discount_percent` int(2) DEFAULT NULL,
  `tax_type_id` int(11) DEFAULT NULL,
  `unit_price` double DEFAULT NULL,
  `currency` char(10) DEFAULT NULL,
  `credit` double NOT NULL DEFAULT '0',
  `debit` double NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `payment_terms`
--

CREATE TABLE IF NOT EXISTS `payment_terms` (
  `terms_indicator` int(11) NOT NULL,
  `terms` char(80) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `days_before_due` smallint(6) NOT NULL DEFAULT '0',
  `day_in_following_month` smallint(6) NOT NULL DEFAULT '0',
  `inactive` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `payment_terms`
--

INSERT INTO `payment_terms` (`terms_indicator`, `terms`, `days_before_due`, `day_in_following_month`, `inactive`) VALUES
(1, 'Due 15th Of the Following Month', 0, 17, 0),
(2, 'Due By End Of The Following Month', 0, 30, 0),
(3, 'Payment due within 10 days', 10, 0, 0),
(4, 'Cash Only', 0, 0, 0),
(5, 'Term 30 Days', 30, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `prices`
--

CREATE TABLE IF NOT EXISTS `prices` (
  `id` int(11) NOT NULL,
  `stock_id` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sales_type_id` int(11) NOT NULL DEFAULT '0',
  `curr_abrev` char(3) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `price` double NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `printers`
--

CREATE TABLE IF NOT EXISTS `printers` (
  `id` tinyint(3) unsigned NOT NULL,
  `name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `queue` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `host` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `port` smallint(11) unsigned NOT NULL,
  `timeout` tinyint(3) unsigned NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `printers`
--

INSERT INTO `printers` (`id`, `name`, `description`, `queue`, `host`, `port`, `timeout`) VALUES
(1, 'QL500', 'Label printer', 'QL500', 'server', 127, 20),
(2, 'Samsung', 'Main network printer', 'scx4521F', 'server', 515, 5),
(3, 'Local', 'Local print server at user IP', 'lp', '', 515, 10);

-- --------------------------------------------------------

--
-- Table structure for table `print_profiles`
--

CREATE TABLE IF NOT EXISTS `print_profiles` (
  `id` smallint(6) unsigned NOT NULL,
  `profile` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `report` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `printer` tinyint(3) unsigned DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `print_profiles`
--

INSERT INTO `print_profiles` (`id`, `profile`, `report`, `printer`) VALUES
(1, 'Out of office', '', 0),
(2, 'Sales Department', '', 0),
(3, 'Central', '', 2),
(4, 'Sales Department', '104', 2),
(5, 'Sales Department', '105', 2),
(6, 'Sales Department', '107', 2),
(7, 'Sales Department', '109', 2),
(8, 'Sales Department', '110', 2),
(9, 'Sales Department', '201', 2);

-- --------------------------------------------------------

--
-- Table structure for table `purch_data`
--

CREATE TABLE IF NOT EXISTS `purch_data` (
  `supplier_id` int(11) NOT NULL DEFAULT '0',
  `stock_id` char(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `price` double NOT NULL DEFAULT '0',
  `suppliers_uom` char(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `conversion_factor` double NOT NULL DEFAULT '1',
  `supplier_description` char(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `purch_data`
--

INSERT INTO `purch_data` (`supplier_id`, `stock_id`, `price`, `suppliers_uom`, `conversion_factor`, `supplier_description`) VALUES
(9, '1111', 200, '', 1, 'test'),
(11, 'SP001', 1200, '', 1, 'Apple iPhone 6S'),
(11, 'SP002', 1400, '', 1, 'Apple iPhone 6S Plus'),
(9, 'SP001', 1000, '', 1, 'Apple iPhone 6S'),
(9, 'SP002', 1100, '', 1, 'Apple iPhone 6S Plus'),
(9, 'SV001', 300, '', 1, 'Repair Service'),
(14, 'SV001', 1000, '', 1, 'Purchase of Goods F'),
(12, '1111', 500, '', 1, 'test'),
(9, '3333', 100, '', 1, 'test 2'),
(10, '3333', 500, '', 1, 'test 2'),
(3, '3333', 1000, '', 1, 'test 2'),
(12, '3333', 200, '', 1, 'test 2'),
(2, 'SP01', 200, '', 1, 'Stock Product 01'),
(3, 'SP02', 300, '', 1, 'Stock Product 02'),
(4, 'SP03', 150, '', 1, 'Stock Product 03'),
(5, 'SP04', 120, '', 1, 'Stock product 04'),
(6, 'SP05', 80, '', 1, 'Stock product 05'),
(7, 'SP01', 1000, '', 1, 'Stock Product 01'),
(3, 'AAA', 1000, '', 1, 'AAA'),
(4, 'AAA', 400, '', 1, 'AAA'),
(2, 'AAA', 568, '', 1, 'AAA'),
(7, 'SP02', 200, '', 1, 'Stock Product 02'),
(5, 'SP07', 44, '', 1, 'Stock Product 07'),
(5, 'SP08', 56, '', 1, 'Stock Product 08'),
(5, 'AAA', 800, '', 1, 'AAA'),
(2, 'Maint001', 2000, '', 1, 'Maintenance');

-- --------------------------------------------------------

--
-- Table structure for table `purch_orders`
--

CREATE TABLE IF NOT EXISTS `purch_orders` (
  `order_no` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL DEFAULT '0',
  `comments` tinytext COLLATE utf8_unicode_ci,
  `ord_date` date NOT NULL DEFAULT '0000-00-00',
  `reference` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `requisition_no` tinytext COLLATE utf8_unicode_ci,
  `into_stock_location` varchar(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `delivery_address` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `total` double NOT NULL DEFAULT '0',
  `tax_included` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `purch_orders`
--

INSERT INTO `purch_orders` (`order_no`, `supplier_id`, `comments`, `ord_date`, `reference`, `requisition_no`, `into_stock_location`, `delivery_address`, `total`, `tax_included`) VALUES
(1, 9, '', '2015-10-26', 'auto', '1234', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 20000, 0),
(2, 9, '', '2015-11-03', 'auto', 'supp_ref_01', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 100, 0),
(3, 11, '', '2015-11-03', 'auto', 'SI001', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 148000, 0),
(4, 9, '', '2015-11-03', 'auto', 'SI002', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 2400, 0),
(5, 9, '', '2015-11-03', 'auto', 'SI003', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 2400, 0),
(6, 9, '', '2015-11-03', 'auto', 'SI004', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 2400, 0),
(7, 9, '', '2015-11-03', 'auto', 'SI005', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 1000, 0),
(8, 9, '', '2015-11-03', 'auto', '7777', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 10000, 0),
(9, 14, '', '2015-11-04', 'auto', '6578', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 1000, 0),
(10, 9, '', '2015-11-04', 'auto', 'we123', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 2100, 0),
(11, 9, 'test memo', '2015-11-04', 'auto', '4567', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 100, 0),
(12, 9, '', '2015-11-06', 'auto', '9090', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 100, 0),
(13, 12, '', '2015-11-06', 'auto', '101010', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 100, 0),
(14, 9, 'brfgmh', '2015-11-06', 'auto', '2323', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 100, 0),
(15, 12, 'cvcn', '2015-11-06', 'auto', '2222', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 100, 0),
(16, 12, 'memo test', '2015-11-07', 'auto', '6969', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 100, 0),
(17, 9, '', '2015-11-06', 'auto', '456789', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 200, 0),
(18, 9, 'test memo', '2015-11-10', 'auto', '121212', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 100, 0),
(19, 9, '', '2015-11-10', 'auto', '131313', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 100, 0),
(20, 9, '', '2015-11-10', 'auto', '141414', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 100, 0),
(21, 10, '', '2015-11-08', 'auto', '151515', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 500, 0),
(22, 3, '', '2015-11-08', 'auto', '161616', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 1000, 0),
(23, 9, 'hatt', '2015-11-11', 'auto', '3333', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 1000, 0),
(24, 9, '', '2015-12-13', 'auto', '5566', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 1000, 0),
(25, 14, 'Purchase of Goods F', '2015-11-17', 'auto', '6004', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 1000, 0),
(26, 12, '', '2015-11-16', 'auto', '323232', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 1000, 0),
(27, 9, '', '2015-11-16', 'auto', '6333', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 1000, 0),
(28, 12, '', '2015-11-16', 'auto', '7878', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 2000, 0),
(29, 12, '', '2015-11-16', 'auto', '98759', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 500, 0),
(30, 9, 'test invoice and payment', '2015-02-28', 'auto', '54545', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 100, 0),
(31, 9, 'test credit note', '2015-02-28', 'auto', '31231', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 200, 0),
(32, 2, '', '2016-08-09', 'auto', 'SI001', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 100, 0),
(33, 3, '', '2016-08-01', 'auto', 'SI002', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 2000, 0),
(34, 4, '', '2016-08-02', 'auto', 'SI003', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 1500, 0),
(35, 5, '', '2016-07-01', 'auto', 'SI004', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 600, 0),
(36, 6, '', '2016-05-01', 'auto', 'SI005', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 1600, 0),
(37, 7, '\n', '2016-08-09', 'auto', 'SI7777', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 10000, 0),
(38, 3, '', '2016-08-10', 'auto', 'IN1234', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 1600, 0),
(39, 3, '', '2016-08-10', 'auto', 'IN1235', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 1000, 0),
(40, 4, '', '2016-08-10', 'auto', 'IN1236', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 800, 0),
(41, 2, '', '2016-08-10', 'auto', 'IN1237', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 568, 0),
(42, 7, '', '2016-08-10', 'auto', 'PO1008', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 4000, 0),
(43, 5, '', '2016-08-10', 'auto', 'IN1238', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 256, 0),
(44, 5, '', '2016-08-10', 'auto', 'IN1239', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 800, 0),
(45, 4, '', '2016-08-10', 'auto', 'IN1240', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 400, 0),
(46, 3, '', '2016-08-10', 'auto', 'IV0810', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 1000, 0),
(47, 2, '', '2016-08-10', 'auto', 'IV1609', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 2000, 0),
(48, 2, '', '2016-08-10', 'auto', '#1232', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 200, 0),
(49, 2, '', '2016-08-10', 'auto', '12345', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 568, 0),
(50, 2, '', '2016-08-10', 'auto', 'IN1241', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 568, 0),
(51, 2, '', '2016-08-10', 'auto', 'IS0001', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 2000, 0),
(52, 2, '', '2016-08-10', 'auto', 'INS0001', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 2568, 0),
(53, 2, '', '2016-08-10', 'auto', '234', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 568, 0),
(54, 2, '', '2016-08-25', 'auto', '', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 200, 0),
(55, 2, 'test', '2017-12-31', 'auto', '111', 'DEF', 'Delivery 1\nDelivery 2\nDelivery 3', 568, 0);

-- --------------------------------------------------------

--
-- Table structure for table `purch_order_details`
--

CREATE TABLE IF NOT EXISTS `purch_order_details` (
  `po_detail_item` int(11) NOT NULL,
  `order_no` int(11) NOT NULL DEFAULT '0',
  `item_code` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` tinytext COLLATE utf8_unicode_ci,
  `delivery_date` date NOT NULL DEFAULT '0000-00-00',
  `qty_invoiced` double NOT NULL DEFAULT '0',
  `unit_price` double NOT NULL DEFAULT '0',
  `act_price` double NOT NULL DEFAULT '0',
  `std_cost_unit` double NOT NULL DEFAULT '0',
  `quantity_ordered` double NOT NULL DEFAULT '0',
  `quantity_received` double NOT NULL DEFAULT '0',
  `tax_type_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `purch_order_details`
--

INSERT INTO `purch_order_details` (`po_detail_item`, `order_no`, `item_code`, `description`, `delivery_date`, `qty_invoiced`, `unit_price`, `act_price`, `std_cost_unit`, `quantity_ordered`, `quantity_received`, `tax_type_id`) VALUES
(1, 1, '1111', 'test ', '2015-10-26', 0, 100, 100, 100, 0, 0, 12),
(2, 2, '1111', 'test ', '2015-11-03', 0, 100, 100, 117.89359712501, 0, 0, 39),
(3, 3, 'SP001', 'Apple iPhone 6S', '2015-11-03', 100, 1200, 1200, 1200, 100, 100, 46),
(4, 3, 'SP002', 'Apple iPhone 6S Plus', '2015-11-03', 20, 1400, 1400, 1400, 20, 20, 46),
(5, 4, 'SP001', 'Apple iPhone 6S', '2015-11-03', 2, 1000, 1000, 1197.9591836735, 1, 1, 38),
(6, 4, 'SP002', 'Apple iPhone 6S Plus', '2015-11-03', 2, 1100, 1100, 1383.3333333333, 1, 1, 39),
(7, 4, 'SV001', 'Repair Service', '2015-11-03', 2, 300, 300, 0, 1, 1, 40),
(8, 5, 'SP001', 'Apple iPhone 6S', '2015-11-03', 1, 1000, 1000, 1195.9595959596, 1, 1, 41),
(9, 5, 'SP002', 'Apple iPhone 6S Plus', '2015-11-03', 1, 1100, 1100, 1368.4210526315, 1, 1, 42),
(10, 5, 'SV001', 'Repair Service', '2015-11-03', 1, 300, 300, 0, 1, 1, 43),
(11, 6, 'SP001', 'Apple iPhone 6S', '2015-11-03', 1, 1000, 1000, 1194, 1, 1, 44),
(12, 6, 'SP002', 'Apple iPhone 6S Plus', '2015-11-03', 1, 1100, 1100, 1354.9999999999, 1, 1, 45),
(13, 6, 'SV001', 'Repair Service', '2015-11-03', 1, 300, 300, 0, 1, 1, 47),
(14, 7, 'SP001', 'Apple iPhone 6S', '2015-11-03', 1, 1000, 1000, 1192.0792079208, 1, 1, 48),
(15, 8, '1111', 'test ', '2015-11-03', 100, 100, 100, 100, 100, 100, 46),
(16, 9, 'SV001', 'Repair Service', '2015-11-04', 1, 1000, 1000, 0, 1, 1, 41),
(17, 10, 'SP001', 'Apple iPhone 6S', '2015-11-04', 1, 1000, 1000, 1190.4230335622, 1, 1, 46),
(18, 10, 'SP002', 'Apple iPhone 6S Plus', '2015-11-04', 1, 1100, 1100, 1348.5205784228, 1, 1, 46),
(19, 11, '1111', 'test ', '2015-11-04', 1, 100, 100, 100, 1, 1, 46),
(20, 12, '1111', 'test ', '2015-11-06', 1, 100, 100, 100, 1, 1, 48),
(21, 13, '1111', 'test ', '2015-11-06', 1, 100, 100, 100.42168674699, 1, 1, 48),
(22, 14, '1111', 'test ', '2015-11-06', 1, 100, 100, 100.41648073777, 1, 1, 46),
(23, 15, '1111', 'test ', '2015-11-06', 1, 100, 100, 100.83823097268, 1, 1, 46),
(24, 16, '1111', 'test ', '2015-11-07', 1, 100, 100, 101.24981855132, 1, 1, 46),
(25, 17, '1111', 'test ', '2015-11-06', 1, 100, 100, 101.23438869266, 1, 1, 46),
(26, 17, '3333', 'test 2', '2015-11-06', 1, 100, 100, 100, 1, 1, 46),
(27, 18, '1111', 'test ', '2015-11-10', 1, 100, 100, 101.21914932608, 1, 1, 46),
(28, 19, '1111', 'test ', '2015-11-10', 1, 100, 100, 101.20428165137, 1, 1, 46),
(29, 20, '1111', 'test ', '2015-11-10', 1, 100, 100, 101.18977223388, 1, 1, 46),
(30, 21, '3333', 'test 2', '2015-11-08', 1, 500, 500, 500, 1, 1, 46),
(31, 22, '3333', 'test 2', '2015-11-08', 1, 1000, 1000, 1000, 1, 1, 45),
(32, 23, '1111', 'test ', '2015-11-11', 10, 100, 100, 101.05902803235, 10, 10, 46),
(33, 24, '1111', 'test ', '2015-12-13', 1, 1000, 1000, 110.93750025177, 1, 1, 46),
(34, 25, 'SV001', 'Purchase of Goods F', '2015-11-17', 0, 1000, 1000, 0, 1, 1, 48),
(35, 26, '1111', 'test ', '2015-11-16', 10, 100, 100, 112.44375022659, 10, 10, 48),
(36, 27, '1111', 'test ', '2015-11-16', 0, 100, 100, 117.71100939924, 0, 0, 48),
(37, 28, '3333', 'test 2', '2015-11-16', 10, 200, 200, 320, 10, 10, 48),
(38, 29, '1111', 'test ', '2015-11-16', 1, 500, 500, 116.07110112153, 1, 1, 48),
(39, 30, '1111', 'test ', '2015-02-28', 1, 100, 100, 117.71100939924, 1, 1, 46),
(40, 31, '1111', 'test ', '2015-02-28', 0, 200, 200, 117.71100939924, 0, 0, 46),
(41, 32, 'SP01', 'Stock Product 01', '2016-08-09', 5, 100, 100, 100, 1, 1, 46),
(42, 33, 'SP02', 'Stock Product 02', '2016-08-01', 10, 200, 200, 200, 10, 10, 46),
(43, 34, 'SP03', 'Stock Product 03', '2016-08-02', 10, 150, 150, 150, 10, 10, 46),
(44, 35, 'SP04', 'Stock product 04', '2016-07-01', 5, 120, 120, 120, 5, 5, 46),
(45, 36, 'SP05', 'Stock product 05', '2016-05-01', 20, 80, 80, 80, 20, 20, 46),
(46, 37, 'SP01', 'Stock Product 01', '2016-08-09', 10, 1000, 1000, 1000, 10, 10, 46),
(49, 38, 'AAA', 'AAA', '2016-08-11', 1, 1000, 1000, 1000, 1, 1, 46),
(50, 38, 'SP02', 'Stock Product 02', '2016-08-11', 2, 300, 300, 216.66666666667, 2, 2, 46),
(51, 39, 'AAA', 'AAA', '2016-08-10', 1, 1000, 1000, 1000, 1, 1, 46),
(52, 40, 'AAA', 'AAA', '2016-08-11', 2, 400, 400, 700, 2, 2, 46),
(53, 41, 'AAA', 'AAA', '2016-08-10', 1, 568, 568, 673.6, 1, 1, 41),
(54, 42, 'SP02', 'Stock Product 02', '2016-08-11', 0, 200, 200, 216.66666666667, 0, 0, 46),
(55, 43, 'SP07', 'Stock Product 07', '2016-08-11', 0, 44, 0, 0, 2, 2, 46),
(56, 43, 'SP08', 'Stock Product 08', '2016-08-11', 0, 56, 0, 0, 3, 3, 46),
(57, 44, 'AAA', 'AAA', '2016-08-11', 1, 800, 800, 694.66666666667, 1, 1, 46),
(58, 45, 'AAA', 'AAA', '2016-08-10', 1, 400, 400, 652.57142857143, 1, 1, 46),
(59, 46, 'AAA', 'AAA', '2016-08-10', 1, 1000, 1000, 710.47619047619, 1, 1, 0),
(60, 47, 'Maint001', 'Maintenance ', '2016-08-10', 1, 2000, 2000, 0, 1, 1, 46),
(61, 48, 'SP01', 'Stock Product 01', '2016-08-10', 1, 200, 200, 920, 1, 1, 46),
(62, 49, 'AAA', 'AAA', '2016-08-10', 1, 568, 568, 690.12244897959, 1, 1, 46),
(63, 50, 'AAA', 'AAA', '2016-08-10', 1, 568, 568, 672.67638483965, 1, 1, 46),
(64, 51, 'Maint001', 'Maintenance ', '2016-08-10', 1, 2000, 2000, 0, 1, 1, 46),
(65, 52, 'AAA', 'AAA', '2016-08-10', 1, 568, 568, 659.59183673469, 1, 1, 46),
(66, 52, 'Maint001', 'Maintenance ', '2016-08-10', 1, 2000, 2000, 0, 1, 1, 46),
(67, 53, 'AAA', 'AAA', '2016-08-10', 0, 568, 568, 648.14285714285, 1, 1, 46),
(68, 54, 'SP01', 'Stock Product 01', '2016-08-25', 0, 200, 200, 848, 1, 1, 46),
(69, 55, 'AAA', 'AAA', '2016-11-26', 0, 568, 0, 0, 1, 0, 46);

-- --------------------------------------------------------

--
-- Table structure for table `quick_entries`
--

CREATE TABLE IF NOT EXISTS `quick_entries` (
  `id` smallint(6) unsigned NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT '0',
  `description` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `base_amount` double NOT NULL DEFAULT '0',
  `base_desc` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bal_type` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `quick_entries`
--

INSERT INTO `quick_entries` (`id`, `type`, `description`, `base_amount`, `base_desc`, `bal_type`) VALUES
(1, 1, 'Maintenance', 0, 'Amount', 0),
(2, 4, 'Phone', 0, 'Amount', 0),
(3, 2, 'Cash Sales', 0, 'Amount', 0),
(4, 4, 'Supplier Invoice', 0, 'Base Amount', 0),
(5, 1, 'Utility Expenses', 0, 'Base Amount', 0);

-- --------------------------------------------------------

--
-- Table structure for table `quick_entry_lines`
--

CREATE TABLE IF NOT EXISTS `quick_entry_lines` (
  `id` smallint(6) unsigned NOT NULL,
  `qid` smallint(6) unsigned NOT NULL,
  `amount` double DEFAULT '0',
  `action` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `dest_id` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `dimension_id` smallint(6) unsigned DEFAULT NULL,
  `dimension2_id` smallint(6) unsigned DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `quick_entry_lines`
--

INSERT INTO `quick_entry_lines` (`id`, `qid`, `amount`, `action`, `dest_id`, `dimension_id`, `dimension2_id`) VALUES
(1, 1, 0, 't-', '1', 0, 0),
(2, 2, 0, 't-', '1', 0, 0),
(3, 3, 0, 't-', '1', 0, 0),
(4, 3, 0, '=', '4010', 0, 0),
(5, 1, 0, '=', '5765', 0, 0),
(6, 2, 0, '=', '5780', 0, 0),
(7, 2, 0, '=', '1060', 0, 0),
(8, 4, 0, 'T', '1', 0, 0),
(9, 5, 150, 'a', '5790', 0, 0),
(10, 5, 200, 'a', '5780', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `recurrent_invoices`
--

CREATE TABLE IF NOT EXISTS `recurrent_invoices` (
  `id` smallint(6) unsigned NOT NULL,
  `description` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `order_no` int(11) unsigned NOT NULL,
  `debtor_no` int(11) unsigned DEFAULT NULL,
  `group_no` smallint(6) unsigned DEFAULT NULL,
  `days` int(11) NOT NULL DEFAULT '0',
  `monthly` int(11) NOT NULL DEFAULT '0',
  `begin` date NOT NULL DEFAULT '0000-00-00',
  `end` date NOT NULL DEFAULT '0000-00-00',
  `last_sent` date NOT NULL DEFAULT '0000-00-00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `refs`
--

CREATE TABLE IF NOT EXISTS `refs` (
  `id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '0',
  `reference` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `refs`
--

INSERT INTO `refs` (`id`, `type`, `reference`) VALUES
(1, 0, 'JV 0001'),
(2, 0, 'JV 0002'),
(1, 1, 'IJ/PV/0001'),
(2, 1, 'J/PV/0002'),
(3, 1, 'J/PV/0003'),
(4, 1, 'J/PV/0004'),
(5, 1, 'J/PV/0005'),
(6, 1, 'J/PV/0006'),
(1, 2, 'OR 0001'),
(2, 2, 'OR 0002'),
(3, 2, 'OR 0003'),
(1, 4, 'FT 0001'),
(1, 10, 'IV 0001'),
(2, 10, 'IV 0002'),
(3, 10, 'IV 0003'),
(4, 10, 'IV 0004'),
(5, 10, 'IV 0005'),
(6, 10, 'IV 0006'),
(7, 10, 'IV 0007'),
(8, 10, 'IV 0008'),
(9, 10, 'IV 0009'),
(10, 10, 'IV 0010'),
(11, 10, 'IV 0011'),
(12, 10, 'IV 0012'),
(13, 10, 'IV 0013'),
(14, 10, 'IV 0014'),
(15, 10, 'IV 0015'),
(16, 10, 'IV 0016'),
(17, 10, 'IV 0017'),
(18, 10, 'IV 0018'),
(19, 10, 'IV 0019'),
(20, 10, 'IV 0020'),
(1, 12, 'COR 001'),
(2, 12, 'COR 002'),
(3, 12, 'COR 003'),
(4, 12, 'COR 004'),
(5, 12, 'COR 005'),
(6, 12, 'COR 006'),
(7, 12, 'COR 007'),
(8, 12, 'COR 008'),
(9, 12, 'COR 009'),
(10, 12, 'COR 010'),
(11, 12, 'COR 011'),
(12, 12, 'COR 012'),
(13, 12, 'COR 013'),
(14, 12, 'COR 014'),
(15, 12, 'COR 015'),
(16, 12, 'COR 016'),
(17, 12, 'COR 017'),
(1, 13, 'auto'),
(2, 13, 'auto'),
(3, 13, 'auto'),
(4, 13, 'auto'),
(5, 13, 'auto'),
(6, 13, 'auto'),
(7, 13, 'auto'),
(8, 13, 'auto'),
(9, 13, 'auto'),
(10, 13, 'auto'),
(11, 13, 'auto'),
(12, 13, 'auto'),
(13, 13, 'auto'),
(14, 13, 'auto'),
(15, 13, 'auto'),
(16, 13, 'auto'),
(17, 13, 'auto'),
(18, 13, 'auto'),
(19, 13, 'auto'),
(20, 13, 'auto'),
(21, 13, 'auto'),
(22, 13, 'auto'),
(23, 13, 'auto'),
(1, 17, 'ADJ 0001'),
(2, 17, 'ADJ 0002'),
(32, 18, 'auto'),
(33, 18, 'auto'),
(34, 18, 'auto'),
(35, 18, 'auto'),
(36, 18, 'auto'),
(37, 18, 'auto'),
(38, 18, 'auto'),
(39, 18, 'auto'),
(40, 18, 'auto'),
(41, 18, 'auto'),
(42, 18, 'auto'),
(43, 18, 'auto'),
(44, 18, 'auto'),
(45, 18, 'auto'),
(46, 18, 'auto'),
(47, 18, 'auto'),
(48, 18, 'auto'),
(49, 18, 'auto'),
(50, 18, 'auto'),
(51, 18, 'auto'),
(52, 18, 'auto'),
(53, 18, 'auto'),
(54, 18, 'auto'),
(55, 18, 'auto'),
(1, 20, 'PI 0001'),
(14, 20, 'PI 00018'),
(15, 20, 'PI 00019'),
(2, 20, 'PI 0002'),
(16, 20, 'PI 00020'),
(17, 20, 'PI 00021'),
(18, 20, 'PI 00022'),
(19, 20, 'PI 00023'),
(20, 20, 'PI 00024'),
(3, 20, 'PI 0003'),
(4, 20, 'PI 0004'),
(5, 20, 'PI 0005'),
(6, 20, 'PI 0006'),
(7, 20, 'PI 0007'),
(8, 20, 'PI 0008'),
(9, 20, 'PI 0009'),
(10, 20, 'PI 0010'),
(11, 20, 'PI 0011'),
(12, 20, 'PI 0012'),
(13, 20, 'PI 0013'),
(1, 21, 'SCN 0001'),
(1, 22, 'IJ/PV/0001'),
(2, 22, 'IJ/PV/0002'),
(3, 22, 'IJ/PV/0003'),
(4, 22, 'IJ/PV/0004'),
(5, 22, 'IJ/PV/0005'),
(6, 22, 'IJ/PV/0006'),
(7, 22, 'IJ/PV/0007'),
(8, 22, 'IJ/PV/0008'),
(9, 22, 'IJ/PV/0009'),
(10, 22, 'IJ/PV/0010'),
(11, 22, 'IJ/PV/0011'),
(31, 25, 'auto'),
(32, 25, 'auto'),
(33, 25, 'auto'),
(34, 25, 'auto'),
(35, 25, 'auto'),
(36, 25, 'auto'),
(37, 25, 'auto'),
(38, 25, 'auto'),
(39, 25, 'auto'),
(40, 25, 'auto'),
(41, 25, 'auto'),
(42, 25, 'auto'),
(43, 25, 'auto'),
(44, 25, 'auto'),
(45, 25, 'auto'),
(46, 25, 'auto'),
(47, 25, 'auto'),
(48, 25, 'auto'),
(49, 25, 'auto'),
(50, 25, 'auto'),
(51, 25, 'auto'),
(52, 25, 'auto'),
(53, 25, 'auto'),
(1, 30, 'auto'),
(2, 30, 'auto'),
(3, 30, 'auto'),
(4, 30, 'auto'),
(5, 30, 'auto'),
(6, 30, 'auto'),
(7, 30, 'auto'),
(8, 30, 'auto'),
(9, 30, 'auto'),
(10, 30, 'auto'),
(11, 30, 'auto'),
(12, 30, 'auto'),
(13, 30, 'auto'),
(14, 30, 'auto'),
(15, 30, 'auto'),
(16, 30, 'auto'),
(17, 30, 'auto'),
(18, 30, 'auto'),
(19, 30, 'auto'),
(20, 30, 'auto'),
(21, 30, 'auto'),
(22, 30, 'auto'),
(23, 30, 'auto'),
(24, 30, 'auto'),
(25, 30, 'auto'),
(26, 30, 'auto'),
(1, 32, 'QO 0001'),
(2, 32, 'QO 0002'),
(3, 32, 'QO 0003'),
(4, 32, 'QO 0004'),
(5, 32, 'QO 0005'),
(6, 32, 'QO 0006');

-- --------------------------------------------------------

--
-- Table structure for table `salesman`
--

CREATE TABLE IF NOT EXISTS `salesman` (
  `salesman_code` int(11) NOT NULL,
  `salesman_name` char(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `salesman_phone` char(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `salesman_fax` char(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `salesman_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `provision` double NOT NULL DEFAULT '0',
  `break_pt` double NOT NULL DEFAULT '0',
  `provision2` double NOT NULL DEFAULT '0',
  `inactive` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `salesman`
--

INSERT INTO `salesman` (`salesman_code`, `salesman_name`, `salesman_phone`, `salesman_fax`, `salesman_email`, `provision`, `break_pt`, `provision2`, `inactive`) VALUES
(4, 'Jill', '90430238', '', 'jill@a2000.net', 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `sales_orders`
--

CREATE TABLE IF NOT EXISTS `sales_orders` (
  `order_no` int(11) NOT NULL,
  `trans_type` smallint(6) NOT NULL DEFAULT '30',
  `version` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(1) NOT NULL DEFAULT '0',
  `debtor_no` int(11) NOT NULL DEFAULT '0',
  `branch_code` int(11) NOT NULL DEFAULT '0',
  `reference` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `customer_ref` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `comments` tinytext COLLATE utf8_unicode_ci,
  `ord_date` date NOT NULL DEFAULT '0000-00-00',
  `order_type` int(11) NOT NULL DEFAULT '0',
  `ship_via` int(11) NOT NULL DEFAULT '0',
  `delivery_address` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `contact_phone` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `deliver_to` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `freight_cost` double NOT NULL DEFAULT '0',
  `from_stk_loc` varchar(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `delivery_date` date NOT NULL DEFAULT '0000-00-00',
  `payment_terms` int(11) DEFAULT NULL,
  `total` double NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `sales_orders`
--

INSERT INTO `sales_orders` (`order_no`, `trans_type`, `version`, `type`, `debtor_no`, `branch_code`, `reference`, `customer_ref`, `comments`, `ord_date`, `order_type`, `ship_via`, `delivery_address`, `contact_phone`, `contact_email`, `deliver_to`, `freight_cost`, `from_stk_loc`, `delivery_date`, `payment_terms`, `total`) VALUES
(1, 30, 1, 0, 2, 15, 'auto', '', '', '2016-08-10', 2, 1, 'Ang Mo Kio, Singapore', '', NULL, 'Demo Customer 01', 0, 'DEF', '2016-08-15', 5, 128.4),
(2, 30, 1, 0, 3, 16, 'auto', '', '', '2016-08-11', 2, 1, 'Ang Mo Kio, Singapore', '', NULL, 'Demo Customer 02', 0, 'DEF', '2016-08-20', 5, 246.1),
(3, 30, 1, 0, 4, 17, 'auto', '', '', '2016-07-10', 2, 1, 'Ang Mo Kio, Singapore', '', NULL, 'Demo Customer 03', 0, 'DEF', '2016-09-08', 5, 535),
(4, 30, 1, 0, 5, 18, 'auto', '', '', '2016-08-09', 2, 1, 'Ang Mo Kio, Singapore', '', NULL, 'Demo Customer 04', 0, 'DEF', '2016-09-08', 5, 1551.5),
(5, 30, 1, 0, 6, 19, 'auto', '', '', '2016-08-09', 2, 1, 'Ang Mo Kio, Singapore', '', NULL, 'Demo Customer 05', 0, 'DEF', '2016-09-08', 5, 668.75),
(6, 30, 1, 0, 7, 20, 'auto', '', '', '2016-08-09', 2, 1, 'Singapore ', '', NULL, 'CustomerB', 0, 'DEF', '2016-09-08', 5, 535),
(7, 30, 1, 0, 8, 21, 'auto', '', '', '2016-08-09', 2, 1, 'Changi ', '', NULL, 'Customer JJ', 0, 'DEF', '2016-08-09', 4, 1070),
(8, 30, 1, 0, 8, 21, 'auto', '', 'Sales Quotation # 1', '2016-08-10', 2, 1, 'Changi ', '', NULL, 'Customer JJ', 0, 'DEF', '2016-08-11', 4, 1000),
(9, 30, 3, 0, 8, 21, 'auto', '', 'Sales Quotation # 2', '2016-08-10', 2, 1, 'Changi ', '', NULL, 'Customer JJ', 0, 'DEF', '2016-08-11', 4, 2140),
(10, 30, 1, 0, 8, 21, 'auto', '', '', '2016-08-10', 2, 1, 'Changi ', '', NULL, 'Customer JJ', 0, 'DEF', '2016-08-10', 4, 963),
(11, 30, 0, 0, 7, 20, 'auto', '', 'Sales Quotation # 3', '2016-08-10', 2, 1, 'Singapore ', '', NULL, 'CustomerB', 0, 'DEF', '2016-08-11', 5, 963),
(12, 30, 1, 0, 7, 20, 'auto', 'IN9981', '', '2016-08-10', 2, 1, 'Singapore ', '', NULL, 'CustomerB', 0, 'DEF', '2016-09-09', 5, 813.2),
(13, 30, 2, 0, 7, 20, 'auto', '123', '', '2016-08-10', 2, 1, 'Singapore ', '', NULL, 'CustomerB', 0, 'DEF', '2016-09-09', 5, 1070),
(14, 30, 1, 0, 7, 20, 'auto', '', '', '2016-08-10', 2, 1, 'Singapore ', '', NULL, 'CustomerB', 0, 'DEF', '2016-09-09', 5, 2140),
(15, 30, 0, 0, 2, 15, 'auto', '', '', '2016-08-10', 2, 1, 'Ang Mo Kio, Singapore', '', NULL, 'Demo Customer 01', 0, 'DEF', '2016-08-11', 5, 107),
(16, 30, 2, 0, 7, 20, 'auto', '', '', '2016-08-26', 2, 1, 'Singapore ', '', NULL, 'CustomerB', 0, 'DEF', '2016-09-25', 5, 856),
(17, 30, 1, 0, 3, 16, 'auto', '', '', '2016-08-29', 2, 1, 'Ang Mo Kio, Singapore', '', NULL, 'Demo Customer 02', 0, 'DEF', '2016-09-28', 5, 130),
(18, 30, 1, 0, 3, 16, 'auto', '', '', '2016-09-12', 2, 1, 'Ang Mo Kio, Singapore', '', NULL, 'Demo Customer 02', 0, 'DEF', '2016-10-12', 5, 120),
(19, 30, 1, 0, 8, 21, 'auto', '', '', '2016-09-28', 2, 1, 'Changi ', '', NULL, 'Customer JJ', 0, 'DEF', '2016-09-28', 4, 214),
(20, 30, 1, 0, 3, 16, 'auto', '', '', '2017-02-16', 2, 1, 'Ang Mo Kio, Singapore', '', NULL, 'Demo Customer 02', 0, 'DEF', '2017-02-17', 5, 0),
(21, 30, 1, 0, 4, 17, 'auto', '', '', '2017-02-16', 2, 1, 'Ang Mo Kio, Singapore', '', NULL, 'Demo Customer 03', 0, 'DEF', '2017-02-17', 5, 267.5),
(22, 30, 1, 0, 4, 17, 'auto', '', '', '2017-02-16', 2, 1, 'Ang Mo Kio, Singapore', '', NULL, 'Demo Customer 03', 0, 'DEF', '2017-02-17', 5, 160.5),
(23, 30, 0, 0, 4, 17, 'auto', '', '', '2017-02-16', 2, 1, 'Ang Mo Kio, Singapore', '', NULL, 'Demo Customer 03', 0, 'DEF', '2017-02-17', 5, 642),
(24, 30, 1, 0, 4, 17, 'auto', '', '', '2017-02-16', 2, 1, 'Ang Mo Kio, Singapore', '', NULL, 'Demo Customer 03', 0, 'DEF', '2017-03-18', 5, 747.93),
(25, 30, 1, 0, 5, 18, 'auto', '', '', '2017-02-23', 2, 1, 'Ang Mo Kio, Singapore', '', NULL, 'Demo Customer 04', 0, 'DEF', '2017-03-25', 5, 1070),
(26, 30, 1, 0, 8, 21, 'auto', '', '', '2017-05-06', 2, 1, 'Changi ', '', NULL, 'Customer JJ', 0, 'DEF', '2017-05-06', 4, 222),
(1, 32, 0, 0, 8, 21, 'QO 0001', '', '', '2016-08-10', 2, 1, 'Changi ', '', NULL, 'Customer JJ', 0, 'DEF', '2016-08-11', 4, 1000),
(2, 32, 0, 0, 8, 21, 'QO 0002', '', '', '2016-08-10', 2, 1, 'Changi ', '', NULL, 'Customer JJ', 0, 'DEF', '2016-08-11', 4, 2140),
(3, 32, 0, 0, 7, 20, 'QO 0003', '', '', '2016-08-10', 2, 1, 'Singapore ', '', NULL, 'CustomerB', 0, 'DEF', '2016-08-11', 5, 963),
(4, 32, 0, 0, 7, 20, 'QO 0004', '', '', '2017-02-15', 2, 1, 'Singapore ', '', NULL, 'CustomerB', 0, 'DEF', '2017-02-16', 5, 963),
(5, 32, 0, 0, 2, 15, 'QO 0005', '', '', '2017-02-16', 2, 1, 'Ang Mo Kio, Singapore', '', NULL, 'Demo Customer 01', 0, 'DEF', '2017-02-17', 5, 1070),
(6, 32, 0, 0, 8, 21, 'QO 0006', '', '', '2017-03-07', 2, 1, 'Changi ', '', NULL, 'Customer JJ', 0, 'DEF', '2017-03-08', 4, 749);

-- --------------------------------------------------------

--
-- Table structure for table `sales_order_details`
--

CREATE TABLE IF NOT EXISTS `sales_order_details` (
  `id` int(11) NOT NULL,
  `order_no` int(11) NOT NULL DEFAULT '0',
  `trans_type` smallint(6) NOT NULL DEFAULT '30',
  `stk_code` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` tinytext COLLATE utf8_unicode_ci,
  `qty_sent` double NOT NULL DEFAULT '0',
  `unit_price` double NOT NULL DEFAULT '0',
  `quantity` double NOT NULL DEFAULT '0',
  `discount_percent` double NOT NULL DEFAULT '0',
  `tax_type_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `sales_order_details`
--

INSERT INTO `sales_order_details` (`id`, `order_no`, `trans_type`, `stk_code`, `description`, `qty_sent`, `unit_price`, `quantity`, `discount_percent`, `tax_type_id`) VALUES
(1, 1, 30, 'SP01', 'Stock Product 01', 1, 120, 1, 0, 54),
(2, 2, 30, 'SP02', 'Stock Product 02', 1, 230, 1, 0, 54),
(3, 3, 30, 'SP03', 'Stock Product 03', 2, 250, 2, 0, 54),
(4, 4, 30, 'SP04', 'Stock product 04', 5, 290, 5, 0, 54),
(5, 5, 30, 'SP05', 'Stock product 05', 5, 125, 5, 0, 54),
(6, 6, 30, 'SP11', 'Service Product 01', 1, 500, 1, 0, 54),
(7, 7, 30, 'SP01', 'Stock Product 01', 1, 1000, 1, 0, 54),
(8, 1, 32, 'SP14', 'Service Product 04', 1, 1000, 1, 0, 0),
(9, 8, 30, 'SP14', 'Service Product 04', 1, 1000, 1, 0, 0),
(10, 2, 32, 'AAA', 'AAA', 1, 2000, 1, 0, 54),
(11, 9, 30, 'AAA', 'AAA', 1, 2000, 1, 0, 54),
(12, 10, 30, 'AAA', 'AAA', 1, 900, 1, 0, 54),
(13, 3, 32, 'AAA', 'AAA', 1, 1000, 1, 0.1, 54),
(14, 11, 30, 'AAA', 'AAA', 0, 1000, 1, 0.1, 54),
(15, 12, 30, 'AAA', 'AAA', 1, 560, 1, 0, 54),
(16, 12, 30, 'Maint001', 'Maintenance ', 1, 200, 1, 0, 54),
(17, 13, 30, 'AAA', 'AAA', 1, 1000, 1, 0, 54),
(18, 14, 30, 'AAA', 'AAA', 1200, 0, 1200, 0, 54),
(19, 14, 30, 'SP01', 'Stock Product 01', 1, 2000, 1, 0, 54),
(20, 15, 30, 'SP01', 'Stock Product 01', 0, 100, 1, 0, 54),
(21, 16, 30, 'SP01', 'Stock Product 01', 1, 800, 1, 0, 54),
(22, 17, 30, 'SP11', 'Service Product 01', 1, 50, 1, 0, 49),
(23, 17, 30, 'Maint001', 'Maintenance ', 1, 80, 1, 0, 0),
(24, 18, 30, 'SP01', 'Stock Product 01', 1, 20, 1, 0, 0),
(25, 18, 30, 'AAA', 'AAA', 10, 10, 10, 0, 0),
(26, 19, 30, 'SP01', 'Stock Product 01', 10, 20, 10, 0, 54),
(27, 4, 32, 'SP01', 'Stock Product 01', 0, 1000, 1, 0.1, 26),
(28, 5, 32, 'SP01', 'Stock Product 01', 0, 1000, 1, 0, 26),
(29, 20, 30, 'SP01', 'Stock Product 01', 1, 0, 1, 0, 30),
(30, 21, 30, 'SP01', 'Stock Product 01', 1, 250, 1, 0, 26),
(31, 22, 30, 'AAA', 'AAA', 1, 150, 1, 0, 30),
(32, 23, 30, 'SP01', 'Stock Product 01', 0, 600, 1, 0, 26),
(33, 24, 30, 'AAA', 'AAA', 1, 699, 1, 0, 30),
(34, 25, 30, 'SP01', 'Stock Product 01', 1, 1000, 1, 0, 30),
(35, 6, 32, 'SP01', 'Test', 0, 700, 1, 0, 30);

-- --------------------------------------------------------

--
-- Table structure for table `sales_pos`
--

CREATE TABLE IF NOT EXISTS `sales_pos` (
  `id` smallint(6) unsigned NOT NULL,
  `pos_name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `cash_sale` tinyint(1) NOT NULL,
  `credit_sale` tinyint(1) NOT NULL,
  `pos_location` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `pos_account` smallint(6) unsigned NOT NULL,
  `inactive` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `sales_pos`
--

INSERT INTO `sales_pos` (`id`, `pos_name`, `cash_sale`, `credit_sale`, `pos_location`, `pos_account`, `inactive`) VALUES
(1, '', 1, 1, 'DEF', 5, 0);

-- --------------------------------------------------------

--
-- Table structure for table `sales_types`
--

CREATE TABLE IF NOT EXISTS `sales_types` (
  `id` int(11) NOT NULL,
  `sales_type` char(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tax_included` int(1) NOT NULL DEFAULT '0',
  `factor` double NOT NULL DEFAULT '1',
  `inactive` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `sales_types`
--

INSERT INTO `sales_types` (`id`, `sales_type`, `tax_included`, `factor`, `inactive`) VALUES
(1, 'Tax Included', 1, 1, 0),
(2, 'Tax Excluded', 0, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `security_roles`
--

CREATE TABLE IF NOT EXISTS `security_roles` (
  `id` int(11) NOT NULL,
  `role` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sections` text COLLATE utf8_unicode_ci,
  `areas` text COLLATE utf8_unicode_ci,
  `inactive` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `security_roles`
--

INSERT INTO `security_roles` (`id`, `role`, `description`, `sections`, `areas`, `inactive`) VALUES
(1, 'Inquiries', 'Inquiries', '768;2816;3072;3328;5632;5888;8192;8448;10752;11008;13312;15872;16128', '257;258;259;260;513;514;515;516;517;518;519;520;521;522;523;524;525;773;774;2822;3073;3075;3076;3077;3329;3330;3331;3332;3333;3334;3335;5377;5633;5640;5889;5890;5891;7937;7938;7939;7940;8193;8194;8450;8451;10497;10753;11009;11010;11012;13313;13315;15617;15618;15619;15620;15621;15622;15623;15624;15625;15626;15873;15882;16129;16130;16131;16132', 0),
(2, 'System Administrator', 'System Administrator', '256;512;768;2816;3072;3328;5376;5632;5888;7936;8192;8448;10496;10752;11008;13056;13312;15616;15872;16128;91136', '257;258;259;260;513;514;515;516;517;518;519;520;521;522;523;524;525;526;769;770;771;772;773;774;2817;2818;2819;2820;2821;2822;2823;3073;3074;3082;3075;3076;3077;3078;3079;3080;3081;3329;3330;3331;3332;3333;3334;3335;5377;5633;5634;5635;5636;5637;5641;5638;5639;5640;5889;5890;5891;7937;7938;7939;7940;8193;8194;8195;8196;8197;8449;8450;8451;10497;10753;10754;10755;10756;10757;11009;11010;11011;11012;13057;13313;13314;13315;15617;15618;15619;15620;15621;15622;15623;15624;15628;15625;15626;15627;15873;15874;15875;15876;15877;15878;15879;15880;15883;15881;15882;16129;16130;16131;16132;91236;91237', 0),
(3, 'Salesman', 'Salesman', '768;3072;5632;8192;15872', '773;774;3073;3075;3081;5633;8194;15873', 0),
(4, 'Stock Manager', 'Stock Manager', '2816;3072;3328;5632;5888;8192;8448;10752;11008;13312;15872;16128', '2818;2822;3073;3076;3077;3329;3330;3330;3330;3331;3331;3332;3333;3334;3335;5633;5640;5889;5890;5891;8193;8194;8450;8451;10753;11009;11010;11012;13313;13315;15882;16129;16130;16131;16132', 0),
(5, 'Production Manager', 'Production Manager', '512;768;2816;3072;3328;5376;5632;5888;7936;8192;8448;10496;10752;11008;13056;13312;15616;15872;16128', '257;258;259;260;521;522;523;524;525;526;771;772;773;2817;2818;2819;2820;2821;2822;2823;3073;3074;3082;3075;3076;3077;3078;3079;3080;3081;3329;3330;3331;3332;3333;3334;3335;5377;5633;5634;5635;5636;5637;5641;5638;5639;5640;5889;5890;5891;7937;7938;7939;7940;8193;8194;8195;8196;8197;8449;8450;8451;10497;10753;10754;10755;10756;10757;11009;11010;11011;11012;13057;13313;13314;13315;15617;15618;15619;15620;15621;15622;15623;15624;15876;15877;15880;15882;16129;16130;16131;16132;91236;91237', 0),
(6, 'Purchase Officer', 'Purchase Officer', '512;2816;3072;3328;5376;5632;5888;8192;8448;10752;11008;13312;15616;15872;16128', '521;523;524;2818;2819;2820;2821;2822;2823;3073;3074;3076;3077;3078;3079;3080;3081;3329;3330;3330;3330;3331;3331;3332;3333;3334;3335;5377;5633;5635;5640;5640;5889;5890;5891;8193;8194;8196;8197;8449;8450;8451;10753;10755;11009;11010;11012;13313;13315;15617;15619;15620;15621;15624;15624;15876;15877;15880;15882;16129;16130;16131;16132', 0),
(7, 'AR Officer', 'AR Officer', '512;768;2816;3072;3328;5632;5888;8192;8448;10752;11008;13312;15616;15872;16128', '521;523;524;771;773;774;2818;2819;2820;2821;2822;2823;3073;3073;3074;3075;3076;3077;3078;3079;3080;3081;3081;3329;3330;3330;3330;3331;3331;3332;3333;3334;3335;5633;5633;5634;5637;5638;5639;5640;5640;5889;5890;5891;8193;8194;8194;8196;8197;8450;8451;10753;10755;11009;11010;11012;13313;13315;15617;15619;15620;15621;15624;15624;15873;15876;15877;15878;15880;15882;16129;16130;16131;16132', 0),
(8, 'AP Officer', 'AP Officer', '512;2816;3072;3328;5376;5632;5888;8192;8448;10752;11008;13312;15616;15872;16128', '257;258;259;260;521;523;524;769;770;771;772;773;774;2818;2819;2820;2821;2822;2823;3073;3074;3082;3076;3077;3078;3079;3080;3081;3329;3330;3331;3332;3333;3334;3335;5377;5633;5635;5640;5889;5890;5891;7937;7938;7939;7940;8193;8194;8196;8197;8449;8450;8451;10497;10753;10755;11009;11010;11012;13057;13313;13315;15617;15619;15620;15621;15624;15876;15877;15880;15882;16129;16130;16131;16132', 0),
(9, 'Accountant', 'New Accountant', '512;768;2816;3072;3328;5376;5632;5888;8192;8448;10752;11008;13312;15616;15872;16128;91136', '257;258;259;260;515;516;517;518;521;522;523;524;525;771;772;773;774;2817;2818;2819;2820;2821;2822;2823;3073;3074;3082;3075;3076;3077;3078;3079;3080;3081;3329;3330;3331;3332;3333;3334;3335;5377;5633;5634;5635;5636;5637;5641;5638;5639;5640;5889;5890;5891;7937;7938;7939;7940;8193;8194;8196;8197;8449;8450;8451;10497;10753;10754;10755;11009;11010;11012;13057;13313;13315;15617;15618;15619;15620;15621;15622;15623;15624;15628;15625;15626;15627;15629;15873;15874;15875;15876;15877;15878;15879;15880;15883;15881;15882;15884;16129;16130;16131;16132;91236;91237', 0),
(10, 'Sub Admin', 'Sub Admin', '512;768;2816;3072;3328;5376;5632;5888;7936;8192;8448;13056;13312;15616;15872;16128;91136', '257;258;259;260;513;517;518;519;520;521;522;523;524;525;526;769;771;772;773;774;2817;2818;2819;2820;2821;2822;2823;3073;3074;3082;3075;3076;3077;3078;3079;3080;3081;3329;3330;3331;3332;3333;3334;3335;5377;5633;5634;5635;5636;5637;5641;5638;5639;5640;5889;5890;5891;7937;7938;7939;7940;8193;8194;8195;8196;8197;8449;8450;8451;10497;10753;10754;10755;10756;10757;11009;11010;11011;11012;13057;13313;13314;13315;15617;15618;15619;15620;15621;15622;15623;15624;15628;15625;15626;15627;15873;15874;15875;15876;15877;15878;15879;15880;15882;15884;16129;16130;16131;16132', 0);

-- --------------------------------------------------------

--
-- Table structure for table `shippers`
--

CREATE TABLE IF NOT EXISTS `shippers` (
  `shipper_id` int(11) NOT NULL,
  `shipper_name` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `phone` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `phone2` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `contact` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `address` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `inactive` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `shippers`
--

INSERT INTO `shippers` (`shipper_id`, `shipper_name`, `phone`, `phone2`, `contact`, `address`, `inactive`) VALUES
(1, 'Default', '', '', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `source_reference`
--

CREATE TABLE IF NOT EXISTS `source_reference` (
  `id` int(11) NOT NULL,
  `trans_type` tinyint(5) DEFAULT NULL,
  `trans_no` tinyint(11) DEFAULT NULL,
  `reference` varchar(50) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `source_reference`
--

INSERT INTO `source_reference` (`id`, `trans_type`, `trans_no`, `reference`) VALUES
(1, 10, 1, 'CI001'),
(2, 10, 2, 'CI002'),
(3, 10, 3, 'CI003'),
(4, 10, 4, 'CI004'),
(5, 10, 5, 'CI005'),
(6, 12, 1, 'CP002'),
(7, 10, 6, ''),
(8, 12, 2, ''),
(9, 10, 7, ''),
(10, 12, 4, ''),
(11, 32, 1, ''),
(12, 30, 8, ''),
(13, 32, 2, ''),
(14, 30, 9, ''),
(15, 10, 9, ''),
(16, 1, 1, '3344'),
(17, 32, 3, ''),
(18, 30, 11, ''),
(19, 12, 8, ''),
(20, 12, 9, ''),
(21, 12, 10, ''),
(22, 12, 11, ''),
(23, 12, 12, ''),
(24, 10, 11, ''),
(25, 10, 12, ''),
(26, 2, 1, ''),
(27, 10, 13, ''),
(28, 30, 15, ''),
(29, 12, 13, ''),
(30, 10, 14, ''),
(31, 10, 15, ''),
(32, 1, 2, ''),
(33, 10, 16, ''),
(34, 10, 17, ''),
(35, 12, 15, ''),
(36, 1, 3, ''),
(37, 32, 4, ''),
(38, 32, 5, ''),
(39, 13, 18, ''),
(40, 13, 19, ''),
(41, 13, 20, ''),
(42, 30, 23, ''),
(43, 10, 18, ''),
(44, 1, 4, ''),
(45, 1, 5, ''),
(46, 2, 2, ''),
(47, 1, 6, ''),
(48, 2, 3, ''),
(49, 10, 19, ''),
(50, 12, 16, ''),
(51, 32, 6, '');

-- --------------------------------------------------------

--
-- Table structure for table `sql_trail`
--

CREATE TABLE IF NOT EXISTS `sql_trail` (
  `id` int(11) unsigned NOT NULL,
  `sql` text COLLATE utf8_unicode_ci NOT NULL,
  `result` tinyint(1) NOT NULL,
  `msg` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `stock_category`
--

CREATE TABLE IF NOT EXISTS `stock_category` (
  `category_id` int(11) NOT NULL,
  `description` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `dflt_tax_type` int(11) NOT NULL DEFAULT '1',
  `dflt_units` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'each',
  `dflt_mb_flag` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'B',
  `dflt_sales_act` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `dflt_cogs_act` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `dflt_inventory_act` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `dflt_adjustment_act` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `dflt_assembly_act` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `dflt_dim1` int(11) DEFAULT NULL,
  `dflt_dim2` int(11) DEFAULT NULL,
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  `dflt_no_sale` tinyint(1) NOT NULL DEFAULT '0',
  `msic` char(10) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=51 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `stock_category`
--

INSERT INTO `stock_category` (`category_id`, `description`, `dflt_tax_type`, `dflt_units`, `dflt_mb_flag`, `dflt_sales_act`, `dflt_cogs_act`, `dflt_inventory_act`, `dflt_adjustment_act`, `dflt_assembly_act`, `dflt_dim1`, `dflt_dim2`, `inactive`, `dflt_no_sale`, `msic`) VALUES
(46, 'Default', 1, 'each', 'B', '4010', '5010', '1510', '5040', '1530', 0, 0, 0, 0, NULL),
(50, 'Services', 1, 'each', 'D', '4010', '5010', '1510', '1510', '1530', 0, 0, 0, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `stock_master`
--

CREATE TABLE IF NOT EXISTS `stock_master` (
  `stock_id` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `category_id` int(11) NOT NULL DEFAULT '0',
  `tax_type_id` int(11) NOT NULL DEFAULT '0',
  `description` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `long_description` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `units` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'each',
  `mb_flag` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'B',
  `sales_account` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `cogs_account` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `inventory_account` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `adjustment_account` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `assembly_account` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `dimension_id` int(11) DEFAULT NULL,
  `dimension2_id` int(11) DEFAULT NULL,
  `actual_cost` double NOT NULL DEFAULT '0',
  `last_cost` double NOT NULL DEFAULT '0',
  `material_cost` double NOT NULL DEFAULT '0',
  `labour_cost` double NOT NULL DEFAULT '0',
  `overhead_cost` double NOT NULL DEFAULT '0',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  `no_sale` tinyint(1) NOT NULL DEFAULT '0',
  `editable` tinyint(1) NOT NULL DEFAULT '0',
  `sales_gst_type` int(11) NOT NULL,
  `purchase_gst_type` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `stock_master`
--

INSERT INTO `stock_master` (`stock_id`, `category_id`, `tax_type_id`, `description`, `long_description`, `units`, `mb_flag`, `sales_account`, `cogs_account`, `inventory_account`, `adjustment_account`, `assembly_account`, `dimension_id`, `dimension2_id`, `actual_cost`, `last_cost`, `material_cost`, `labour_cost`, `overhead_cost`, `inactive`, `no_sale`, `editable`, `sales_gst_type`, `purchase_gst_type`) VALUES
('AAA', 46, 0, 'AAA', '', 'each', 'B', '4010', '5010', '1510', '5040', '1530', 0, 0, 0, 0, 648.14285714285, 0, 0, 0, 0, 0, 0, 0),
('Maint001', 46, 0, 'Maintenance ', 'Maintenance ', 'each', 'D', '4010', '5010', '1510', '5040', '1530', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('SP01', 46, 0, 'Test', '', 'each', 'B', '', '', '', '', '1530', 0, 0, 0, 0, 649.33333333333, 0, 0, 0, 0, 0, 30, 25),
('SP02', 46, 0, 'Stock Product 02', 'Demo stock product', 'each', 'B', '4010', '5010', '1510', '5040', '1530', 0, 0, 0, 0, 216.66666666667, 0, 0, 0, 0, 1, 54, 46),
('SP03', 46, 0, 'Stock Product 03', 'Demo stock product', 'each', 'B', '4010', '5010', '1510', '5040', '1530', 0, 0, 0, 0, 150, 0, 0, 0, 0, 1, 54, 46),
('SP04', 46, 0, 'Stock product 04', 'Demo stock product', 'each', 'B', '4010', '5010', '1510', '5040', '1530', 0, 0, 0, 0, 120, 0, 0, 0, 0, 1, 54, 46),
('SP05', 46, 0, 'Stock product 05', 'Demo stock product', 'each', 'B', '4010', '5010', '1510', '5040', '1530', 0, 0, 0, 0, 80, 0, 0, 0, 0, 1, 54, 46),
('SP06', 46, 0, 'Stock Product 06', 'Demo stock product', 'each', 'B', '4010', '5010', '1510', '5040', '1530', 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 54, 46),
('SP07', 46, 0, 'Stock Product 07', 'Demo stock product', 'each', 'B', '4010', '5010', '1510', '5040', '1530', 0, 0, 0, 0, 44, 0, 0, 0, 0, 1, 54, 46),
('SP08', 46, 0, 'Stock Product 08', 'Demo stock product', 'each', 'B', '4010', '5010', '1510', '5040', '1530', 0, 0, 0, 0, 56, 0, 0, 0, 0, 1, 54, 46),
('SP09', 46, 0, 'Stock Product 09', 'Demo stock product', 'each', 'B', '4010', '5010', '1510', '5040', '1530', 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 54, 46),
('SP10', 46, 0, 'Stock Product 10', 'Demo stock product', 'each', 'B', '4010', '5010', '1510', '5040', '1530', 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 54, 46),
('SP11', 50, 0, 'Service Product 01', 'Demo service product', 'each', 'D', '4010', '5010', '1510', '5040', '1530', 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 54, 46),
('SP12', 50, 0, 'Service Product 02', 'Demo service product', 'each', 'D', '4010', '5010', '1510', '5040', '1530', 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 54, 46),
('SP13', 50, 0, 'Service Product 03', 'Demo service product', 'each', 'D', '4010', '5010', '1510', '5040', '1530', 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 54, 46),
('SP14', 50, 0, 'Service Product 04', 'Demo service product', 'each', 'D', '4010', '5010', '1510', '5040', '1530', 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 54, 46);

-- --------------------------------------------------------

--
-- Table structure for table `stock_moves`
--

CREATE TABLE IF NOT EXISTS `stock_moves` (
  `trans_id` int(11) NOT NULL,
  `trans_no` int(11) NOT NULL DEFAULT '0',
  `stock_id` char(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `type` smallint(6) NOT NULL DEFAULT '0',
  `loc_code` char(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tran_date` date NOT NULL DEFAULT '0000-00-00',
  `person_id` int(11) DEFAULT NULL,
  `price` double NOT NULL DEFAULT '0',
  `reference` char(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `qty` double NOT NULL DEFAULT '1',
  `discount_percent` double NOT NULL DEFAULT '0',
  `standard_cost` double NOT NULL DEFAULT '0',
  `visible` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `stock_moves`
--

INSERT INTO `stock_moves` (`trans_id`, `trans_no`, `stock_id`, `type`, `loc_code`, `tran_date`, `person_id`, `price`, `reference`, `qty`, `discount_percent`, `standard_cost`, `visible`) VALUES
(1, 31, 'SP01', 25, 'DEF', '2016-08-09', 2, 100, '', 1, 0, 100, 1),
(2, 32, 'SP02', 25, 'DEF', '2016-08-01', 3, 200, '', 10, 0, 200, 1),
(3, 33, 'SP03', 25, 'DEF', '2016-08-02', 4, 150, '', 10, 0, 150, 1),
(4, 34, 'SP04', 25, 'DEF', '2016-07-01', 5, 120, '', 5, 0, 120, 1),
(5, 35, 'SP05', 25, 'DEF', '2016-05-01', 6, 80, '', 20, 0, 80, 1),
(6, 1, 'SP01', 13, 'DEF', '2016-08-10', 0, 120, 'auto', -1, 0, 100, 1),
(7, 2, 'SP02', 13, 'DEF', '2016-08-11', 0, 230, 'auto', -1, 0, 200, 1),
(8, 3, 'SP03', 13, 'DEF', '2016-07-10', 0, 250, 'auto', -2, 0, 150, 1),
(9, 4, 'SP04', 13, 'DEF', '2016-08-09', 0, 290, 'auto', -5, 0, 120, 1),
(10, 5, 'SP05', 13, 'DEF', '2016-08-09', 0, 125, 'auto', -5, 0, 80, 1),
(11, 6, 'SP11', 13, 'DEF', '2016-08-09', 0, 500, 'auto', -1, 0, 0, 1),
(12, 7, 'SP01', 13, 'DEF', '2016-08-09', 0, 1000, 'auto', -1, 0, 100, 1),
(13, 36, 'SP01', 25, 'DEF', '2016-08-09', 7, 1000, '', 10, 0, 1000, 1),
(14, 37, 'AAA', 25, 'DEF', '2016-08-10', 3, 1000, '', 1, 0, 1000, 1),
(15, 37, 'SP02', 25, 'DEF', '2016-08-10', 3, 300, '', 2, 0, 216.66666666667, 1),
(16, 38, 'AAA', 25, 'DEF', '2016-08-10', 3, 1000, '', 1, 0, 1000, 1),
(17, 39, 'AAA', 25, 'DEF', '2016-08-10', 4, 400, '', 2, 0, 700, 1),
(18, 40, 'AAA', 25, 'DEF', '2016-08-10', 2, 568, '', 1, 0, 673.6, 1),
(19, 41, 'SP02', 25, 'DEF', '2016-08-10', 7, 200, '', 20, 0, 206.25, 1),
(20, 42, 'SP07', 25, 'DEF', '2016-08-10', 5, 44, '', 2, 0, 44, 1),
(21, 42, 'SP08', 25, 'DEF', '2016-08-10', 5, 56, '', 3, 0, 56, 1),
(22, 43, 'AAA', 25, 'DEF', '2016-08-10', 5, 800, '', 1, 0, 694.66666666667, 1),
(23, 8, 'SP14', 13, 'DEF', '2016-08-10', 0, 1000, 'auto', -1, 0, 0, 1),
(24, 44, 'AAA', 25, 'DEF', '2016-08-10', 4, 400, '', 1, 0, 652.57142857143, 1),
(25, 9, 'AAA', 13, 'DEF', '2016-08-10', 0, 900, 'auto', -1, 0, 652.57142857143, 1),
(26, 10, 'AAA', 13, 'DEF', '2016-08-10', 0, 2000, 'auto', -1, 0, 652.57142857143, 1),
(27, 1, 'SP02', 21, 'DEF', '2016-08-10', 7, 200, '', -20, 0, 216.66666666667, 1),
(28, 45, 'AAA', 25, 'DEF', '2016-08-10', 3, 1000, '', 1, 0, 710.47619047619, 1),
(29, 46, 'Maint001', 25, 'DEF', '2016-08-10', 2, 2000, '', 1, 0, 0, 1),
(30, 47, 'SP01', 25, 'DEF', '2016-08-10', 2, 200, '', 1, 0, 920, 1),
(31, 48, 'AAA', 25, 'DEF', '2016-08-10', 2, 568, '', 1, 0, 690.12244897959, 1),
(32, 11, 'AAA', 13, 'DEF', '2016-08-10', 0, 560, 'auto', -1, 0, 690.12244897959, 1),
(33, 11, 'Maint001', 13, 'DEF', '2016-08-10', 0, 200, 'auto', -1, 0, 0, 1),
(34, 49, 'AAA', 25, 'DEF', '2016-08-10', 2, 568, '', 1, 0, 672.67638483965, 1),
(35, 50, 'Maint001', 25, 'DEF', '2016-08-10', 2, 2000, '', 1, 0, 0, 1),
(36, 51, 'AAA', 25, 'DEF', '2016-08-10', 2, 568, '', 1, 0, 659.59183673469, 1),
(37, 51, 'Maint001', 25, 'DEF', '2016-08-10', 2, 2000, '', 1, 0, 0, 1),
(38, 12, 'AAA', 13, 'DEF', '2016-08-10', 0, 1000, 'auto', -1, 0, 659.59183673469, 1),
(39, 52, 'AAA', 25, 'DEF', '2016-08-10', 2, 568, '', 1, 0, 648.14285714285, 1),
(42, 13, 'SP01', 13, '', '2016-08-10', 0, 2000, 'IV 0013', -1, 0, 920, 1),
(43, 53, 'SP01', 25, 'DEF', '2016-08-25', 2, 200, '', 1, 0, 848, 1),
(44, 1, 'SP01', 17, 'DEF', '2016-08-26', 0, 0, 'ADJ 0001', 10, 0, 500, 1),
(45, 2, 'SP01', 17, 'DEF', '2016-08-26', 0, 0, 'ADJ 0002', 10, 0, 600, 1),
(46, 14, 'SP01', 13, 'DEF', '2016-08-26', 0, 800, 'auto', -1, 0, 649.33333333333, 1),
(47, 15, 'SP11', 13, 'DEF', '2016-08-29', 0, 50, 'auto', -1, 0, 0, 1),
(48, 15, 'Maint001', 13, 'DEF', '2016-08-29', 0, 80, 'auto', -1, 0, 0, 1),
(51, 16, 'SP01', 13, '', '2016-09-12', 0, 20, 'IV 0016', -1, 0, 649.33333333333, 1),
(52, 16, 'AAA', 13, '', '2016-09-12', 0, 10, 'IV 0016', -10, 0, 648.14285714285, 1),
(53, 16, 'SP09', 13, '', '2016-09-12', 0, 5, 'IV 0016', -5, 0, 0, 1),
(54, 17, 'SP01', 13, 'DEF', '2016-09-28', 0, 20, 'auto', -10, 0, 649.33333333333, 1),
(55, 18, 'SP01', 13, 'DEF', '2017-02-16', 0, 0, 'auto', -1, 0, 649.33333333333, 1),
(56, 19, 'SP01', 13, 'DEF', '2017-02-16', 0, 250, 'auto', -1, 0, 649.33333333333, 1),
(57, 20, 'AAA', 13, 'DEF', '2017-02-16', 0, 150, 'auto', -1, 0, 648.14285714285, 1),
(58, 21, 'AAA', 13, 'DEF', '2017-02-16', 0, 699, 'auto', -1, 0, 648.14285714285, 1),
(59, 22, 'SP01', 13, 'DEF', '2017-02-23', 0, 1000, 'auto', -1, 0, 649.33333333333, 1);

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE IF NOT EXISTS `suppliers` (
  `supplier_id` int(11) NOT NULL,
  `supp_name` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `supp_ref` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `supp_address` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `gst_no` varchar(25) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `contact` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `supp_account_no` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `website` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `bank_account` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `curr_code` char(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payment_terms` int(11) DEFAULT NULL,
  `tax_included` tinyint(1) NOT NULL DEFAULT '0',
  `dimension_id` int(11) DEFAULT '0',
  `dimension2_id` int(11) DEFAULT '0',
  `tax_group_id` int(11) DEFAULT NULL,
  `credit_limit` double NOT NULL DEFAULT '0',
  `purchase_account` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `payable_account` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `payment_discount_account` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `notes` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  `supplier_tax_id` int(11) DEFAULT NULL,
  `industry_code` int(11) DEFAULT NULL,
  `valid_gst` tinyint(1) NOT NULL DEFAULT '1',
  `last_verifile` date DEFAULT NULL,
  `self_bill` tinyint(1) DEFAULT '0',
  `self_bill_approval_ref` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`supplier_id`, `supp_name`, `supp_ref`, `address`, `supp_address`, `gst_no`, `contact`, `supp_account_no`, `website`, `bank_account`, `curr_code`, `payment_terms`, `tax_included`, `dimension_id`, `dimension2_id`, `tax_group_id`, `credit_limit`, `purchase_account`, `payable_account`, `payment_discount_account`, `notes`, `inactive`, `supplier_tax_id`, `industry_code`, `valid_gst`, `last_verifile`, `self_bill`, `self_bill_approval_ref`) VALUES
(3, 'Demo Supplier 02', 'Demo Supplier 02', '', '', '123456788', '', '', '', 'OCBC / 0011001247611', 'SGD', 5, 0, 0, 0, NULL, 0, '5710', '2100', '5060', '', 0, 0, NULL, 0, '0000-00-00', 0, ''),
(2, 'Demo Supplier 01', 'Demo Supplier 01', '', '', '123456789', '', '', '', 'OCBC / 0011001247610', 'SGD', 5, 0, 0, 0, NULL, 0, '5710', '2100', '5060', '', 0, 0, NULL, 0, '0000-00-00', 0, ''),
(4, 'Demo Supplier 03', 'Demo Supplier 03', '', '', '123456787', '', '', '', 'OCBC / 0011001247609', 'SGD', 5, 0, 0, 0, NULL, 0, '5710', '2100', '5060', '', 0, 0, NULL, 0, '0000-00-00', 0, ''),
(5, 'Demo Supplier 04', 'Demo Supplier 04', '', '', '123456786', '', '', '', 'OCBC / 0011001247608', 'SGD', 5, 0, 0, 0, NULL, 0, '5710', '2100', '5060', '', 0, 0, NULL, 0, '0000-00-00', 0, ''),
(6, 'Demo Supplier 05', 'Demo Supplier 05', '', '', '123456785', '', '', '', 'OCBC / 0011001247607', 'SGD', 5, 0, 0, 0, NULL, 0, '5710', '2100', '5060', '', 0, 0, NULL, 0, '0000-00-00', 0, ''),
(7, 'SupplierM', 'Supplier M', 'SG', '', '', '', '', '', '', 'SGD', 4, 0, 0, 0, NULL, 0, '', '2100', '5060', '', 0, NULL, NULL, 0, '0000-00-00', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `supp_allocations`
--

CREATE TABLE IF NOT EXISTS `supp_allocations` (
  `id` int(11) NOT NULL,
  `amt` double unsigned DEFAULT NULL,
  `date_alloc` date NOT NULL DEFAULT '0000-00-00',
  `trans_no_from` int(11) DEFAULT NULL,
  `trans_type_from` int(11) DEFAULT NULL,
  `trans_no_to` int(11) DEFAULT NULL,
  `trans_type_to` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `supp_allocations`
--

INSERT INTO `supp_allocations` (`id`, `amt`, `date_alloc`, `trans_no_from`, `trans_type_from`, `trans_no_to`, `trans_type_to`) VALUES
(1, 107, '2016-08-09', 1, 22, 1, 20),
(2, 2140, '2016-08-09', 2, 22, 2, 20),
(3, 5000, '2016-08-09', 3, 22, 1, 96),
(4, 10700, '2016-08-09', 3, 22, 6, 20),
(5, 1712, '2016-08-10', 4, 22, 7, 20),
(6, 1070, '2016-08-10', 5, 22, 8, 20),
(7, 856, '2016-08-10', 6, 22, 9, 20),
(8, 1605, '2016-08-10', 7, 22, 3, 20),
(9, 4280, '2016-08-10', 8, 22, 11, 20),
(10, 568, '2016-08-10', 9, 22, 10, 20),
(11, 1000, '2016-08-10', 10, 22, 14, 20),
(12, 2140, '2016-08-10', 11, 22, 15, 20);

-- --------------------------------------------------------

--
-- Table structure for table `supp_invoice_items`
--

CREATE TABLE IF NOT EXISTS `supp_invoice_items` (
  `id` int(11) NOT NULL,
  `supp_trans_no` int(11) DEFAULT NULL,
  `supp_trans_type` int(11) DEFAULT NULL,
  `gl_code` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `grn_item_id` int(11) DEFAULT NULL,
  `po_detail_item_id` int(11) DEFAULT NULL,
  `stock_id` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` tinytext COLLATE utf8_unicode_ci,
  `quantity` double NOT NULL DEFAULT '0',
  `unit_price` double NOT NULL DEFAULT '0',
  `unit_tax` double NOT NULL DEFAULT '0',
  `memo_` tinytext COLLATE utf8_unicode_ci,
  `tax_type_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `supp_invoice_items`
--

INSERT INTO `supp_invoice_items` (`id`, `supp_trans_no`, `supp_trans_type`, `gl_code`, `grn_item_id`, `po_detail_item_id`, `stock_id`, `description`, `quantity`, `unit_price`, `unit_tax`, `memo_`, `tax_type_id`) VALUES
(5, 2, 20, '0', 41, 42, 'SP02', 'Stock Product 02', 10, 200, 0, '', 46),
(6, 3, 20, '0', 42, 43, 'SP03', 'Stock Product 03', 10, 150, 0, '', 46),
(7, 4, 20, '0', 43, 44, 'SP04', 'Stock product 04', 5, 120, 0, '', 46),
(8, 5, 20, '0', 44, 45, 'SP05', 'Stock product 05', 20, 80, 0, '', 46),
(9, 6, 20, '0', 45, 46, 'SP01', 'Stock Product 01', 10, 1000, 0, '', 46),
(10, 7, 20, '0', 46, 49, 'AAA', 'AAA', 1, 1000, 0, '', 46),
(11, 7, 20, '0', 47, 50, 'SP02', 'Stock Product 02', 2, 300, 0, '', 46),
(12, 8, 20, '0', 48, 51, 'AAA', 'AAA', 1, 1000, 0, '', 46),
(13, 9, 20, '0', 49, 52, 'AAA', 'AAA', 2, 400, 0, '', 46),
(14, 10, 20, '0', 50, 53, 'AAA', 'AAA', 1, 568, 0, '', 41),
(15, 11, 20, '0', 51, 54, 'SP02', 'Stock Product 02', 20, 200, 0, '', 46),
(16, 12, 20, '0', 54, 57, 'AAA', 'AAA', 1, 800, 0, '', 46),
(17, 13, 20, '0', 55, 58, 'AAA', 'AAA', 1, 400, 0, '', 46),
(18, 1, 21, '0', 51, 54, 'SP02', 'Stock Product 02', -20, 200, -0, '', 46),
(19, 1, 20, '0', 40, 41, 'SP01', 'Stock Product 01', 1, 100, 7, NULL, 46),
(20, 14, 20, '0', 56, 59, 'AAA', 'AAA', 1, 1000, 0, '', 0),
(21, 15, 20, '0', 57, 60, 'Maint001', 'Maintenance ', 1, 2000, 0, '', 46),
(22, 16, 20, '0', 58, 61, 'SP01', 'Stock Product 01', 1, 200, 0, '', 46),
(23, 17, 20, '0', 59, 62, 'AAA', 'AAA', 1, 568, 0, '', 46),
(24, 18, 20, '0', 60, 63, 'AAA', 'AAA', 1, 568, 0, '', 46),
(25, 19, 20, '0', 61, 64, 'Maint001', 'Maintenance ', 1, 2000, 0, '', 46),
(26, 20, 20, '0', 62, 65, 'AAA', 'AAA', 1, 568, 0, '', 46),
(27, 20, 20, '0', 63, 66, 'Maint001', 'Maintenance ', 1, 2000, 0, '', 46);

-- --------------------------------------------------------

--
-- Table structure for table `supp_trans`
--

CREATE TABLE IF NOT EXISTS `supp_trans` (
  `trans_no` int(11) unsigned NOT NULL DEFAULT '0',
  `type` smallint(6) unsigned NOT NULL DEFAULT '0',
  `supplier_id` int(11) unsigned DEFAULT NULL,
  `reference` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `supp_reference` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tran_date` date NOT NULL DEFAULT '0000-00-00',
  `due_date` date NOT NULL DEFAULT '0000-00-00',
  `ov_amount` double NOT NULL DEFAULT '0',
  `ov_discount` double NOT NULL DEFAULT '0',
  `ov_gst` double NOT NULL DEFAULT '0',
  `rate` double NOT NULL DEFAULT '1',
  `alloc` double NOT NULL DEFAULT '0',
  `tax_included` tinyint(1) NOT NULL DEFAULT '0',
  `fixed_access` tinyint(1) NOT NULL DEFAULT '0',
  `tpe` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cheque` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `imported_goods` tinyint(1) DEFAULT '0',
  `paid_tax` tinyint(1) DEFAULT '0',
  `permit` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `supp_trans`
--

INSERT INTO `supp_trans` (`trans_no`, `type`, `supplier_id`, `reference`, `supp_reference`, `tran_date`, `due_date`, `ov_amount`, `ov_discount`, `ov_gst`, `rate`, `alloc`, `tax_included`, `fixed_access`, `tpe`, `cheque`, `reason`, `imported_goods`, `paid_tax`, `permit`) VALUES
(1, 20, 2, 'PI 0001', 'SI001', '2016-08-09', '2016-09-08', 100, 0, 7, 1, 107, 0, 0, '', NULL, NULL, 0, 0, ''),
(2, 20, 3, 'PI 0002', 'SI002', '2016-08-01', '2016-09-01', 2000, 0, 140, 1, 2140, 0, 0, '', NULL, NULL, 0, 0, ''),
(3, 20, 4, 'PI 0003', 'SI003', '2016-08-02', '2016-09-01', 1500, 0, 105, 1, 1605, 0, 0, '', NULL, NULL, 0, 0, ''),
(4, 20, 5, 'PI 0004', 'SI004', '2016-07-01', '2016-07-31', 600, 0, 42, 1, 0, 0, 0, '', NULL, NULL, 0, 0, ''),
(5, 20, 6, 'PI 0005', 'SI005', '2016-05-01', '2016-05-31', 1600, 0, 112, 1, 0, 0, 0, '', NULL, NULL, 0, 0, ''),
(6, 20, 7, 'PI 0006', 'SI7777', '2016-08-09', '2016-08-09', 10000, 0, 700, 1, 10700, 0, 0, '', NULL, NULL, 0, 0, ''),
(7, 20, 3, 'PI 0007', 'IN1234', '2016-08-10', '2016-08-10', 1600, 0, 112, 1, 1712, 0, 0, '', NULL, '', 0, 0, NULL),
(8, 20, 3, 'PI 0008', 'IN1235', '2016-08-10', '2016-09-09', 1000, 0, 70, 1, 1070, 0, 0, '', NULL, NULL, 0, 0, ''),
(9, 20, 4, 'PI 0009', 'IN1236', '2016-08-10', '2016-08-10', 800, 0, 56, 1, 856, 0, 0, '', NULL, '', 0, 0, NULL),
(10, 20, 2, 'PI 0010', 'IN1237', '2016-08-10', '2016-09-09', 568, 0, 0, 1, 568, 0, 0, '', NULL, NULL, 0, 0, ''),
(11, 20, 7, 'PI 0011', 'IV1008', '2016-08-10', '2016-08-10', 4000, 0, 280, 1, 4280, 0, 0, '', NULL, '', 0, 0, NULL),
(12, 20, 5, 'PI 0012', 'IN1239', '2016-08-10', '2016-08-10', 800, 0, 56, 1, 0, 0, 0, '', NULL, '', 0, 0, NULL),
(13, 20, 4, 'PI 0013', 'IN1240', '2016-08-10', '2016-09-09', 400, 0, 28, 1, 0, 0, 0, '', NULL, NULL, 0, 0, ''),
(14, 20, 3, 'PI 00018', 'IV0810', '2016-08-10', '2016-09-09', 1000, 0, 0, 1, 1000, 0, 0, '', NULL, NULL, 0, 0, ''),
(15, 20, 2, 'PI 00019', 'IV1609', '2016-08-10', '2016-09-09', 2000, 0, 140, 1, 2140, 0, 0, '', NULL, NULL, 0, 0, ''),
(16, 20, 2, 'PI 00020', '#1232', '2016-08-10', '2016-09-09', 200, 0, 14, 1, 0, 0, 0, '', NULL, NULL, 0, 0, ''),
(17, 20, 2, 'PI 00021', '12345', '2016-08-10', '2016-09-09', 568, 0, 39.76, 1, 0, 0, 0, '', NULL, NULL, 0, 0, ''),
(18, 20, 2, 'PI 00022', 'IN1241', '2016-08-10', '2016-09-09', 568, 0, 39.76, 1, 0, 0, 0, '', NULL, NULL, 0, 0, ''),
(19, 20, 2, 'PI 00023', 'IS0001', '2016-08-10', '2016-09-09', 2000, 0, 140, 1, 0, 0, 0, '', NULL, NULL, 0, 0, ''),
(20, 20, 2, 'PI 00024', 'INS0001', '2016-08-10', '2016-09-09', 2568, 0, 179.76, 1, 0, 0, 0, '', NULL, NULL, 0, 0, ''),
(1, 21, 7, 'SCN 0001', 'CN0810', '2016-08-10', '2016-08-10', -4000, 0, -280, 1, 0, 0, 0, '', NULL, 'Wrong Order', 0, 0, NULL),
(1, 22, 2, 'IJ/PV/0001', '', '2016-08-09', '2016-08-09', -107, 0, 0, 1, 107, 0, 0, '', 'PC001', '', 0, 0, NULL),
(2, 22, 3, 'IJ/PV/0002', '', '2016-08-09', '2016-08-09', -2140, 0, 0, 1, 2140, 0, 0, '', 'PC002', '', 0, 0, NULL),
(3, 22, 7, 'IJ/PV/0003', '', '2016-08-09', '2016-08-09', -15700, 0, 0, 1, 15700, 0, 0, '', '', '', 0, 0, NULL),
(4, 22, 3, 'IJ/PV/0004', '', '2016-08-10', '2016-08-10', -1700, -12, 0, 1, 1712, 0, 0, '', '', '', 0, 0, NULL),
(5, 22, 3, 'IJ/PV/0005', '', '2016-08-10', '2016-08-10', -1000, -70, 0, 1, 1070, 0, 0, '', '654321', '', 0, 0, NULL),
(6, 22, 4, 'IJ/PV/0006', '', '2016-08-10', '2016-08-10', -850, -6, 0, 1, 856, 0, 0, '', '', '', 0, 0, NULL),
(7, 22, 4, 'IJ/PV/0007', '', '2016-08-10', '2016-08-10', -1605, 0, 0, 1, 1605, 0, 0, '', '', '', 0, 0, NULL),
(8, 22, 7, 'IJ/PV/0008', '', '2016-08-10', '2016-08-10', -4280, 0, 0, 1, 4280, 0, 0, '', '', '', 0, 0, NULL),
(9, 22, 2, 'IJ/PV/0009', '', '2016-08-10', '2016-08-10', -568, 0, 0, 1, 568, 0, 0, '', '', '', 0, 0, NULL),
(10, 22, 3, 'IJ/PV/0010', '', '2016-08-10', '2016-08-10', -1000, 0, 0, 1, 1000, 0, 0, '', '', '', 0, 0, NULL),
(11, 22, 2, 'IJ/PV/0011', '', '2016-08-10', '2016-08-10', -2140, 0, 0, 1, 2140, 0, 0, '', '', '', 0, 0, NULL),
(1, 96, 7, 'INV311215', '', '2015-12-31', '2015-12-31', 5000, 0, 0, 1, 5000, 0, 0, '1', NULL, NULL, 0, 0, NULL),
(2, 96, 7, 'OB1210', '', '2015-12-31', '2015-12-31', 20000, 0, 0, 1, 0, 0, 0, '1', NULL, NULL, 0, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sys_expense_type`
--

CREATE TABLE IF NOT EXISTS `sys_expense_type` (
  `id` int(11) NOT NULL,
  `title` varchar(25) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sys_expense_type`
--

INSERT INTO `sys_expense_type` (`id`, `title`) VALUES
(1, 'Test expense type');

-- --------------------------------------------------------

--
-- Table structure for table `sys_prefs`
--

CREATE TABLE IF NOT EXISTS `sys_prefs` (
  `name` varchar(35) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `category` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `length` smallint(6) DEFAULT NULL,
  `value` tinytext COLLATE utf8_unicode_ci
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `sys_prefs`
--

INSERT INTO `sys_prefs` (`name`, `category`, `type`, `length`, `value`) VALUES
('baddeb_sale_reverse', NULL, '', NULL, '4015'),
('baddeb_sale_tax_reverse', NULL, '', NULL, 'A2150'),
('baddeb_purchase_reverse', NULL, '', NULL, '5620'),
('baddeb_purchase_tax_reverse', NULL, '', NULL, 'A1300'),
('baddeb_sale_tax', NULL, '', NULL, '35'),
('baddeb_purchase_tax', NULL, '', NULL, '25'),
('gst_start_date', NULL, '', NULL, '2016-08-07'),
('gst_default_code', NULL, '', NULL, NULL),
('self_bill_approval_ref', NULL, '', NULL, NULL),
('self_bill_start_date', NULL, '', NULL, NULL),
('self_bill_end_date', NULL, '', NULL, NULL),
('maximum_claimable_currency', NULL, '', NULL, NULL),
('maximum_claimable_input_tax', NULL, '', NULL, NULL),
('rounding_difference_act', NULL, '', NULL, '4451'),
('coy_name', 'setup.company', 'varchar', 60, 'J-Consulting Group Pte Ltd'),
('gst_no', 'setup.company', 'varchar', 25, '001018863616'),
('coy_no', 'setup.company', 'varchar', 25, '001538236-U'),
('tax_prd', 'setup.company', 'int', 11, '3'),
('tax_last', 'setup.company', 'int', 11, '9'),
('postal_address', 'setup.company', 'tinytext', 0, '5 Ang Mo Kio Industrial Park 2A \n#07-17 AMK TECH II \nSingapore 567760'),
('custom_duty', NULL, '', NULL, NULL),
('phone', 'setup.company', 'varchar', 30, '+65 6720 2000'),
('fax', 'setup.company', 'varchar', 30, NULL),
('email', 'setup.company', 'varchar', 100, 'contact@uniq365.com'),
('coy_logo', 'setup.company', 'varchar', 100, 'LOGO-1487048390.png'),
('domicile', 'setup.company', 'varchar', 55, 'Singapore'),
('curr_default', 'setup.company', 'char', 3, 'SGD'),
('use_dimension', 'setup.company', 'tinyint', 1, '1'),
('f_year', 'setup.company', 'int', 11, '3'),
('no_item_list', 'setup.company', 'tinyint', 1, '1'),
('no_customer_list', 'setup.company', 'tinyint', 1, '1'),
('no_supplier_list', 'setup.company', 'tinyint', 1, '1'),
('base_sales', 'setup.company', 'int', 11, '2'),
('time_zone', 'setup.company', 'tinyint', 1, '1'),
('add_pct', 'setup.company', 'int', 5, '-1'),
('round_to', 'setup.company', 'int', 5, '5'),
('login_tout', 'setup.company', 'smallint', 6, '6000'),
('past_due_days', 'glsetup.general', 'int', 11, '30'),
('profit_loss_year_act', 'glsetup.general', 'varchar', 15, '9990'),
('retained_earnings_act', 'glsetup.general', 'varchar', 15, '3590'),
('bank_charge_act', 'glsetup.general', 'varchar', 15, '5690'),
('exchange_diff_act', 'glsetup.general', 'varchar', 15, '4450'),
('default_credit_limit', 'glsetup.customer', 'int', 11, '1000'),
('accumulate_shipping', 'glsetup.customer', 'tinyint', 1, '0'),
('legal_text', 'glsetup.customer', 'tinytext', 0, 'Legal Text On Invoice '),
('freight_act', 'glsetup.customer', 'varchar', 15, '4430'),
('debtors_act', 'glsetup.sales', 'varchar', 15, '1200'),
('default_sales_act', 'glsetup.sales', 'varchar', 15, '4010'),
('default_sales_discount_act', 'glsetup.sales', 'varchar', 15, '4510'),
('default_prompt_payment_act', 'glsetup.sales', 'varchar', 15, '4500'),
('default_delivery_required', 'glsetup.sales', 'smallint', 6, '1'),
('default_dim_required', 'glsetup.dims', 'int', 11, '20'),
('pyt_discount_act', 'glsetup.purchase', 'varchar', 15, '5060'),
('creditors_act', 'glsetup.purchase', 'varchar', 15, '2100'),
('po_over_receive', 'glsetup.purchase', 'int', 11, '10'),
('po_over_charge', 'glsetup.purchase', 'int', 11, '10'),
('allow_negative_stock', 'glsetup.inventory', 'tinyint', 1, '1'),
('default_inventory_act', 'glsetup.items', 'varchar', 15, '1510'),
('default_cogs_act', 'glsetup.items', 'varchar', 15, '5010'),
('default_adj_act', 'glsetup.items', 'varchar', 15, '1510'),
('default_inv_sales_act', 'glsetup.items', 'varchar', 15, '4010'),
('default_assembly_act', 'glsetup.items', 'varchar', 15, '1530'),
('default_workorder_required', 'glsetup.manuf', 'int', 11, '20'),
('version_id', 'system', 'varchar', 11, '2.3rc'),
('auto_curr_reval', 'setup.company', 'smallint', 6, '1'),
('grn_clearing_act', 'glsetup.purchase', 'varchar', 15, '1550'),
('bcc_email', 'setup.company', 'varchar', 100, '');

-- --------------------------------------------------------

--
-- Table structure for table `sys_types`
--

CREATE TABLE IF NOT EXISTS `sys_types` (
  `type_id` smallint(6) NOT NULL DEFAULT '0',
  `type_no` int(11) NOT NULL DEFAULT '1',
  `next_reference` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `sys_types`
--

INSERT INTO `sys_types` (`type_id`, `type_no`, `next_reference`) VALUES
(0, 19, 'JV 0003'),
(1, 8, 'J/PV/0007'),
(2, 5, 'OR 0004'),
(4, 3, 'FT 0002'),
(10, 19, 'IV 0021'),
(11, 3, 'CCN 0001'),
(12, 6, 'COR 018'),
(13, 5, 'auto'),
(16, 2, 'TR 0001'),
(17, 2, 'ADJ 0003'),
(18, 1, 'auto'),
(20, 8, 'PI 00025'),
(21, 1, 'SCN 0002'),
(22, 4, 'IJ/PV/0012'),
(25, 1, 'auto'),
(26, 1, '1'),
(28, 1, '1'),
(29, 1, '1'),
(30, 5, 'auto'),
(32, 0, 'QO 0007'),
(35, 1, '1'),
(40, 1, '1');

-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

CREATE TABLE IF NOT EXISTS `tags` (
  `id` int(11) NOT NULL,
  `type` smallint(6) NOT NULL,
  `name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `inactive` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tags`
--

INSERT INTO `tags` (`id`, `type`, `name`, `description`, `inactive`) VALUES
(1, 1, 'test', 'test account tag', 0),
(2, 1, 'test account tag', 'this is test acc', 0),
(3, 2, 'PC Hardware', 'PC Hardware', 0),
(4, 2, 'Software', '`Software', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tag_associations`
--

CREATE TABLE IF NOT EXISTS `tag_associations` (
  `record_id` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `tag_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tax_groups`
--

CREATE TABLE IF NOT EXISTS `tax_groups` (
  `id` int(11) NOT NULL,
  `name` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tax_shipping` tinyint(1) NOT NULL DEFAULT '0',
  `inactive` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tax_groups`
--

INSERT INTO `tax_groups` (`id`, `name`, `tax_shipping`, `inactive`) VALUES
(1, 'Standard Taxable Customers', 1, 0),
(2, 'Tax Exempt', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tax_group_items`
--

CREATE TABLE IF NOT EXISTS `tax_group_items` (
  `tax_group_id` int(11) NOT NULL DEFAULT '0',
  `tax_type_id` int(11) NOT NULL DEFAULT '0',
  `rate` double NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tax_types`
--

CREATE TABLE IF NOT EXISTS `tax_types` (
  `id` int(11) NOT NULL,
  `rate` double NOT NULL DEFAULT '0',
  `sales_gl_code` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `purchasing_gl_code` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `name` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  `gst_03_type` tinyint(3) NOT NULL,
  `f3_box` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `use_for` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tax_types`
--

INSERT INTO `tax_types` (`id`, `rate`, `sales_gl_code`, `purchasing_gl_code`, `name`, `inactive`, `gst_03_type`, `f3_box`, `use_for`) VALUES
(12, 6, '2150', '1300', 'Purchase GST Standard 6% (TX)', 0, 1, '6a', 3),
(13, 6, '2150', '1300', 'Purchase - Goods And Services Tax (IM)', 0, 2, '6a', 3),
(14, 0, '2150', '1300', 'Purchase - Goods And Services Tax', 1, 0, '', 1),
(15, 6, '2150', '1300', 'Purchase - Goods And Services Tax (BL)', 0, 4, '', 3),
(16, 0, '2150', '1300', 'Purchase - Goods And Services Tax (NR)', 0, 5, '', 3),
(17, 0, '2150', '1300', 'Purchase - Goods And Services Tax (ZP)', 0, 6, '6a', 3),
(18, 0, '2150', '1300', 'Purchase - Goods And Services Tax (ZP)', 0, 6, '6a', 3),
(19, 0, '2150', '1300', 'Purchase - Goods And Services Tax (EP)', 0, 7, '', 3),
(20, 0, '2150', '1300', 'Purchase - Goods And Services Tax (OP)', 0, 8, '6a', 3),
(21, 6, '2150', '1300', 'Purchase - Goods And Services Tax (TX-E43)', 0, 9, '6a', 3),
(22, 6, '2150', '1300', 'Purchase - Goods And Services Tax (TX-N43)', 0, 10, '', 3),
(23, 7, '2150', '1300', 'Purchase - Goods And Services Tax', 1, 0, '', 1),
(24, 0, '2150', '1300', 'Purchase - Goods And Services Tax', 1, 0, '', 1),
(25, 7, '2150', '1300', 'Purchase - Goods And Services Tax', 1, 0, '', 1),
(26, 6, '2150', '1300', 'SR', 0, 14, '5a', 2),
(27, 0, '2150', '1300', 'Supply - Goods And Services Tax (ZRE)', 0, 104, '', 2),
(28, 0, '2150', '1300', 'Supply - Goods And Services Tax (ES43)', 0, 16, '', 2),
(29, 0, '2150', '1300', 'Supply - Goods And Services Tax (ESN43)', 0, 17, '', 2),
(30, 6, '2150', '1300', 'Supply - Goods And Services Tax (DS)', 0, 18, '', 2),
(31, 0, '2150', '1300', 'Supply - Goods And Services Tax (OS)', 0, 19, '', 2),
(32, 0, '2150', '1300', 'Supply - Goods And Services Tax (ES)', 0, 20, '', 2),
(33, 0, '2150', '1300', 'Supply - Goods And Services Tax', 1, 0, '', 1),
(34, 0, '2150', '1300', 'Supply - Goods And Services Tax', 1, 0, '', 1),
(35, 7, '2150', '1300', 'Supply - Services Tax', 1, 0, '', 1),
(37, 0, '2150', '1300', 'Supply - Goods And Services Tax', 1, 0, '', 1),
(38, 0, '2150', '1300', '', 0, 0, '', 1),
(39, 0, '2150', '1300', '', 0, 0, '', 1),
(40, 0, '2150', '1300', '', 0, 0, '', 1),
(41, 0, '2150', '1300', '', 0, 0, '', 1),
(42, 0, '2150', '1300', '', 0, 0, '', 1),
(43, 0, '2150', '1300', '', 0, 0, '', 1),
(44, 0, '2150', '1300', '', 0, 0, '', 1),
(45, 0, '2150', '1300', '', 0, 0, '', 1),
(46, 0, '2150', '1300', '', 0, 0, '', 1),
(47, 0, '2150', '1300', '', 0, 0, '', 1),
(48, 0, '2150', '1300', '', 0, 0, '', 1),
(49, 0, '2150', '1300', '', 0, 0, '', 1),
(50, 0, '2150', '1300', '', 0, 0, '', 1),
(51, 0, '2150', '1300', '', 0, 0, '', 1),
(52, 0, '2150', '1300', '', 0, 0, '', 1),
(53, 0, '2150', '1300', '', 0, 0, '', 1),
(54, 0, '2150', '1300', '', 0, 0, '', 1),
(55, 0, '2150', '1300', '', 0, 0, '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbltaxcode`
--

CREATE TABLE IF NOT EXISTS `tbltaxcode` (
  `taxcodeid` int(11) NOT NULL,
  `taxcodeno` varchar(60) NOT NULL,
  `defaultrate` double DEFAULT NULL,
  `taxcodecategory` varchar(1) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbltaxcode`
--

INSERT INTO `tbltaxcode` (`taxcodeid`, `taxcodeno`, `defaultrate`, `taxcodecategory`) VALUES
(1, 'TX', 6, '0'),
(2, 'IM', 6, '0'),
(3, 'IS', 0, '0'),
(4, 'BL', 6, '0'),
(5, 'NR', 0, '0'),
(6, 'ZP', 0, '0'),
(7, 'EP', 0, '0'),
(8, 'OP', 0, '0'),
(9, 'TX-E43', 6, '0'),
(10, 'TX-N43', 6, '0'),
(11, 'TX-RE', 0, '0'),
(12, 'GP', 6, '0'),
(13, 'AP', 0, '0'),
(14, 'SR', 6, '1'),
(15, 'ZR', 6, '1'),
(16, 'ES43', 0, '1'),
(17, 'ESN43', 0, '1'),
(18, 'DS', 0, '1'),
(19, 'OS', 6, '1'),
(20, 'ES', 0, '1'),
(21, 'RS', 0, '1'),
(22, 'GS', 0, '1'),
(23, 'AS', 6, '1');

-- --------------------------------------------------------

--
-- Table structure for table `trans_tax_details`
--

CREATE TABLE IF NOT EXISTS `trans_tax_details` (
  `id` int(11) NOT NULL,
  `trans_type` smallint(6) DEFAULT NULL,
  `trans_no` int(11) DEFAULT NULL,
  `tran_date` date NOT NULL,
  `tax_type_id` int(11) NOT NULL DEFAULT '0',
  `rate` double NOT NULL DEFAULT '0',
  `ex_rate` double NOT NULL DEFAULT '1',
  `included_in_price` tinyint(1) NOT NULL DEFAULT '0',
  `net_amount` double NOT NULL DEFAULT '0',
  `amount` double NOT NULL DEFAULT '0',
  `memo` tinytext COLLATE utf8_unicode_ci
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `trans_tax_details`
--

INSERT INTO `trans_tax_details` (`id`, `trans_type`, `trans_no`, `tran_date`, `tax_type_id`, `rate`, `ex_rate`, `included_in_price`, `net_amount`, `amount`, `memo`) VALUES
(1, 13, 1, '2016-08-10', 54, 7, 1, 0, 120, 8.4, 'auto'),
(2, 10, 1, '0000-00-00', 54, 7, 1, 0, 120, 8.4, 'IV 0001'),
(3, 13, 2, '2016-08-11', 54, 7, 1, 0, 230, 16.1, 'auto'),
(4, 10, 2, '0000-00-00', 54, 7, 1, 0, 230, 16.1, 'IV 0002'),
(5, 13, 3, '2016-07-10', 54, 7, 1, 0, 500, 35, 'auto'),
(6, 10, 3, '0000-00-00', 54, 7, 1, 0, 500, 35, 'IV 0003'),
(7, 13, 4, '2016-08-09', 54, 7, 1, 0, 1450, 101.5, 'auto'),
(8, 10, 4, '0000-00-00', 54, 7, 1, 0, 1450, 101.5, 'IV 0004'),
(9, 13, 5, '2016-08-09', 54, 7, 1, 0, 625, 43.75, 'auto'),
(10, 10, 5, '0000-00-00', 54, 7, 1, 0, 625, 43.75, 'IV 0005'),
(11, 13, 6, '2016-08-09', 54, 7, 1, 0, 500, 35, 'auto'),
(12, 10, 6, '0000-00-00', 54, 7, 1, 0, 500, 35, 'IV 0006'),
(13, 13, 7, '2016-08-09', 54, 7, 1, 0, 1000, 70, 'auto'),
(14, 10, 7, '0000-00-00', 54, 7, 1, 0, 1000, 70, 'IV 0007'),
(15, 13, 9, '2016-08-10', 54, 7, 1, 0, 900, 63, 'auto'),
(16, 10, 9, '0000-00-00', 54, 7, 1, 0, 900, 63, 'IV 0009'),
(17, 13, 10, '2016-08-10', 54, 7, 1, 0, 2000, 140, 'auto'),
(18, 10, 10, '0000-00-00', 54, 7, 1, 0, 2000, 140, 'IV 0010'),
(19, 13, 11, '2016-08-10', 54, 7, 1, 0, 760, 53.2, 'auto'),
(20, 10, 11, '0000-00-00', 54, 7, 1, 0, 560, 39.2, 'IV 0011'),
(21, 10, 11, '0000-00-00', 54, 7, 1, 0, 200, 14, 'IV 0011'),
(22, 13, 12, '2016-08-10', 54, 7, 1, 0, 1000, 70, 'auto'),
(23, 10, 12, '0000-00-00', 54, 7, 1, 0, 1000, 70, 'IV 0012'),
(24, 13, 13, '2016-08-10', 54, 7, 1, 0, 0, 0, 'auto'),
(25, 10, 13, '0000-00-00', 54, 7, 1, 0, 0, 0, 'IV 0013'),
(26, 13, 13, '2016-08-10', 54, 7, 1, 0, 2000, 140, 'IV 0013'),
(27, 13, 14, '2016-08-26', 54, 7, 1, 0, 800, 56, 'auto'),
(28, 10, 14, '0000-00-00', 54, 7, 1, 0, 800, 56, 'IV 0014'),
(29, 13, 15, '2016-08-29', 49, 0, 1, 0, 50, 0, 'auto'),
(30, 10, 15, '0000-00-00', 49, 0, 1, 0, 50, 0, 'IV 0015'),
(31, 13, 17, '2016-09-28', 54, 7, 1, 0, 200, 14, 'auto'),
(32, 10, 17, '0000-00-00', 54, 7, 1, 0, 200, 14, 'IV 0017'),
(33, 13, 19, '2017-02-16', 26, 7, 1, 0, 250, 17.5, 'auto'),
(34, 13, 20, '2017-02-16', 30, 7, 1, 0, 150, 10.5, 'auto'),
(35, 13, 21, '2017-02-16', 30, 7, 1, 0, 699, 48.93, 'auto'),
(36, 10, 18, '0000-00-00', 30, 7, 1, 0, 699, 48.93, 'IV 0018'),
(37, 13, 22, '2017-02-23', 30, 7, 1, 0, 1000, 70, 'auto'),
(38, 10, 19, '0000-00-00', 30, 7, 1, 0, 1000, 70, 'IV 0019');

-- --------------------------------------------------------

--
-- Table structure for table `useronline`
--

CREATE TABLE IF NOT EXISTS `useronline` (
  `id` int(11) NOT NULL,
  `timestamp` int(15) NOT NULL DEFAULT '0',
  `ip` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `file` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` smallint(6) NOT NULL,
  `user_id` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `real_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `role_id` int(11) NOT NULL DEFAULT '1',
  `phone` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_format` tinyint(1) NOT NULL DEFAULT '0',
  `date_sep` tinyint(1) NOT NULL DEFAULT '0',
  `tho_sep` tinyint(1) NOT NULL DEFAULT '0',
  `dec_sep` tinyint(1) NOT NULL DEFAULT '0',
  `theme` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'default',
  `page_size` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'A4',
  `prices_dec` smallint(6) NOT NULL DEFAULT '2',
  `qty_dec` smallint(6) NOT NULL DEFAULT '2',
  `rates_dec` smallint(6) NOT NULL DEFAULT '4',
  `percent_dec` smallint(6) NOT NULL DEFAULT '1',
  `show_gl` tinyint(1) NOT NULL DEFAULT '1',
  `show_codes` tinyint(1) NOT NULL DEFAULT '0',
  `show_hints` tinyint(1) NOT NULL DEFAULT '0',
  `last_visit_date` datetime DEFAULT NULL,
  `query_size` tinyint(1) unsigned NOT NULL DEFAULT '10',
  `graphic_links` tinyint(1) DEFAULT '1',
  `pos` smallint(6) DEFAULT '1',
  `print_profile` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `rep_popup` tinyint(1) DEFAULT '1',
  `sticky_doc_date` tinyint(1) DEFAULT '0',
  `startup_tab` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  `amount_dec` tinyint(1) NOT NULL DEFAULT '0',
  `imei` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_id`, `password`, `real_name`, `role_id`, `phone`, `email`, `language`, `date_format`, `date_sep`, `tho_sep`, `dec_sep`, `theme`, `page_size`, `prices_dec`, `qty_dec`, `rates_dec`, `percent_dec`, `show_gl`, `show_codes`, `show_hints`, `last_visit_date`, `query_size`, `graphic_links`, `pos`, `print_profile`, `rep_popup`, `sticky_doc_date`, `startup_tab`, `inactive`, `amount_dec`, `imei`) VALUES
(14, 'accounts', '81dc9bdb52d04dc20036dbd8313ed055', 'accounts', 9, '', '', 'C', 1, 2, 0, 0, 'uniq365', 'A4', 4, 0, 4, 2, 1, 1, 1, '2016-09-28 16:18:42', 50, 1, 1, '', 1, 1, 'orders', 0, 2, NULL),
(10, 'admin', '4297f44b13955235245b2497399d7a93', 'Administrator', 2, '', '', 'C', 1, 2, 0, 0, 'uniq365', 'A4', 2, 2, 4, 2, 1, 1, 1, '2017-05-20 18:50:55', 50, 1, 1, '', 1, 1, 'orders', 0, 2, ''),
(13, 'tester', 'e10adc3949ba59abbe56e057f20f883e', 'tester', 9, '', '', 'C', 1, 2, 0, 0, 'template', 'A4', 2, 2, 4, 2, 1, 1, 1, NULL, 50, 1, 1, '', 1, 1, 'orders', 0, 0, NULL),
(12, 'rome', '5f4dcc3b5aa765d61d8327deb882cf99', 'Rome', 2, '', '', 'C', 1, 2, 0, 0, 'template', 'A4', 3, 2, 4, 2, 1, 1, 1, '2015-10-05 15:18:47', 50, 1, 1, '', 1, 1, 'orders', 0, 0, NULL),
(15, 'james', '4297f44b13955235245b2497399d7a93', 'James', 3, 'Lee', '', 'C', 1, 2, 0, 0, 'uniq365', 'A4', 2, 2, 4, 2, 1, 1, 1, '2017-03-07 17:17:16', 50, 1, 1, '', 1, 1, 'orders', 0, 0, ''),
(16, 'TPLSB', '4297f44b13955235245b2497399d7a93', '', 10, '', '', 'C', 1, 2, 0, 0, 'uniq365', 'A4', 2, 2, 4, 2, 1, 1, 1, '2017-03-15 15:36:26', 50, 1, 1, '', 1, 1, 'orders', 0, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `voided`
--

CREATE TABLE IF NOT EXISTS `voided` (
  `type` int(11) NOT NULL DEFAULT '0',
  `id` int(11) NOT NULL DEFAULT '0',
  `date_` date NOT NULL DEFAULT '0000-00-00',
  `memo_` tinytext COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `voided`
--

INSERT INTO `voided` (`type`, `id`, `date_`, `memo_`) VALUES
(12, 1, '2016-08-10', '');

-- --------------------------------------------------------

--
-- Table structure for table `workcentres`
--

CREATE TABLE IF NOT EXISTS `workcentres` (
  `id` int(11) NOT NULL,
  `name` char(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` char(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `inactive` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `workorders`
--

CREATE TABLE IF NOT EXISTS `workorders` (
  `id` int(11) NOT NULL,
  `wo_ref` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `loc_code` varchar(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `units_reqd` double NOT NULL DEFAULT '1',
  `stock_id` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `date_` date NOT NULL DEFAULT '0000-00-00',
  `type` tinyint(4) NOT NULL DEFAULT '0',
  `required_by` date NOT NULL DEFAULT '0000-00-00',
  `released_date` date NOT NULL DEFAULT '0000-00-00',
  `units_issued` double NOT NULL DEFAULT '0',
  `closed` tinyint(1) NOT NULL DEFAULT '0',
  `released` tinyint(1) NOT NULL DEFAULT '0',
  `additional_costs` double NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wo_issues`
--

CREATE TABLE IF NOT EXISTS `wo_issues` (
  `issue_no` int(11) NOT NULL,
  `workorder_id` int(11) NOT NULL DEFAULT '0',
  `reference` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `issue_date` date DEFAULT NULL,
  `loc_code` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `workcentre_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wo_issue_items`
--

CREATE TABLE IF NOT EXISTS `wo_issue_items` (
  `id` int(11) NOT NULL,
  `stock_id` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `issue_id` int(11) DEFAULT NULL,
  `qty_issued` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wo_manufacture`
--

CREATE TABLE IF NOT EXISTS `wo_manufacture` (
  `id` int(11) NOT NULL,
  `reference` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `workorder_id` int(11) NOT NULL DEFAULT '0',
  `quantity` double NOT NULL DEFAULT '0',
  `date_` date NOT NULL DEFAULT '0000-00-00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wo_requirements`
--

CREATE TABLE IF NOT EXISTS `wo_requirements` (
  `id` int(11) NOT NULL,
  `workorder_id` int(11) NOT NULL DEFAULT '0',
  `stock_id` char(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `workcentre` int(11) NOT NULL DEFAULT '0',
  `units_req` double NOT NULL DEFAULT '1',
  `std_cost` double NOT NULL DEFAULT '0',
  `loc_code` char(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `units_issued` double NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attachments`
--
ALTER TABLE `attachments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `type_no` (`type_no`,`trans_no`);

--
-- Indexes for table `audit_trail`
--
ALTER TABLE `audit_trail`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Seq` (`fiscal_year`,`gl_date`,`gl_seq`),
  ADD KEY `Type_and_Number` (`type`,`trans_no`);

--
-- Indexes for table `bad_debts`
--
ALTER TABLE `bad_debts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `bank_accounts`
--
ALTER TABLE `bank_accounts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `bank_account_name` (`bank_account_name`),
  ADD KEY `bank_account_number` (`bank_account_number`),
  ADD KEY `account_code` (`account_code`);

--
-- Indexes for table `bank_trans`
--
ALTER TABLE `bank_trans`
  ADD PRIMARY KEY (`id`),
  ADD KEY `bank_act` (`bank_act`,`ref`),
  ADD KEY `type` (`type`,`trans_no`),
  ADD KEY `bank_act_2` (`bank_act`,`reconciled`),
  ADD KEY `bank_act_3` (`bank_act`,`trans_date`);

--
-- Indexes for table `bank_trans_detail`
--
ALTER TABLE `bank_trans_detail`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `bom`
--
ALTER TABLE `bom`
  ADD PRIMARY KEY (`id`,`parent`,`component`,`workcentre_added`,`loc_code`),
  ADD KEY `component` (`component`),
  ADD KEY `id` (`id`),
  ADD KEY `loc_code` (`loc_code`),
  ADD KEY `parent` (`parent`,`loc_code`),
  ADD KEY `workcentre_added` (`workcentre_added`);

--
-- Indexes for table `budget_trans`
--
ALTER TABLE `budget_trans`
  ADD PRIMARY KEY (`counter`),
  ADD KEY `Type_and_Number` (`type`,`type_no`),
  ADD KEY `Account` (`account`,`tran_date`,`dimension_id`,`dimension2_id`);

--
-- Indexes for table `chart_class`
--
ALTER TABLE `chart_class`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `chart_master`
--
ALTER TABLE `chart_master`
  ADD PRIMARY KEY (`account_code`),
  ADD KEY `account_name` (`account_name`),
  ADD KEY `accounts_by_type` (`account_type`,`account_code`);

--
-- Indexes for table `chart_types`
--
ALTER TABLE `chart_types`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `class_id` (`class_id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD KEY `type_and_id` (`type`,`id`);

--
-- Indexes for table `credit_status`
--
ALTER TABLE `credit_status`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `reason_description` (`reason_description`);

--
-- Indexes for table `crm_categories`
--
ALTER TABLE `crm_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `type` (`type`,`action`),
  ADD UNIQUE KEY `type_2` (`type`,`name`);

--
-- Indexes for table `crm_contacts`
--
ALTER TABLE `crm_contacts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `type` (`type`,`action`);

--
-- Indexes for table `crm_persons`
--
ALTER TABLE `crm_persons`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ref` (`ref`);

--
-- Indexes for table `currencies`
--
ALTER TABLE `currencies`
  ADD PRIMARY KEY (`curr_abrev`);

--
-- Indexes for table `cust_allocations`
--
ALTER TABLE `cust_allocations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `From` (`trans_type_from`,`trans_no_from`),
  ADD KEY `To` (`trans_type_to`,`trans_no_to`);

--
-- Indexes for table `cust_branch`
--
ALTER TABLE `cust_branch`
  ADD PRIMARY KEY (`branch_code`,`debtor_no`),
  ADD KEY `branch_code` (`branch_code`),
  ADD KEY `branch_ref` (`branch_ref`),
  ADD KEY `group_no` (`group_no`);

--
-- Indexes for table `dashboard_reminders`
--
ALTER TABLE `dashboard_reminders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dashboard_widgets`
--
ALTER TABLE `dashboard_widgets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `data_incorrect`
--
ALTER TABLE `data_incorrect`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `debtors_master`
--
ALTER TABLE `debtors_master`
  ADD PRIMARY KEY (`debtor_no`),
  ADD UNIQUE KEY `debtor_ref` (`debtor_ref`),
  ADD KEY `name` (`name`);

--
-- Indexes for table `debtor_trans`
--
ALTER TABLE `debtor_trans`
  ADD PRIMARY KEY (`type`,`trans_no`),
  ADD KEY `debtor_no` (`debtor_no`,`branch_code`),
  ADD KEY `tran_date` (`tran_date`),
  ADD KEY `order_` (`order_`);

--
-- Indexes for table `debtor_trans_details`
--
ALTER TABLE `debtor_trans_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Transaction` (`debtor_trans_type`,`debtor_trans_no`),
  ADD KEY `src_id` (`src_id`);

--
-- Indexes for table `dimensions`
--
ALTER TABLE `dimensions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `reference` (`reference`),
  ADD KEY `date_` (`date_`),
  ADD KEY `due_date` (`due_date`),
  ADD KEY `type_` (`type_`);

--
-- Indexes for table `exchange_rates`
--
ALTER TABLE `exchange_rates`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `curr_code` (`curr_code`,`date_`);

--
-- Indexes for table `fiscal_year`
--
ALTER TABLE `fiscal_year`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `begin` (`begin`),
  ADD UNIQUE KEY `end` (`end`);

--
-- Indexes for table `gl_trans`
--
ALTER TABLE `gl_trans`
  ADD PRIMARY KEY (`counter`),
  ADD KEY `Type_and_Number` (`type`,`type_no`),
  ADD KEY `dimension_id` (`dimension_id`),
  ADD KEY `dimension2_id` (`dimension2_id`),
  ADD KEY `tran_date` (`tran_date`),
  ADD KEY `account_and_tran_date` (`account`,`tran_date`);

--
-- Indexes for table `grn_batch`
--
ALTER TABLE `grn_batch`
  ADD PRIMARY KEY (`id`),
  ADD KEY `delivery_date` (`delivery_date`),
  ADD KEY `purch_order_no` (`purch_order_no`);

--
-- Indexes for table `grn_items`
--
ALTER TABLE `grn_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `grn_batch_id` (`grn_batch_id`);

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `description` (`description`);

--
-- Indexes for table `import_process`
--
ALTER TABLE `import_process`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`),
  ADD KEY `id_2` (`id`);

--
-- Indexes for table `item_codes`
--
ALTER TABLE `item_codes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `stock_id` (`stock_id`,`item_code`),
  ADD KEY `item_code` (`item_code`);

--
-- Indexes for table `item_tax_types`
--
ALTER TABLE `item_tax_types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `item_tax_type_exemptions`
--
ALTER TABLE `item_tax_type_exemptions`
  ADD PRIMARY KEY (`item_tax_type_id`,`tax_type_id`);

--
-- Indexes for table `item_units`
--
ALTER TABLE `item_units`
  ADD PRIMARY KEY (`abbr`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `kv_country`
--
ALTER TABLE `kv_country`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kv_departments`
--
ALTER TABLE `kv_departments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kv_empl_attendancee`
--
ALTER TABLE `kv_empl_attendancee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kv_empl_cv`
--
ALTER TABLE `kv_empl_cv`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kv_empl_degree`
--
ALTER TABLE `kv_empl_degree`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kv_empl_experience`
--
ALTER TABLE `kv_empl_experience`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kv_empl_info`
--
ALTER TABLE `kv_empl_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kv_empl_job`
--
ALTER TABLE `kv_empl_job`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kv_empl_loan`
--
ALTER TABLE `kv_empl_loan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kv_empl_option`
--
ALTER TABLE `kv_empl_option`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kv_empl_salary`
--
ALTER TABLE `kv_empl_salary`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kv_empl_training`
--
ALTER TABLE `kv_empl_training`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kv_loan_types`
--
ALTER TABLE `kv_loan_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `locations`
--
ALTER TABLE `locations`
  ADD PRIMARY KEY (`loc_code`);

--
-- Indexes for table `loc_stock`
--
ALTER TABLE `loc_stock`
  ADD PRIMARY KEY (`loc_code`,`stock_id`),
  ADD KEY `stock_id` (`stock_id`);

--
-- Indexes for table `log`
--
ALTER TABLE `log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `movement_types`
--
ALTER TABLE `movement_types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `msic_division`
--
ALTER TABLE `msic_division`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`),
  ADD KEY `id_2` (`id`);

--
-- Indexes for table `msic_item`
--
ALTER TABLE `msic_item`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`),
  ADD KEY `id_2` (`id`);

--
-- Indexes for table `msic_section`
--
ALTER TABLE `msic_section`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`),
  ADD KEY `id_2` (`id`);

--
-- Indexes for table `opening_cache`
--
ALTER TABLE `opening_cache`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `opening_customer`
--
ALTER TABLE `opening_customer`
  ADD PRIMARY KEY (`id`),
  ADD KEY `balance` (`balance`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `opening_gl`
--
ALTER TABLE `opening_gl`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `opening_gl_system`
--
ALTER TABLE `opening_gl_system`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `opening_product`
--
ALTER TABLE `opening_product`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`),
  ADD KEY `id_2` (`id`),
  ADD KEY `id_3` (`id`);

--
-- Indexes for table `opening_sale`
--
ALTER TABLE `opening_sale`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`),
  ADD KEY `id_2` (`id`);

--
-- Indexes for table `payment_terms`
--
ALTER TABLE `payment_terms`
  ADD PRIMARY KEY (`terms_indicator`),
  ADD UNIQUE KEY `terms` (`terms`);

--
-- Indexes for table `prices`
--
ALTER TABLE `prices`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `price` (`stock_id`,`sales_type_id`,`curr_abrev`);

--
-- Indexes for table `printers`
--
ALTER TABLE `printers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `print_profiles`
--
ALTER TABLE `print_profiles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `profile` (`profile`,`report`);

--
-- Indexes for table `purch_data`
--
ALTER TABLE `purch_data`
  ADD PRIMARY KEY (`supplier_id`,`stock_id`);

--
-- Indexes for table `purch_orders`
--
ALTER TABLE `purch_orders`
  ADD PRIMARY KEY (`order_no`),
  ADD KEY `ord_date` (`ord_date`);

--
-- Indexes for table `purch_order_details`
--
ALTER TABLE `purch_order_details`
  ADD PRIMARY KEY (`po_detail_item`),
  ADD KEY `order` (`order_no`,`po_detail_item`);

--
-- Indexes for table `quick_entries`
--
ALTER TABLE `quick_entries`
  ADD PRIMARY KEY (`id`),
  ADD KEY `description` (`description`);

--
-- Indexes for table `quick_entry_lines`
--
ALTER TABLE `quick_entry_lines`
  ADD PRIMARY KEY (`id`),
  ADD KEY `qid` (`qid`);

--
-- Indexes for table `recurrent_invoices`
--
ALTER TABLE `recurrent_invoices`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `description` (`description`);

--
-- Indexes for table `refs`
--
ALTER TABLE `refs`
  ADD PRIMARY KEY (`id`,`type`),
  ADD KEY `Type_and_Reference` (`type`,`reference`);

--
-- Indexes for table `salesman`
--
ALTER TABLE `salesman`
  ADD PRIMARY KEY (`salesman_code`),
  ADD UNIQUE KEY `salesman_name` (`salesman_name`);

--
-- Indexes for table `sales_orders`
--
ALTER TABLE `sales_orders`
  ADD PRIMARY KEY (`trans_type`,`order_no`);

--
-- Indexes for table `sales_order_details`
--
ALTER TABLE `sales_order_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sorder` (`trans_type`,`order_no`);

--
-- Indexes for table `sales_pos`
--
ALTER TABLE `sales_pos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `pos_name` (`pos_name`);

--
-- Indexes for table `sales_types`
--
ALTER TABLE `sales_types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `sales_type` (`sales_type`);

--
-- Indexes for table `security_roles`
--
ALTER TABLE `security_roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `role` (`role`);

--
-- Indexes for table `shippers`
--
ALTER TABLE `shippers`
  ADD PRIMARY KEY (`shipper_id`),
  ADD UNIQUE KEY `name` (`shipper_name`);

--
-- Indexes for table `source_reference`
--
ALTER TABLE `source_reference`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sql_trail`
--
ALTER TABLE `sql_trail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stock_category`
--
ALTER TABLE `stock_category`
  ADD PRIMARY KEY (`category_id`),
  ADD UNIQUE KEY `description` (`description`);

--
-- Indexes for table `stock_master`
--
ALTER TABLE `stock_master`
  ADD PRIMARY KEY (`stock_id`);

--
-- Indexes for table `stock_moves`
--
ALTER TABLE `stock_moves`
  ADD PRIMARY KEY (`trans_id`),
  ADD KEY `type` (`type`,`trans_no`),
  ADD KEY `Move` (`stock_id`,`loc_code`,`tran_date`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`supplier_id`),
  ADD KEY `supp_ref` (`supp_ref`);

--
-- Indexes for table `supp_allocations`
--
ALTER TABLE `supp_allocations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `From` (`trans_type_from`,`trans_no_from`),
  ADD KEY `To` (`trans_type_to`,`trans_no_to`);

--
-- Indexes for table `supp_invoice_items`
--
ALTER TABLE `supp_invoice_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Transaction` (`supp_trans_type`,`supp_trans_no`,`stock_id`);

--
-- Indexes for table `supp_trans`
--
ALTER TABLE `supp_trans`
  ADD PRIMARY KEY (`type`,`trans_no`),
  ADD KEY `supplier_id` (`supplier_id`),
  ADD KEY `SupplierID_2` (`supplier_id`,`supp_reference`),
  ADD KEY `type` (`type`),
  ADD KEY `tran_date` (`tran_date`);

--
-- Indexes for table `sys_expense_type`
--
ALTER TABLE `sys_expense_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sys_prefs`
--
ALTER TABLE `sys_prefs`
  ADD PRIMARY KEY (`name`),
  ADD KEY `category` (`category`);

--
-- Indexes for table `sys_types`
--
ALTER TABLE `sys_types`
  ADD PRIMARY KEY (`type_id`);

--
-- Indexes for table `tags`
--
ALTER TABLE `tags`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `type` (`type`,`name`);

--
-- Indexes for table `tag_associations`
--
ALTER TABLE `tag_associations`
  ADD UNIQUE KEY `record_id` (`record_id`,`tag_id`);

--
-- Indexes for table `tax_groups`
--
ALTER TABLE `tax_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `tax_group_items`
--
ALTER TABLE `tax_group_items`
  ADD PRIMARY KEY (`tax_group_id`,`tax_type_id`);

--
-- Indexes for table `tax_types`
--
ALTER TABLE `tax_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbltaxcode`
--
ALTER TABLE `tbltaxcode`
  ADD PRIMARY KEY (`taxcodeid`);

--
-- Indexes for table `trans_tax_details`
--
ALTER TABLE `trans_tax_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Type_and_Number` (`trans_type`,`trans_no`),
  ADD KEY `tran_date` (`tran_date`);

--
-- Indexes for table `useronline`
--
ALTER TABLE `useronline`
  ADD PRIMARY KEY (`id`),
  ADD KEY `timestamp` (`timestamp`),
  ADD KEY `ip` (`ip`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexes for table `voided`
--
ALTER TABLE `voided`
  ADD UNIQUE KEY `id` (`type`,`id`);

--
-- Indexes for table `workcentres`
--
ALTER TABLE `workcentres`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `workorders`
--
ALTER TABLE `workorders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `wo_ref` (`wo_ref`);

--
-- Indexes for table `wo_issues`
--
ALTER TABLE `wo_issues`
  ADD PRIMARY KEY (`issue_no`),
  ADD KEY `workorder_id` (`workorder_id`);

--
-- Indexes for table `wo_issue_items`
--
ALTER TABLE `wo_issue_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wo_manufacture`
--
ALTER TABLE `wo_manufacture`
  ADD PRIMARY KEY (`id`),
  ADD KEY `workorder_id` (`workorder_id`);

--
-- Indexes for table `wo_requirements`
--
ALTER TABLE `wo_requirements`
  ADD PRIMARY KEY (`id`),
  ADD KEY `workorder_id` (`workorder_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attachments`
--
ALTER TABLE `attachments`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `audit_trail`
--
ALTER TABLE `audit_trail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=194;
--
-- AUTO_INCREMENT for table `bad_debts`
--
ALTER TABLE `bad_debts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `bank_accounts`
--
ALTER TABLE `bank_accounts`
  MODIFY `id` smallint(6) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `bank_trans`
--
ALTER TABLE `bank_trans`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=46;
--
-- AUTO_INCREMENT for table `bank_trans_detail`
--
ALTER TABLE `bank_trans_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `bom`
--
ALTER TABLE `bom`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `budget_trans`
--
ALTER TABLE `budget_trans`
  MODIFY `counter` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `credit_status`
--
ALTER TABLE `credit_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `crm_categories`
--
ALTER TABLE `crm_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'pure technical key',AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `crm_contacts`
--
ALTER TABLE `crm_contacts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=64;
--
-- AUTO_INCREMENT for table `crm_persons`
--
ALTER TABLE `crm_persons`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=43;
--
-- AUTO_INCREMENT for table `cust_allocations`
--
ALTER TABLE `cust_allocations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `cust_branch`
--
ALTER TABLE `cust_branch`
  MODIFY `branch_code` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `dashboard_reminders`
--
ALTER TABLE `dashboard_reminders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `dashboard_widgets`
--
ALTER TABLE `dashboard_widgets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `data_incorrect`
--
ALTER TABLE `data_incorrect`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `debtors_master`
--
ALTER TABLE `debtors_master`
  MODIFY `debtor_no` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `debtor_trans_details`
--
ALTER TABLE `debtor_trans_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=59;
--
-- AUTO_INCREMENT for table `dimensions`
--
ALTER TABLE `dimensions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `exchange_rates`
--
ALTER TABLE `exchange_rates`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=91;
--
-- AUTO_INCREMENT for table `fiscal_year`
--
ALTER TABLE `fiscal_year`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `gl_trans`
--
ALTER TABLE `gl_trans`
  MODIFY `counter` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=399;
--
-- AUTO_INCREMENT for table `grn_batch`
--
ALTER TABLE `grn_batch`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=54;
--
-- AUTO_INCREMENT for table `grn_items`
--
ALTER TABLE `grn_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=66;
--
-- AUTO_INCREMENT for table `groups`
--
ALTER TABLE `groups`
  MODIFY `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `import_process`
--
ALTER TABLE `import_process`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `item_codes`
--
ALTER TABLE `item_codes`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2542;
--
-- AUTO_INCREMENT for table `item_tax_types`
--
ALTER TABLE `item_tax_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `kv_country`
--
ALTER TABLE `kv_country`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=247;
--
-- AUTO_INCREMENT for table `kv_departments`
--
ALTER TABLE `kv_departments`
  MODIFY `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `kv_empl_attendancee`
--
ALTER TABLE `kv_empl_attendancee`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `kv_empl_cv`
--
ALTER TABLE `kv_empl_cv`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `kv_empl_degree`
--
ALTER TABLE `kv_empl_degree`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `kv_empl_experience`
--
ALTER TABLE `kv_empl_experience`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `kv_empl_info`
--
ALTER TABLE `kv_empl_info`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `kv_empl_job`
--
ALTER TABLE `kv_empl_job`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `kv_empl_loan`
--
ALTER TABLE `kv_empl_loan`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `kv_empl_option`
--
ALTER TABLE `kv_empl_option`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `kv_empl_salary`
--
ALTER TABLE `kv_empl_salary`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=137;
--
-- AUTO_INCREMENT for table `kv_empl_training`
--
ALTER TABLE `kv_empl_training`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `kv_loan_types`
--
ALTER TABLE `kv_loan_types`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `log`
--
ALTER TABLE `log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `movement_types`
--
ALTER TABLE `movement_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `msic_division`
--
ALTER TABLE `msic_division`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=84;
--
-- AUTO_INCREMENT for table `msic_item`
--
ALTER TABLE `msic_item`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `msic_section`
--
ALTER TABLE `msic_section`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `opening_cache`
--
ALTER TABLE `opening_cache`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT for table `opening_customer`
--
ALTER TABLE `opening_customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `opening_gl`
--
ALTER TABLE `opening_gl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `opening_gl_system`
--
ALTER TABLE `opening_gl_system`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `opening_product`
--
ALTER TABLE `opening_product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `opening_sale`
--
ALTER TABLE `opening_sale`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `payment_terms`
--
ALTER TABLE `payment_terms`
  MODIFY `terms_indicator` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `prices`
--
ALTER TABLE `prices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `printers`
--
ALTER TABLE `printers`
  MODIFY `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `print_profiles`
--
ALTER TABLE `print_profiles`
  MODIFY `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `purch_orders`
--
ALTER TABLE `purch_orders`
  MODIFY `order_no` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=56;
--
-- AUTO_INCREMENT for table `purch_order_details`
--
ALTER TABLE `purch_order_details`
  MODIFY `po_detail_item` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=70;
--
-- AUTO_INCREMENT for table `quick_entries`
--
ALTER TABLE `quick_entries`
  MODIFY `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `quick_entry_lines`
--
ALTER TABLE `quick_entry_lines`
  MODIFY `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `recurrent_invoices`
--
ALTER TABLE `recurrent_invoices`
  MODIFY `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `salesman`
--
ALTER TABLE `salesman`
  MODIFY `salesman_code` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `sales_order_details`
--
ALTER TABLE `sales_order_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=36;
--
-- AUTO_INCREMENT for table `sales_pos`
--
ALTER TABLE `sales_pos`
  MODIFY `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `sales_types`
--
ALTER TABLE `sales_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `security_roles`
--
ALTER TABLE `security_roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `shippers`
--
ALTER TABLE `shippers`
  MODIFY `shipper_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `source_reference`
--
ALTER TABLE `source_reference`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=52;
--
-- AUTO_INCREMENT for table `sql_trail`
--
ALTER TABLE `sql_trail`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `stock_category`
--
ALTER TABLE `stock_category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=51;
--
-- AUTO_INCREMENT for table `stock_moves`
--
ALTER TABLE `stock_moves`
  MODIFY `trans_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=60;
--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `supplier_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `supp_allocations`
--
ALTER TABLE `supp_allocations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `supp_invoice_items`
--
ALTER TABLE `supp_invoice_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT for table `sys_expense_type`
--
ALTER TABLE `sys_expense_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tags`
--
ALTER TABLE `tags`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tax_groups`
--
ALTER TABLE `tax_groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tax_types`
--
ALTER TABLE `tax_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=56;
--
-- AUTO_INCREMENT for table `tbltaxcode`
--
ALTER TABLE `tbltaxcode`
  MODIFY `taxcodeid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `trans_tax_details`
--
ALTER TABLE `trans_tax_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=39;
--
-- AUTO_INCREMENT for table `useronline`
--
ALTER TABLE `useronline`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` smallint(6) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `workcentres`
--
ALTER TABLE `workcentres`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `workorders`
--
ALTER TABLE `workorders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `wo_issues`
--
ALTER TABLE `wo_issues`
  MODIFY `issue_no` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `wo_issue_items`
--
ALTER TABLE `wo_issue_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `wo_manufacture`
--
ALTER TABLE `wo_manufacture`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `wo_requirements`
--
ALTER TABLE `wo_requirements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
